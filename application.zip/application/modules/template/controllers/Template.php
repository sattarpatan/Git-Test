<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();		
    }
	
	function one_col($data)
	{
		$this->load->view('once_col', $data);
	}
	
	function two_col($data=NULL)
	{
		
		$this->load->view('two_col', $data);
	}
	
	function admin($data)
	{
		$this->load->view('admin', $data);
	}
}
/******/	

/* $data['module'] = "tasks";
$data['view_file'] = "display";
Modules::run('template/two_col', $data); */