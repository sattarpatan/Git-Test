		  <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Users <small>Some examples to get you started</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Default Example <small>Users</small></h2>
                    <div class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="<?php echo site_url('state/index');?>"><i class="fa fa-bars"></i> Go to List</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                      The fields marked with <code>*</code> are required.
                    </p>
                    
<?php echo form_open('state/edit/'.$state['id'],array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="name" class="col-md-2 control-label">Name</label>
		<div class="col-md-8">
			<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $state['name']); ?>" class="form-control" id="name" />
		</div>
	</div>
	<div class="form-group">
		<label for="country_id" class="col-md-2 control-label">Country Id</label>
		<div class="col-md-8">
			<input type="text" name="country_id" value="<?php echo ($this->input->post('country_id') ? $this->input->post('country_id') : $state['country_id']); ?>" class="form-control" id="country_id" />
		</div>
	</div>
	<div class="form-group">
		<label for="status" class="col-md-2 control-label">Status</label>
		<div class="col-md-8">
			<input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $state['status']); ?>" class="form-control" id="status" />
		</div>
	</div>
	<div class="form-group">
		<label for="created_date" class="col-md-2 control-label">Created Date</label>
		<div class="col-md-8">
			<input type="text" name="created_date" value="<?php echo ($this->input->post('created_date') ? $this->input->post('created_date') : $state['created_date']); ?>" class="form-control" id="created_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="updated_date" class="col-md-2 control-label">Updated Date</label>
		<div class="col-md-8">
			<input type="text" name="updated_date" value="<?php echo ($this->input->post('updated_date') ? $this->input->post('updated_date') : $state['updated_date']); ?>" class="form-control" id="updated_date" />
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
<?php echo form_close(); ?>					
					
                  </div>
                </div>
              </div>
            </div>
          </div>

