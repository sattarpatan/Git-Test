<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('View Member'); ?>
		<?=view_list(base_url('members')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<div class="col-md-3 col-sm-3 col-xs-12 profile_left">
		  <div class="profile_img">
			<div id="crop-avatar">
			  <!-- Current avatar -->
			  <img class="img-responsive avatar-view" src="<?php echo $member['file_path'];?>" alt="<?php echo $member['name']; ?>" title="<?php echo $member['name']; ?>">
			</div>
		  </div>
		  <h3 class="blue"><?php echo $member['name']; ?></h3>

		  <ul class="list-unstyled user_data">
			
			<li><i class="fa fa-map-marker user-profile-icon">
				</i>&nbsp;&nbsp;<?php echo $member['country']; ?>
			</li>

			<li>
			  <i class="fa fa-envelope"></i>&nbsp;&nbsp;<?php echo $member['email']; ?>
			</li>
		  </ul>
		  <br/>
		  <!-- start skills -->
		  <h4 class="blue">Social Media</h4>
		   <ul class="list-unstyled user_data">
			<li class="m-top-xs">
			  <a href="<?php echo $member['facebook']; ?>" target="_blank">
				<i class="fa fa-facebook"></i>
				<?php echo $member['facebook']; ?></a>
			</li>
			<li class="m-top-xs">
			  <a href="<?php echo $member['twitter']; ?>" target="_blank">
				<i class="fa fa-twitter"></i>
				<?php echo $member['twitter']; ?></a>
			</li>
			<li>
				<a href="<?php echo $member['linkedin']; ?>" target="_blank">
				<i class="fa fa-linkedin"></i> <?php echo $member['linkedin']; ?></a>
			</li>
		  </ul>
		  <!-- end of skills -->

		</div>
		<div class="col-md-9 col-sm-9 col-xs-12">

		  <div class="profile_title">
			<div class="col-md-12">
			  <h2 class="blue">University</h2>
			</div>
		  </div>
		  <table class="table table-bordered">
			<tr>
				<td>Name</td>
				<td><?php echo $member['university']; ?></td>
			</tr>
			<tr>
				<td>Designation</td>
				<td><?php echo $member['u_designation']; ?></td>
			</tr>
			<tr>
				<td>Department</td>
				<td><?php echo $member['department']; ?></td>
			</tr>
		  </table>
		  
		  <div class="profile_title">
			<div class="col-md-12">
			  <h2 class="blue">Company</h2>
			</div>
		  </div>
		  <table class="table table-bordered">
			<tr>
				<td>Name</td>
				<td><?php echo $member['company']; ?></td>
			</tr>
			<tr>
				<td>Designation</td>
				<td><?php echo $member['c_designation']; ?></td>
			</tr>
		  </table>
		  
		  <div class="profile_title">
			<div class="col-md-12">
			  <h2 class="blue">Biography</h2>
			</div>
		  </div>
		  <br/>
		  <div><?php echo $member['biography']; ?></div>
		  <br/><br/>
		  <div class="profile_title">
			<div class="col-md-12">
			  <h2 class="blue">Researches</h2>
			</div>
		  </div>
		  <br/>
		  <?php foreach ($researchs as $research) { ?>
		  <p><?php echo $research['research']; ?></p>
		  <?php } ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('members'); ?>";
window.onload = function(){	
	$("#plus_btn").click(function(){
		var html = '<li><div class="form-group">\
		<div class="col-sm-1">\
						<span class="glyphicon glyphicon-sort text-success" id="sort_icon member"></span>\
					</div>\
					<div class="col-sm-10">\
						<textarea rows="3" cols="" class="form-control " id="research" name="research[]"></textarea>\
					</div>\
			<div class="col-sm-1">\
				<br/>\
				<a href="#" class="btn btn-success minus_btn">-</a>\
			</div>\
		</div></li>'
		$("#research_form").children().append(html);		
		$(".minus_btn").click(function(){
			$(this).closest("li").remove();
			return false;
		});		
		$("#sortable").sortable();		
		return false;	
	});
	
	$(".minus_btn").click(function(){
		$(this).closest("li").remove();
		return false;
	});	
	$("#sortable").sortable();
}
</script>