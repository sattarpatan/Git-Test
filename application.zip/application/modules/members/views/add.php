<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Member'); ?>
		<?=view_list(base_url('members')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('member_add_error')) { ?>
			<?=alert_error($this->session->flashdata('member_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Image <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<input type="file" name="member" id="member"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('member'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Name
			<span class="required">*</span></label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="name" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('name'); ?>">
			  <?php echo form_error('name'); ?>
			</div>
		  </div>
		 <?php /*  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Email <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="email" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('email'); ?>">
			  <?php echo form_error('email'); ?>
			</div>
		  </div> */?>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Country <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<input type="text" name="country" class="form-control col-md-7 col-xs-12" value="<?php echo set_value('country'); ?>">
				<?php echo form_error('country'); ?>
			</div>
		  </div>
		  
		  <div class="form-group"><hr/></div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> University / Company <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="company" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('company'); ?>">
			  <?php echo form_error('company'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Designation <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="u_designation" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('u_designation'); ?>">
			  <?php echo form_error('u_designation'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Department
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="department" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('department'); ?>">
			  <?php echo form_error('department'); ?>
			</div>
		  </div>
		  
		  <div class="form-group"><hr/></div>
		  
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Biography
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<textarea rows="5" cols="" class="ckeditor form-control " id="biography" name="biography"><?=$this->input->post('biography'); ?></textarea>
			  <?php echo form_error('biography'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Research & Interest
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			<textarea rows="5" cols="" class="form-control " id="research" name="research"><?php echo set_value('research'); ?></textarea>
			  <?php /* <div id="research_form">
					<ul id="sortable" class="ui-sortable">
							<li class="ui-sortable-handle">
							<div class="form-group">
								<div class="col-sm-1">
									<span class="glyphicon glyphicon-sort text-success" id="sort_icon member"></span>
								</div>
								<div class="col-sm-10">
									<textarea rows="3" cols="" class="form-control " id="research" name="research[]"></textarea>
								</div>
								<div class="col-sm-1">
									<a href="#" class="btn btn-success member" id="plus_btn">+</a>
								</div>
							</div>
						</li>
					</ul>
                </div> */?>
			</div>
		  </div>
		  
		  <?php /* <div class="form-group"><hr/></div>
		  
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Facebook
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="facebook" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('facebook'); ?>">
			  <?php echo form_error('facebook'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Twitter
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="twitter" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('twitter'); ?>">
			  <?php echo form_error('twitter'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Linkedin
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="linkedin" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('linkedin'); ?>">
			  <?php echo form_error('linkedin'); ?>
			</div>
		  </div> */?>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('members'); ?>";
window.onload = function(){	
	$("#plus_btn").click(function(){
		var html = '<li><div class="form-group">\
		<div class="col-sm-1">\
						<span class="glyphicon glyphicon-sort text-success" id="sort_icon member"></span>\
					</div>\
					<div class="col-sm-10">\
						<textarea rows="3" cols="" class="form-control " id="research" name="research[]"></textarea>\
					</div>\
			<div class="col-sm-1">\
				<br/>\
				<a href="#" class="btn btn-success minus_btn">-</a>\
			</div>\
		</div></li>'
		$("#research_form").children().append(html);
		
		$(".minus_btn").click(function(){
			$(this).closest("li").remove();
			return false;
		});
		
		$("#sortable").sortable();		
		return false;	
	});
}
</script>