<?php

class Members_Model extends CI_Model {

	public function getMembers($cnf_id=NULL) {
		if ($cnf_id==NULL) {
			$sql = "SELECT m.*, f.* FROM members m join filemaster f on m.file_id=f.file_id";
			$query = $this->db->query($sql);
		} else {
			$sql = "SELECT m.*, f.* FROM members m join filemaster f on m.file_id=f.file_id WHERE m.cnf_id=?";
			$query = $this->db->query($sql,$cnf_id);
		}
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getMember($member_id) {
		$sql = "SELECT m.*, f.* FROM members m join filemaster f on m.file_id=f.file_id WHERE m.member_id=?";
		$query = $this->db->query($sql,array($member_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function getResearches($member_id) {
		$sql = "SELECT * from member_researches WHERE member_id=?";
		$query = $this->db->query($sql,array($member_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getDeletePermission($member_id) {
		$sql = "SELECT * FROM members_confs WHERE member_id=?";
		$query = $this->db->query($sql,array($member_id));
		
		if ($query->num_rows()>1) {
			return false;
		}
		
		$sql1 = "SELECT m.* FROM members m JOIN filemaster f ON m.file_id=f.file_id WHERE member_id=? AND f.cnf_id=?";
		$query1 = $this->db->query($sql1,array($member_id,$this->session->userdata('cnf_id')));
		
		if ($query1->num_rows()!=1)
		{
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	public function getMemberConfs($member_id) {
		$sql = "SELECT cnf_url, short_name FROM confs WHERE cnf_id in (SELECT cnf_id FROM members_confs WHERE member_id=?)";
		$query = $this->db->query($sql,array($member_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function deleteMember($member_id){
		
		$this->db->trans_start();
		
		$sql = "delete from filemaster where file_id=(select file_id from members where member_id=?)";
		$this->db->query($sql,array($member_id));
		
		$sql = "delete from members_confs where member_id=?";
		$this->db->query($sql,array($member_id));
		
		$sql = "delete from members where member_id=?";
		$this->db->query($sql,array($member_id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	
	public function removeMember($member_id){
		
		$this->db->trans_start();
		
		$sql = "delete from members_confs where member_id=?";
		$this->db->query($sql,array($member_id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function insertMember($filepath) {
		
		$this->db->trans_start();
		
		$researches = array_filter($this->input->post('research'));
		
		$data = array(
			'file_path' 		=> 	$filepath,
			'title_desc'		=>	$this->input->post('name'),
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('filemaster',$data);
		
		$insert_id = $this->db->insert_id();
		
		$data = array(
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'file_id' 			=> 	$insert_id,
			'name'				=>	$this->input->post('name'),
			'email'				=>	$this->input->post('email'),
			'country'			=>	$this->input->post('country'),
			'university'		=>	$this->input->post('university'),
			'department'		=>	$this->input->post('department'),
			'u_designation'		=>	$this->input->post('u_designation'),
			'company'			=>	$this->input->post('company'),
			'c_designation'		=>	$this->input->post('c_designation'),
			'biography'			=>	$this->input->post('biography'),
			'research'			=>	$this->input->post('research'),			
			'facebook'			=>	$this->input->post('facebook'),
			'twitter'			=>	$this->input->post('twitter'),
			'linkedin'			=>	$this->input->post('linkedin'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s'),
			'url_slug'			=>	url_title(htmlentities($this->input->post('name'), ENT_SUBSTITUTE, "UTF-8"), 'dash', TRUE)
		);
		
		$this->db->insert('members',$data);
		
		$insert_id = $this->db->insert_id();
		
		/* if (!empty($researches)) {
			
			foreach ($researches as $key =>$value) {
				$data1[$key] = array(
					'member_id'			=>	$insert_id,
					'research' 			=>	$value,
					'created_by'		=>	$this->session->userdata('user_id'),
					'created_datetime'	=>	date('Y-m-d H:i:s')
				);
			}
			
			$this->db->insert_batch('member_researches',$data1);
		
		} */
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateMember($filepath) {
		
		$this->db->trans_start();
		
		$member_id = $this->input->post('member_id');
		$researches = array_filter($this->input->post('research'));
		
		if ($filepath!=false) {
		
			$data = array(
				'file_path' 		=> 	$filepath,
				'title_desc'		=>	$this->input->post('name'),
				'cnf_id'			=>	$this->session->userdata('cnf_id'),
				'created_by'		=> 	$this->session->userdata('user_id'),
				'created_datetime'	=>	date('Y-m-d H:i:s')
			);
			
			$this->db->where(array('file_id'=>$this->input->post('file_id')));
			
			$this->db->update('filemaster',$data);
		
		}
		
		$data = array(
			'name'				=>	$this->input->post('name'),
			'email'				=>	$this->input->post('email'),
			'country'			=>	$this->input->post('country'),
			'university'		=>	$this->input->post('university'),
			'department'		=>	$this->input->post('department'),
			'u_designation'		=>	$this->input->post('u_designation'),
			'company'			=>	$this->input->post('company'),
			'c_designation'		=>	$this->input->post('c_designation'),
			'biography'			=>	$this->input->post('biography'),
			'research'			=>	$this->input->post('research'),	
			'facebook'			=>	$this->input->post('facebook'),
			'twitter'			=>	$this->input->post('twitter'),
			'linkedin'			=>	$this->input->post('linkedin'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s'),
			'url_slug'			=>	url_title(htmlentities($this->input->post('name'), ENT_SUBSTITUTE, "UTF-8"), 'dash', TRUE)
		);
				
		$this->db->where(array('member_id'=>$member_id));
		
		$this->db->update('members',$data);
		
		$this->db->delete('member_researches',array('member_id' => $member_id));
		
		/* if (!empty($researches)) {
			
			foreach ($researches as $key =>$value) {
				$data1[$key] = array(
					'member_id'			=>	$member_id,
					'research' 			=>	$value,
					'created_by'		=>	$this->session->userdata('user_id'),
					'created_datetime'	=>	date('Y-m-d H:i:s')
				);
			}
			
			$this->db->insert_batch('member_researches',$data1);
		
		} */
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}
