<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Members extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('members/Members_Model');
			$this->load->model('conference/conference_model');
			$this->load->model('countries/countries_model');
			$this->load->model('universities/Universities_Model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{  
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['members'] = $this->Members_Model->getMembers($cnf_id);
		//$this->load->layout2('members/list',$data);
		
		$data['_view'] = 'members/list';
		$this->load->view('layouts/main',$data);
	}
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['countries'] = $this->countries_model->getCountryRows();
		$data['universities'] = $this->Universities_Model->getUniversities();
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Member',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('members_add') == FALSE)
		{			
			//$this->load->layout2('members/add',$data);
			
			$data['_view'] = 'members/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(member_id)+1 as member_id FROM members";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['member_id'],$cnf_id);
			$newFile = MEMBER_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['member'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('member_add_error', $this->session->flashdata('file_error')); 
				//$this->load->layout2('members/add',$data);
				
				$data['_view'] = 'members/add';
				$this->load->view('layouts/main',$data);
				exit;
			}
			else
			{
				$filePath = S3_PATH.$newFile;
			}	
				
			$insert_status = $this->Members_Model->insertMember($filePath);
			
			if ($insert_status==true) {
				$this->session->set_flashdata('members_success', 'Member added successfully!');
				redirect('members');
			}
			else
			{
				$this->session->set_flashdata('members_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('members/add',$data);
				
				$data['_view'] = 'members/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($member_id)
	{
		if ($this->check_edit_member_access($member_id)==true) {
			
			$filePath = false;
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['countries'] = $this->countries_model->getCountries();
			$data['universities'] = $this->Universities_Model->getUniversities();
			$data['member'] = $this->Members_Model->getMember($member_id);
			$data['researchs'] = $this->Members_Model->getResearches($member_id);
			$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Member',$this->session->userdata('company_id'));
			
			if ($this->form_validation->run('members_edit') == FALSE)
			{
				//$this->load->layout2('members/edit',$data);
				
				$data['_view'] = 'members/edit';
				$this->load->view('layouts/main',$data);
				
			}
			else
			{
				if (!empty($_FILES['member']['name']))
				{
					$newFileName = $this->createFileName($this->input->post('member_id'),$cnf_id);
					$newFile = MEMBER_IMAGES.$newFileName;
				
					$this->load->library('../controllers/upload');
					
					$upload_status = $this->upload->doUpload($_FILES['member'], $newFile, $data['upload_settings']);
					
					if ($upload_status==false)
					{
						$this->session->set_flashdata('member_edit_error', $this->session->flashdata('file_error')); 
						//$this->load->layout2('members/edit',$data);
						
						$data['_view'] = 'members/edit';
						$this->load->view('layouts/main',$data);
						exit;
					}
					else
					{
						$filePath = S3_PATH.$newFile;
					}
				}
				
				$update_status = $this->Members_Model->updateMember($filePath);
				
				if ($update_status==true) {
					$this->session->set_flashdata('members_success', 'Member updated successfully!');
					redirect('members');
				}
				else
				{
					$this->session->set_flashdata('members_edit_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('members/edit',$data);
					
					$data['_view'] = 'members/edit';
					$this->load->view('layouts/main',$data);
				}
			}
		} else {
			$this->session->set_flashdata('member_access_error','Sorry! You dont have access to edit this member! Contact support team for further details');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['members'] = $this->Members_Model->getMembers($cnf_id);
			//$this->load->layout2('members/list',$data);
			
			$data['_view'] = 'members/list';
			$this->load->view('layouts/main',$data);
		}
	}
	
	public function check_edit_member_access ($member_id) {
		$member = $this->Members_Model->getMember($member_id);
		$cnf_id = $this->session->userdata('cnf_id');
		if (isset($member['cnf_id']) && $member['cnf_id']==$cnf_id) {
			return true;
		} else {
			return false;
		}
	}
	
	public function createFileName($member_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['member']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$member_id.".".$fileinfo['extension'];
	}	
	
	public function view($member_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['countries'] = $this->countries_model->getCountries();
		$data['member'] = $this->Members_Model->getMember($member_id);
		$data['researchs'] = $this->Members_Model->getResearches($member_id);
		//$this->load->layout2('members/view',$data);
		
			$data['_view'] = 'members/view';
			$this->load->view('layouts/main',$data);
	}
	
	function removeMember(){
		$member_id = $this->input->post('member_id');
		echo $this->Members_Model->removeMember($member_id);
	}
	
	function getMember(){
		$member_id = $this->input->post('member_id');
		$member = $this->Members_Model->getMember($member_id);
		echo json_encode($member);
	}
	
	public function file_check() {
		if (empty($_FILES['member']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select member');
			return false;
		} else {
			return true;
		}
	}
	
	public function email_check() {
		$email =  $this->input->post('email');
		$sql = "SELECT * FROM members WHERE email=?";
		$query = $this->db->query($sql,$email);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('email_check', 'This email is not available!');
			return false;
		} else {
			return true;
		}
	}
	
	public function email_check_for_edit() {
		$email =  $this->input->post('email');
		$member_id = $this->input->post('member_id');
		$sql = "SELECT * FROM members WHERE email=? AND member_id!=?";
		$query = $this->db->query($sql,array($email,$member_id));
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('email_check_for_edit', 'Member already existed with this email id!');
			return false;
		} else {
			return true;
		}
	}
}