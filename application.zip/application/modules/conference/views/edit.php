		  <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Users <small>Some examples to get you started</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Default Example <small>Users</small></h2>
                    <div class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="<?php echo site_url('conference/index');?>"><i class="fa fa-bars"></i> Go to List</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                      The fields marked with <code>*</code> are required.
                    </p>
					
					 <?php echo form_open('conference/edit/'.$conference['id'],array("class"=>"form-horizontal")); ?>

						<div class="form-group">
							<label for="ConfUrl" class="col-md-2  control-label"><span class="text-danger">*</span>ConfUrl</label>
							<div class="col-md-8">
								<input type="text" name="ConfUrl" value="<?php echo $conference['ConfUrl']; ?>" class="form-control" id="ConfUrl" />
								<span class="text-danger"><?php echo form_error('ConfUrl');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="slug" class="col-md-2  control-label"><span class="text-danger">*</span>Slug</label>
							<div class="col-md-8">
								<input type="text" name="slug" value="<?php echo $conference['slug']; ?>" class="form-control" id="slug" />
								<span class="text-danger"><?php echo form_error('slug');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="ShortName" class="col-md-2  control-label"><span class="text-danger">*</span>ShortName</label>
							<div class="col-md-8">
								<input type="text" name="ShortName" value="<?php echo $conference['ShortName']; ?>" class="form-control" id="ShortName" />
								<span class="text-danger"><?php echo form_error('ShortName');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<label for="conf_start_date" class="col-md-2  control-label"><span class="text-danger">*</span>Conf Start Date</label>
							<div class="col-md-8">
								<input type="text" name="conf_start_date" value="<?php echo $conference['conf_start_date']; ?>" class="form-control" id="conf_start_date" />
								<span class="text-danger"><?php echo form_error('conf_start_date');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="conf_end_date" class="col-md-2  control-label"><span class="text-danger">*</span>Conf End Date</label>
							<div class="col-md-8">
								<input type="text" name="conf_end_date" value="<?php echo $conference['conf_end_date']; ?>" class="form-control" id="conf_end_date" />
								<span class="text-danger"><?php echo form_error('conf_end_date');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="country" class="col-md-2  control-label"><span class="text-danger">*</span>Country</label>
							<div class="col-md-8">
							
								<select name="country" id="country" class="form-control">
									<option value="">Select Country</option>
									<?php
									if(!empty($countries)){
										foreach($countries as $country){ 
											
											$selected = ($country['id'] == $conference['country']) ? ' selected="selected"' : set_value('country');
											
											echo '<option value="'.$country['id'].'" '.$selected.'>'.$country['name'].'</option>';
										}
									}else{
										echo '<option value="">Country not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('country');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="state" class="col-md-2  control-label"><span class="text-danger">*</span>State</label>
							<div class="col-md-8">
								<select name="state" id="state" class="form-control">
									<option value="">Select country first</option>
									<?php
									if(!empty($states)){
										foreach($states as $state){ 
											
											$selected = ($state['id'] == $conference['state']) ? ' selected="selected"' : set_value('state');
											
											echo '<option value="'.$state['id'].'" '.$selected.'>'.$state['name'].'</option>';
										}
									}else{
										echo '<option value="">State not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('state');?></span>
							</div>
						</div>
						<div class="form-group">
							<label for="city" class="col-md-2  control-label"><span class="text-danger">*</span>City</label>
							<div class="col-md-8">
								<!-- City dropdown -->
								<select name="city" id="city" class="form-control">
									<option value="">Select state first</option>
									<?php
									if(!empty($cities)){
										foreach($cities as $city){ 
											
											$selected = ($city['id'] == $conference['state']) ? ' selected="selected"' : set_value('state');
											
											echo '<option value="'.$state['id'].'" '.$selected.'>'.$state['name'].'</option>';
										}
									}else{
										echo '<option value="">Country not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('city');?></span>
							</div>
						</div>
						
						
						<div class="form-group">
							<label for="category" class="col-md-2  control-label"><span class="text-danger">*</span>Category</label>
							<div class="col-md-8">
								
								<select name="category" id="category" class="form-control">
									<option value="">Select Category</option>
									<?php
									if(!empty($categories)){
										foreach($categories as $cagegory){ 
										
										$selected = ($cagegory['id'] == $conference['category']) ? ' selected="selected"' : set_value('category');
										
											echo '<option value="'.$cagegory['id'].'" '.$selected.'>'.$cagegory['subject'].'</option>';
										}
									}else{
										echo '<option value="">Categories not available</option>';
									}
									?>
								</select>
								
							</div>
						</div>
						<div class="form-group">
							<label for="subject" class="col-md-2  control-label"><span class="text-danger">*</span>Subject</label>
							<div class="col-md-8">
								
								<select name="subject" id="subject" class="form-control">
									<option value="">Select Subject</option>
									<?php
									if(!empty($subjects)){
										foreach($subjects as $subject){ 
											$selected = ($subject['id'] == $conference['subject']) ? ' selected="selected"' : set_value('subject');
											
											echo '<option value="'.$subject['id'].'" '.$selected.'>'.$subject['subject'].'</option>';
										}
									}else{
										echo '<option value="">Subjects not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('subject');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<label for="subject" class="col-md-2  control-label"><span class="text-danger">*</span>CTL</label>
							<div class="col-md-8">
								
								<select name="conf_ctl" id="conf_ctl" class="form-control">
									<option value="">Select CTL</option>
									<?php
									if(!empty($ctls)){
										foreach($ctls as $ctl){ 
											$selected = ($ctl['user_id'] == $conference['conf_ctl']) ? ' selected="selected"' : set_value('conf_ctl');
											
											echo '<option value="'.$ctl['user_id'].'" '.$selected.'>'.$ctl['user_displayname'].'</option>';
										}
									}else{
										echo '<option value="">CTLs not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('conf_ctl');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<label for="subject" class="col-md-2  control-label"><span class="text-danger">*</span>TL</label>
							<div class="col-md-8">
								
								<select name="conf_tl" id="conf_tl" class="form-control">
									<option value="">Select TL</option>
									<?php
									if(!empty($tls)){
										foreach($tls as $tl){ 
											
											$selected = ($tl['user_id'] == $conference['conf_tl']) ? ' selected="selected"' : set_value('conf_tl');
											
											echo '<option value="'.$tl['user_id'].'" '.$selected.'>'.$tl['user_displayname'].'</option>';
										}
									}else{
										echo '<option value="">TLs not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('conf_tl');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<label for="subject" class="col-md-2  control-label"><span class="text-danger">*</span>PC</label>
							<div class="col-md-8">
								
								<select name="conf_pc" id="conf_pc" class="form-control">
									<option value="">Select PC</option>
									<?php
									if(!empty($pcs)){
										foreach($pcs as $pc){ 					
										
											$selected = ($pc['user_id'] == $conference['conf_pc']) ? ' selected="selected"' : set_value('conf_pc');
										
											echo '<option value="'.$pc['user_id'].'" '.$selected.'>'.$pc['user_displayname'].'</option>';
										}
									}else{
										echo '<option value="">PCs not available</option>';
									}
									?>
								</select>
								<span class="text-danger"><?php echo form_error('conf_pc');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<label for="up" class="col-md-2  control-label"><span class="text-danger">*</span>Status</label>
							<div class="col-md-8">		
								<?php 			
								$options = array(
									'0'	=> 'Inactive',
									'1'	=> 'Live',
									'2'	=> 'Previous',
									'3'	=> 'Unpublished',
								);
								
								echo form_dropdown('status', $options, $conference['up'] , array('class'=>'form-control')); ?>
								<span class="text-danger"><?php echo form_error('status');?></span>
							</div>
						</div>
						
						<div class="form-group">
							<div class="col-sm-offset-4 col-sm-8">
								<button type="submit" class="btn btn-success">Save</button>
							</div>
						</div>
						
					<?php echo form_close(); ?>                   
					
					
					
                  </div>
                </div>
              </div>
            </div>
          </div>


<script type="text/javascript">
$(document).ready(function(){
    /* Populate data to state dropdown */
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'<?php echo base_url('countries/getStates'); ?>',
                data:'country_id='+countryID,
                success:function(data){
                    $('#state').html('<option value="">Select State</option>'); 
                    var dataObj = jQuery.parseJSON(data);
                    if(dataObj){
                        $(dataObj).each(function(){
                            var option = $('<option />');
                            option.attr('value', this.id).text(this.name);           
                            $('#state').append(option);
                        });
                    }else{
                        $('#state').html('<option value="">State not available</option>');
                    }
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    /* Populate data to city dropdown */
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'<?php echo base_url('countries/getCities'); ?>',
                data:'state_id='+stateID,
                success:function(data){
                    $('#city').html('<option value="">Select City</option>'); 
                    var dataObj = jQuery.parseJSON(data);
                    if(dataObj){
                        $(dataObj).each(function(){
                            var option = $('<option />');
                            option.attr('value', this.id).text(this.name);           
                            $('#city').append(option);
                        });
                    }else{
                        $('#city').html('<option value="">City not available</option>');
                    }
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});
</script>