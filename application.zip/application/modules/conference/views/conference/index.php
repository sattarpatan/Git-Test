<div class="pull-right">
	<a href="<?php echo site_url('conference/add'); ?>" class="btn btn-success">Add</a> 
</div>

<table class="table table-striped table-bordered">
    <tr>
		<th>ID</th>
		<th>Up</th>
		<th>Is Completed</th>
		<th>Is New</th>
		<th>Is Exhibitor</th>
		<th>Show Sciprgm</th>
		<th>National Reg Url</th>
		<th>Keywords</th>
		<th>Near By Cities</th>
		<th>Preconfid</th>
		<th>Gacode</th>
		<th>Renowned</th>
		<th>Accredition</th>
		<th>Search Category</th>
		<th>Search Subject</th>
		<th>Search Region</th>
		<th>Search Country</th>
		<th>Search Month</th>
		<th>Search Year</th>
		<th>Created Date</th>
		<th>Updated-date</th>
		<th>Slug</th>
		<th>ShortName</th>
		<th>Title</th>
		<th>Maintitle</th>
		<th>Theme</th>
		<th>Conf Start Date</th>
		<th>Conf End Date</th>
		<th>Country</th>
		<th>State</th>
		<th>City</th>
		<th>Confvenue</th>
		<th>Venue</th>
		<th>Hvenue</th>
		<th>Dates</th>
		<th>ConfUrl</th>
		<th>Category</th>
		<th>Subject</th>
		<th>EmailId1</th>
		<th>EmailId2</th>
		<th>EmailId3</th>
		<th>JournalName1</th>
		<th>JournalName2</th>
		<th>JournalName3</th>
		<th>JournalName4</th>
		<th>JournalName5</th>
		<th>JournalShortName1</th>
		<th>JournalShortName2</th>
		<th>JournalShortName3</th>
		<th>JournalShortName4</th>
		<th>JournalShortName5</th>
		<th>JournalURL1</th>
		<th>JournalURL2</th>
		<th>JournalURL3</th>
		<th>JournalURL4</th>
		<th>JournalURL5</th>
		<th>ConfName1</th>
		<th>ConfName2</th>
		<th>ConfName3</th>
		<th>ConfName4</th>
		<th>ConfName5</th>
		<th>ConfShortName1</th>
		<th>ConfShortName2</th>
		<th>ConfShortName3</th>
		<th>ConfShortName4</th>
		<th>ConfShortName5</th>
		<th>ConfURL1</th>
		<th>ConfURL2</th>
		<th>ConfURL3</th>
		<th>ConfURL4</th>
		<th>ConfURL5</th>
		<th>WebUrl</th>
		<th>EarlyBird</th>
		<th>RegCloses</th>
		<th>FinalDate</th>
		<th>TracksCount</th>
		<th>SubTracksCount</th>
		<th>CancellationDate</th>
		<th>ResearchField</th>
		<th>AbstractSub</th>
		<th>Description</th>
		<th>Field</th>
		<th>Field2</th>
		<th>Date</th>
		<th>Highlights</th>
		<th>Past Conference</th>
		<th>Conference Gallery</th>
		<th>Proceedings</th>
		<th>Proceedings Current</th>
		<th>Continent</th>
		<th>Search Keywords</th>
		<th>Actions</th>
    </tr>
	<?php foreach($conference as $e){ ?>
    <tr>
		<td><?php echo $e['id']; ?></td>
		<td><?php echo $e['up']; ?></td>
		<td><?php echo $e['is_completed']; ?></td>
		<td><?php echo $e['is_new']; ?></td>
		<td><?php echo $e['is_exhibitor']; ?></td>
		<td><?php echo $e['show_sciprgm']; ?></td>
		<td><?php echo $e['national_reg_url']; ?></td>
		<td><?php echo $e['keywords']; ?></td>
		<td><?php echo $e['near_by_cities']; ?></td>
		<td><?php echo $e['preconfid']; ?></td>
		<td><?php echo $e['gacode']; ?></td>
		<td><?php echo $e['renowned']; ?></td>
		<td><?php echo $e['accredition']; ?></td>
		<td><?php echo $e['search_category']; ?></td>
		<td><?php echo $e['search_subject']; ?></td>
		<td><?php echo $e['search_region']; ?></td>
		<td><?php echo $e['search_country']; ?></td>
		<td><?php echo $e['search_month']; ?></td>
		<td><?php echo $e['search_year']; ?></td>
		<td><?php echo $e['created_date']; ?></td>
		<td><?php echo $e['updated-date']; ?></td>
		<td><?php echo $e['slug']; ?></td>
		<td><?php echo $e['ShortName']; ?></td>
		<td><?php echo $e['Title']; ?></td>
		<td><?php echo $e['maintitle']; ?></td>
		<td><?php echo $e['Theme']; ?></td>
		<td><?php echo $e['conf_start_date']; ?></td>
		<td><?php echo $e['conf_end_date']; ?></td>
		<td><?php echo $e['country']; ?></td>
		<td><?php echo $e['state']; ?></td>
		<td><?php echo $e['city']; ?></td>
		<td><?php echo $e['confvenue']; ?></td>
		<td><?php echo $e['venue']; ?></td>
		<td><?php echo $e['hvenue']; ?></td>
		<td><?php echo $e['Dates']; ?></td>
		<td><?php echo $e['ConfUrl']; ?></td>
		<td><?php echo $e['category']; ?></td>
		<td><?php echo $e['subject']; ?></td>
		<td><?php echo $e['EmailId1']; ?></td>
		<td><?php echo $e['EmailId2']; ?></td>
		<td><?php echo $e['EmailId3']; ?></td>
		<td><?php echo $e['JournalName1']; ?></td>
		<td><?php echo $e['JournalName2']; ?></td>
		<td><?php echo $e['JournalName3']; ?></td>
		<td><?php echo $e['JournalName4']; ?></td>
		<td><?php echo $e['JournalName5']; ?></td>
		<td><?php echo $e['JournalShortName1']; ?></td>
		<td><?php echo $e['JournalShortName2']; ?></td>
		<td><?php echo $e['JournalShortName3']; ?></td>
		<td><?php echo $e['JournalShortName4']; ?></td>
		<td><?php echo $e['JournalShortName5']; ?></td>
		<td><?php echo $e['JournalURL1']; ?></td>
		<td><?php echo $e['JournalURL2']; ?></td>
		<td><?php echo $e['JournalURL3']; ?></td>
		<td><?php echo $e['JournalURL4']; ?></td>
		<td><?php echo $e['JournalURL5']; ?></td>
		<td><?php echo $e['ConfName1']; ?></td>
		<td><?php echo $e['ConfName2']; ?></td>
		<td><?php echo $e['ConfName3']; ?></td>
		<td><?php echo $e['ConfName4']; ?></td>
		<td><?php echo $e['ConfName5']; ?></td>
		<td><?php echo $e['ConfShortName1']; ?></td>
		<td><?php echo $e['ConfShortName2']; ?></td>
		<td><?php echo $e['ConfShortName3']; ?></td>
		<td><?php echo $e['ConfShortName4']; ?></td>
		<td><?php echo $e['ConfShortName5']; ?></td>
		<td><?php echo $e['ConfURL1']; ?></td>
		<td><?php echo $e['ConfURL2']; ?></td>
		<td><?php echo $e['ConfURL3']; ?></td>
		<td><?php echo $e['ConfURL4']; ?></td>
		<td><?php echo $e['ConfURL5']; ?></td>
		<td><?php echo $e['WebUrl']; ?></td>
		<td><?php echo $e['EarlyBird']; ?></td>
		<td><?php echo $e['RegCloses']; ?></td>
		<td><?php echo $e['FinalDate']; ?></td>
		<td><?php echo $e['TracksCount']; ?></td>
		<td><?php echo $e['SubTracksCount']; ?></td>
		<td><?php echo $e['CancellationDate']; ?></td>
		<td><?php echo $e['ResearchField']; ?></td>
		<td><?php echo $e['AbstractSub']; ?></td>
		<td><?php echo $e['description']; ?></td>
		<td><?php echo $e['field']; ?></td>
		<td><?php echo $e['field2']; ?></td>
		<td><?php echo $e['date']; ?></td>
		<td><?php echo $e['highlights']; ?></td>
		<td><?php echo $e['past_conference']; ?></td>
		<td><?php echo $e['conference_gallery']; ?></td>
		<td><?php echo $e['proceedings']; ?></td>
		<td><?php echo $e['proceedings_current']; ?></td>
		<td><?php echo $e['continent']; ?></td>
		<td><?php echo $e['search_keywords']; ?></td>
		<td>
            <a href="<?php echo site_url('conference/edit/'.$e['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('conference/remove/'.$e['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
</table>
<div class="pull-right">
    <?php echo $this->pagination->create_links(); ?>    
</div>
