<?php echo form_open('conference/edit/'.$editconference['id'],array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="up" class="col-md-4 control-label"><span class="text-danger">*</span>Up</label>
		<div class="col-md-8">
			<input type="checkbox" name="up" value="1" <?php echo ($editconference['up']==1 ? 'checked="checked"' : ''); ?> id='up' />
			<span class="text-danger"><?php echo form_error('up');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="is_completed" class="col-md-4 control-label"><span class="text-danger">*</span>Is Completed</label>
		<div class="col-md-8">
			<input type="text" name="is_completed" value="<?php echo ($this->input->post('is_completed') ? $this->input->post('is_completed') : $editconference['is_completed']); ?>" class="form-control" id="is_completed" />
			<span class="text-danger"><?php echo form_error('is_completed');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="is_new" class="col-md-4 control-label"><span class="text-danger">*</span>Is New</label>
		<div class="col-md-8">
			<input type="text" name="is_new" value="<?php echo ($this->input->post('is_new') ? $this->input->post('is_new') : $editconference['is_new']); ?>" class="form-control" id="is_new" />
			<span class="text-danger"><?php echo form_error('is_new');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="is_exhibitor" class="col-md-4 control-label"><span class="text-danger">*</span>Is Exhibitor</label>
		<div class="col-md-8">
			<input type="text" name="is_exhibitor" value="<?php echo ($this->input->post('is_exhibitor') ? $this->input->post('is_exhibitor') : $editconference['is_exhibitor']); ?>" class="form-control" id="is_exhibitor" />
			<span class="text-danger"><?php echo form_error('is_exhibitor');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="show_sciprgm" class="col-md-4 control-label"><span class="text-danger">*</span>Show Sciprgm</label>
		<div class="col-md-8">
			<input type="text" name="show_sciprgm" value="<?php echo ($this->input->post('show_sciprgm') ? $this->input->post('show_sciprgm') : $editconference['show_sciprgm']); ?>" class="form-control" id="show_sciprgm" />
			<span class="text-danger"><?php echo form_error('show_sciprgm');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="national_reg_url" class="col-md-4 control-label"><span class="text-danger">*</span>National Reg Url</label>
		<div class="col-md-8">
			<input type="text" name="national_reg_url" value="<?php echo ($this->input->post('national_reg_url') ? $this->input->post('national_reg_url') : $editconference['national_reg_url']); ?>" class="form-control" id="national_reg_url" />
			<span class="text-danger"><?php echo form_error('national_reg_url');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="keywords" class="col-md-4 control-label"><span class="text-danger">*</span>Keywords</label>
		<div class="col-md-8">
			<input type="text" name="keywords" value="<?php echo ($this->input->post('keywords') ? $this->input->post('keywords') : $editconference['keywords']); ?>" class="form-control" id="keywords" />
			<span class="text-danger"><?php echo form_error('keywords');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="near_by_cities" class="col-md-4 control-label"><span class="text-danger">*</span>Near By Cities</label>
		<div class="col-md-8">
			<input type="text" name="near_by_cities" value="<?php echo ($this->input->post('near_by_cities') ? $this->input->post('near_by_cities') : $editconference['near_by_cities']); ?>" class="form-control" id="near_by_cities" />
			<span class="text-danger"><?php echo form_error('near_by_cities');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="preconfid" class="col-md-4 control-label"><span class="text-danger">*</span>Preconfid</label>
		<div class="col-md-8">
			<input type="text" name="preconfid" value="<?php echo ($this->input->post('preconfid') ? $this->input->post('preconfid') : $editconference['preconfid']); ?>" class="form-control" id="preconfid" />
			<span class="text-danger"><?php echo form_error('preconfid');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="gacode" class="col-md-4 control-label"><span class="text-danger">*</span>Gacode</label>
		<div class="col-md-8">
			<input type="text" name="gacode" value="<?php echo ($this->input->post('gacode') ? $this->input->post('gacode') : $editconference['gacode']); ?>" class="form-control" id="gacode" />
			<span class="text-danger"><?php echo form_error('gacode');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="renowned" class="col-md-4 control-label"><span class="text-danger">*</span>Renowned</label>
		<div class="col-md-8">
			<input type="text" name="renowned" value="<?php echo ($this->input->post('renowned') ? $this->input->post('renowned') : $editconference['renowned']); ?>" class="form-control" id="renowned" />
			<span class="text-danger"><?php echo form_error('renowned');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="accredition" class="col-md-4 control-label"><span class="text-danger">*</span>Accredition</label>
		<div class="col-md-8">
			<input type="text" name="accredition" value="<?php echo ($this->input->post('accredition') ? $this->input->post('accredition') : $editconference['accredition']); ?>" class="form-control" id="accredition" />
			<span class="text-danger"><?php echo form_error('accredition');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_category" class="col-md-4 control-label"><span class="text-danger">*</span>Search Category</label>
		<div class="col-md-8">
			<input type="text" name="search_category" value="<?php echo ($this->input->post('search_category') ? $this->input->post('search_category') : $editconference['search_category']); ?>" class="form-control" id="search_category" />
			<span class="text-danger"><?php echo form_error('search_category');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_subject" class="col-md-4 control-label"><span class="text-danger">*</span>Search Subject</label>
		<div class="col-md-8">
			<input type="text" name="search_subject" value="<?php echo ($this->input->post('search_subject') ? $this->input->post('search_subject') : $editconference['search_subject']); ?>" class="form-control" id="search_subject" />
			<span class="text-danger"><?php echo form_error('search_subject');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_region" class="col-md-4 control-label"><span class="text-danger">*</span>Search Region</label>
		<div class="col-md-8">
			<input type="text" name="search_region" value="<?php echo ($this->input->post('search_region') ? $this->input->post('search_region') : $editconference['search_region']); ?>" class="form-control" id="search_region" />
			<span class="text-danger"><?php echo form_error('search_region');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_country" class="col-md-4 control-label"><span class="text-danger">*</span>Search Country</label>
		<div class="col-md-8">
			<input type="text" name="search_country" value="<?php echo ($this->input->post('search_country') ? $this->input->post('search_country') : $editconference['search_country']); ?>" class="form-control" id="search_country" />
			<span class="text-danger"><?php echo form_error('search_country');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_month" class="col-md-4 control-label"><span class="text-danger">*</span>Search Month</label>
		<div class="col-md-8">
			<input type="text" name="search_month" value="<?php echo ($this->input->post('search_month') ? $this->input->post('search_month') : $editconference['search_month']); ?>" class="form-control" id="search_month" />
			<span class="text-danger"><?php echo form_error('search_month');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_year" class="col-md-4 control-label"><span class="text-danger">*</span>Search Year</label>
		<div class="col-md-8">
			<input type="text" name="search_year" value="<?php echo ($this->input->post('search_year') ? $this->input->post('search_year') : $editconference['search_year']); ?>" class="form-control" id="search_year" />
			<span class="text-danger"><?php echo form_error('search_year');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="created_date" class="col-md-4 control-label"><span class="text-danger">*</span>Created Date</label>
		<div class="col-md-8">
			<input type="text" name="created_date" value="<?php echo ($this->input->post('created_date') ? $this->input->post('created_date') : $editconference['created_date']); ?>" class="form-control" id="created_date" />
			<span class="text-danger"><?php echo form_error('created_date');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="updated-date" class="col-md-4 control-label"><span class="text-danger">*</span>Updated-date</label>
		<div class="col-md-8">
			<input type="text" name="updated-date" value="<?php echo ($this->input->post('updated-date') ? $this->input->post('updated-date') : $editconference['updated-date']); ?>" class="form-control" id="updated-date" />
			<span class="text-danger"><?php echo form_error('updated-date');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="slug" class="col-md-4 control-label"><span class="text-danger">*</span>Slug</label>
		<div class="col-md-8">
			<input type="text" name="slug" value="<?php echo ($this->input->post('slug') ? $this->input->post('slug') : $editconference['slug']); ?>" class="form-control" id="slug" />
			<span class="text-danger"><?php echo form_error('slug');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ShortName" class="col-md-4 control-label">ShortName</label>
		<div class="col-md-8">
			<input type="text" name="ShortName" value="<?php echo ($this->input->post('ShortName') ? $this->input->post('ShortName') : $editconference['ShortName']); ?>" class="form-control" id="ShortName" />
			<span class="text-danger"><?php echo form_error('ShortName');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="Title" class="col-md-4 control-label">Title</label>
		<div class="col-md-8">
			<input type="text" name="Title" value="<?php echo ($this->input->post('Title') ? $this->input->post('Title') : $editconference['Title']); ?>" class="form-control" id="Title" />
			<span class="text-danger"><?php echo form_error('Title');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="maintitle" class="col-md-4 control-label"><span class="text-danger">*</span>Maintitle</label>
		<div class="col-md-8">
			<input type="text" name="maintitle" value="<?php echo ($this->input->post('maintitle') ? $this->input->post('maintitle') : $editconference['maintitle']); ?>" class="form-control" id="maintitle" />
			<span class="text-danger"><?php echo form_error('maintitle');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="Theme" class="col-md-4 control-label">Theme</label>
		<div class="col-md-8">
			<input type="text" name="Theme" value="<?php echo ($this->input->post('Theme') ? $this->input->post('Theme') : $editconference['Theme']); ?>" class="form-control" id="Theme" />
			<span class="text-danger"><?php echo form_error('Theme');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="conf_start_date" class="col-md-4 control-label"><span class="text-danger">*</span>Conf Start Date</label>
		<div class="col-md-8">
			<input type="text" name="conf_start_date" value="<?php echo ($this->input->post('conf_start_date') ? $this->input->post('conf_start_date') : $editconference['conf_start_date']); ?>" class="form-control" id="conf_start_date" />
			<span class="text-danger"><?php echo form_error('conf_start_date');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="conf_end_date" class="col-md-4 control-label"><span class="text-danger">*</span>Conf End Date</label>
		<div class="col-md-8">
			<input type="text" name="conf_end_date" value="<?php echo ($this->input->post('conf_end_date') ? $this->input->post('conf_end_date') : $editconference['conf_end_date']); ?>" class="form-control" id="conf_end_date" />
			<span class="text-danger"><?php echo form_error('conf_end_date');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="country" class="col-md-4 control-label"><span class="text-danger">*</span>Country</label>
		<div class="col-md-8">
			<input type="text" name="country" value="<?php echo ($this->input->post('country') ? $this->input->post('country') : $editconference['country']); ?>" class="form-control" id="country" />
			<span class="text-danger"><?php echo form_error('country');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="state" class="col-md-4 control-label"><span class="text-danger">*</span>State</label>
		<div class="col-md-8">
			<input type="text" name="state" value="<?php echo ($this->input->post('state') ? $this->input->post('state') : $editconference['state']); ?>" class="form-control" id="state" />
			<span class="text-danger"><?php echo form_error('state');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="city" class="col-md-4 control-label"><span class="text-danger">*</span>City</label>
		<div class="col-md-8">
			<input type="text" name="city" value="<?php echo ($this->input->post('city') ? $this->input->post('city') : $editconference['city']); ?>" class="form-control" id="city" />
			<span class="text-danger"><?php echo form_error('city');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="confvenue" class="col-md-4 control-label"><span class="text-danger">*</span>Confvenue</label>
		<div class="col-md-8">
			<input type="text" name="confvenue" value="<?php echo ($this->input->post('confvenue') ? $this->input->post('confvenue') : $editconference['confvenue']); ?>" class="form-control" id="confvenue" />
			<span class="text-danger"><?php echo form_error('confvenue');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="venue" class="col-md-4 control-label">Venue</label>
		<div class="col-md-8">
			<input type="text" name="venue" value="<?php echo ($this->input->post('venue') ? $this->input->post('venue') : $editconference['venue']); ?>" class="form-control" id="venue" />
			<span class="text-danger"><?php echo form_error('venue');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="hvenue" class="col-md-4 control-label"><span class="text-danger">*</span>Hvenue</label>
		<div class="col-md-8">
			<input type="text" name="hvenue" value="<?php echo ($this->input->post('hvenue') ? $this->input->post('hvenue') : $editconference['hvenue']); ?>" class="form-control" id="hvenue" />
			<span class="text-danger"><?php echo form_error('hvenue');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="Dates" class="col-md-4 control-label">Dates</label>
		<div class="col-md-8">
			<input type="text" name="Dates" value="<?php echo ($this->input->post('Dates') ? $this->input->post('Dates') : $editconference['Dates']); ?>" class="form-control" id="Dates" />
			<span class="text-danger"><?php echo form_error('Dates');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfUrl" class="col-md-4 control-label"><span class="text-danger">*</span>ConfUrl</label>
		<div class="col-md-8">
			<input type="text" name="ConfUrl" value="<?php echo ($this->input->post('ConfUrl') ? $this->input->post('ConfUrl') : $editconference['ConfUrl']); ?>" class="form-control" id="ConfUrl" />
			<span class="text-danger"><?php echo form_error('ConfUrl');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="category" class="col-md-4 control-label"><span class="text-danger">*</span>Category</label>
		<div class="col-md-8">
			<input type="text" name="category" value="<?php echo ($this->input->post('category') ? $this->input->post('category') : $editconference['category']); ?>" class="form-control" id="category" />
			<span class="text-danger"><?php echo form_error('category');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="subject" class="col-md-4 control-label"><span class="text-danger">*</span>Subject</label>
		<div class="col-md-8">
			<input type="text" name="subject" value="<?php echo ($this->input->post('subject') ? $this->input->post('subject') : $editconference['subject']); ?>" class="form-control" id="subject" />
			<span class="text-danger"><?php echo form_error('subject');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="EmailId1" class="col-md-4 control-label"><span class="text-danger">*</span>EmailId1</label>
		<div class="col-md-8">
			<input type="text" name="EmailId1" value="<?php echo ($this->input->post('EmailId1') ? $this->input->post('EmailId1') : $editconference['EmailId1']); ?>" class="form-control" id="EmailId1" />
			<span class="text-danger"><?php echo form_error('EmailId1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="EmailId2" class="col-md-4 control-label"><span class="text-danger">*</span>EmailId2</label>
		<div class="col-md-8">
			<input type="text" name="EmailId2" value="<?php echo ($this->input->post('EmailId2') ? $this->input->post('EmailId2') : $editconference['EmailId2']); ?>" class="form-control" id="EmailId2" />
			<span class="text-danger"><?php echo form_error('EmailId2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="EmailId3" class="col-md-4 control-label"><span class="text-danger">*</span>EmailId3</label>
		<div class="col-md-8">
			<input type="text" name="EmailId3" value="<?php echo ($this->input->post('EmailId3') ? $this->input->post('EmailId3') : $editconference['EmailId3']); ?>" class="form-control" id="EmailId3" />
			<span class="text-danger"><?php echo form_error('EmailId3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalName1" class="col-md-4 control-label"><span class="text-danger">*</span>JournalName1</label>
		<div class="col-md-8">
			<input type="text" name="JournalName1" value="<?php echo ($this->input->post('JournalName1') ? $this->input->post('JournalName1') : $editconference['JournalName1']); ?>" class="form-control" id="JournalName1" />
			<span class="text-danger"><?php echo form_error('JournalName1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalName2" class="col-md-4 control-label"><span class="text-danger">*</span>JournalName2</label>
		<div class="col-md-8">
			<input type="text" name="JournalName2" value="<?php echo ($this->input->post('JournalName2') ? $this->input->post('JournalName2') : $editconference['JournalName2']); ?>" class="form-control" id="JournalName2" />
			<span class="text-danger"><?php echo form_error('JournalName2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalName3" class="col-md-4 control-label"><span class="text-danger">*</span>JournalName3</label>
		<div class="col-md-8">
			<input type="text" name="JournalName3" value="<?php echo ($this->input->post('JournalName3') ? $this->input->post('JournalName3') : $editconference['JournalName3']); ?>" class="form-control" id="JournalName3" />
			<span class="text-danger"><?php echo form_error('JournalName3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalName4" class="col-md-4 control-label"><span class="text-danger">*</span>JournalName4</label>
		<div class="col-md-8">
			<input type="text" name="JournalName4" value="<?php echo ($this->input->post('JournalName4') ? $this->input->post('JournalName4') : $editconference['JournalName4']); ?>" class="form-control" id="JournalName4" />
			<span class="text-danger"><?php echo form_error('JournalName4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalName5" class="col-md-4 control-label"><span class="text-danger">*</span>JournalName5</label>
		<div class="col-md-8">
			<input type="text" name="JournalName5" value="<?php echo ($this->input->post('JournalName5') ? $this->input->post('JournalName5') : $editconference['JournalName5']); ?>" class="form-control" id="JournalName5" />
			<span class="text-danger"><?php echo form_error('JournalName5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalShortName1" class="col-md-4 control-label"><span class="text-danger">*</span>JournalShortName1</label>
		<div class="col-md-8">
			<input type="text" name="JournalShortName1" value="<?php echo ($this->input->post('JournalShortName1') ? $this->input->post('JournalShortName1') : $editconference['JournalShortName1']); ?>" class="form-control" id="JournalShortName1" />
			<span class="text-danger"><?php echo form_error('JournalShortName1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalShortName2" class="col-md-4 control-label"><span class="text-danger">*</span>JournalShortName2</label>
		<div class="col-md-8">
			<input type="text" name="JournalShortName2" value="<?php echo ($this->input->post('JournalShortName2') ? $this->input->post('JournalShortName2') : $editconference['JournalShortName2']); ?>" class="form-control" id="JournalShortName2" />
			<span class="text-danger"><?php echo form_error('JournalShortName2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalShortName3" class="col-md-4 control-label"><span class="text-danger">*</span>JournalShortName3</label>
		<div class="col-md-8">
			<input type="text" name="JournalShortName3" value="<?php echo ($this->input->post('JournalShortName3') ? $this->input->post('JournalShortName3') : $editconference['JournalShortName3']); ?>" class="form-control" id="JournalShortName3" />
			<span class="text-danger"><?php echo form_error('JournalShortName3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalShortName4" class="col-md-4 control-label"><span class="text-danger">*</span>JournalShortName4</label>
		<div class="col-md-8">
			<input type="text" name="JournalShortName4" value="<?php echo ($this->input->post('JournalShortName4') ? $this->input->post('JournalShortName4') : $editconference['JournalShortName4']); ?>" class="form-control" id="JournalShortName4" />
			<span class="text-danger"><?php echo form_error('JournalShortName4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalShortName5" class="col-md-4 control-label"><span class="text-danger">*</span>JournalShortName5</label>
		<div class="col-md-8">
			<input type="text" name="JournalShortName5" value="<?php echo ($this->input->post('JournalShortName5') ? $this->input->post('JournalShortName5') : $editconference['JournalShortName5']); ?>" class="form-control" id="JournalShortName5" />
			<span class="text-danger"><?php echo form_error('JournalShortName5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalURL1" class="col-md-4 control-label"><span class="text-danger">*</span>JournalURL1</label>
		<div class="col-md-8">
			<input type="text" name="JournalURL1" value="<?php echo ($this->input->post('JournalURL1') ? $this->input->post('JournalURL1') : $editconference['JournalURL1']); ?>" class="form-control" id="JournalURL1" />
			<span class="text-danger"><?php echo form_error('JournalURL1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalURL2" class="col-md-4 control-label"><span class="text-danger">*</span>JournalURL2</label>
		<div class="col-md-8">
			<input type="text" name="JournalURL2" value="<?php echo ($this->input->post('JournalURL2') ? $this->input->post('JournalURL2') : $editconference['JournalURL2']); ?>" class="form-control" id="JournalURL2" />
			<span class="text-danger"><?php echo form_error('JournalURL2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalURL3" class="col-md-4 control-label"><span class="text-danger">*</span>JournalURL3</label>
		<div class="col-md-8">
			<input type="text" name="JournalURL3" value="<?php echo ($this->input->post('JournalURL3') ? $this->input->post('JournalURL3') : $editconference['JournalURL3']); ?>" class="form-control" id="JournalURL3" />
			<span class="text-danger"><?php echo form_error('JournalURL3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalURL4" class="col-md-4 control-label"><span class="text-danger">*</span>JournalURL4</label>
		<div class="col-md-8">
			<input type="text" name="JournalURL4" value="<?php echo ($this->input->post('JournalURL4') ? $this->input->post('JournalURL4') : $editconference['JournalURL4']); ?>" class="form-control" id="JournalURL4" />
			<span class="text-danger"><?php echo form_error('JournalURL4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="JournalURL5" class="col-md-4 control-label"><span class="text-danger">*</span>JournalURL5</label>
		<div class="col-md-8">
			<input type="text" name="JournalURL5" value="<?php echo ($this->input->post('JournalURL5') ? $this->input->post('JournalURL5') : $editconference['JournalURL5']); ?>" class="form-control" id="JournalURL5" />
			<span class="text-danger"><?php echo form_error('JournalURL5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfName1" class="col-md-4 control-label"><span class="text-danger">*</span>ConfName1</label>
		<div class="col-md-8">
			<input type="text" name="ConfName1" value="<?php echo ($this->input->post('ConfName1') ? $this->input->post('ConfName1') : $editconference['ConfName1']); ?>" class="form-control" id="ConfName1" />
			<span class="text-danger"><?php echo form_error('ConfName1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfName2" class="col-md-4 control-label"><span class="text-danger">*</span>ConfName2</label>
		<div class="col-md-8">
			<input type="text" name="ConfName2" value="<?php echo ($this->input->post('ConfName2') ? $this->input->post('ConfName2') : $editconference['ConfName2']); ?>" class="form-control" id="ConfName2" />
			<span class="text-danger"><?php echo form_error('ConfName2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfName3" class="col-md-4 control-label"><span class="text-danger">*</span>ConfName3</label>
		<div class="col-md-8">
			<input type="text" name="ConfName3" value="<?php echo ($this->input->post('ConfName3') ? $this->input->post('ConfName3') : $editconference['ConfName3']); ?>" class="form-control" id="ConfName3" />
			<span class="text-danger"><?php echo form_error('ConfName3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfName4" class="col-md-4 control-label"><span class="text-danger">*</span>ConfName4</label>
		<div class="col-md-8">
			<input type="text" name="ConfName4" value="<?php echo ($this->input->post('ConfName4') ? $this->input->post('ConfName4') : $editconference['ConfName4']); ?>" class="form-control" id="ConfName4" />
			<span class="text-danger"><?php echo form_error('ConfName4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfName5" class="col-md-4 control-label"><span class="text-danger">*</span>ConfName5</label>
		<div class="col-md-8">
			<input type="text" name="ConfName5" value="<?php echo ($this->input->post('ConfName5') ? $this->input->post('ConfName5') : $editconference['ConfName5']); ?>" class="form-control" id="ConfName5" />
			<span class="text-danger"><?php echo form_error('ConfName5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfShortName1" class="col-md-4 control-label"><span class="text-danger">*</span>ConfShortName1</label>
		<div class="col-md-8">
			<input type="text" name="ConfShortName1" value="<?php echo ($this->input->post('ConfShortName1') ? $this->input->post('ConfShortName1') : $editconference['ConfShortName1']); ?>" class="form-control" id="ConfShortName1" />
			<span class="text-danger"><?php echo form_error('ConfShortName1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfShortName2" class="col-md-4 control-label"><span class="text-danger">*</span>ConfShortName2</label>
		<div class="col-md-8">
			<input type="text" name="ConfShortName2" value="<?php echo ($this->input->post('ConfShortName2') ? $this->input->post('ConfShortName2') : $editconference['ConfShortName2']); ?>" class="form-control" id="ConfShortName2" />
			<span class="text-danger"><?php echo form_error('ConfShortName2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfShortName3" class="col-md-4 control-label"><span class="text-danger">*</span>ConfShortName3</label>
		<div class="col-md-8">
			<input type="text" name="ConfShortName3" value="<?php echo ($this->input->post('ConfShortName3') ? $this->input->post('ConfShortName3') : $editconference['ConfShortName3']); ?>" class="form-control" id="ConfShortName3" />
			<span class="text-danger"><?php echo form_error('ConfShortName3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfShortName4" class="col-md-4 control-label"><span class="text-danger">*</span>ConfShortName4</label>
		<div class="col-md-8">
			<input type="text" name="ConfShortName4" value="<?php echo ($this->input->post('ConfShortName4') ? $this->input->post('ConfShortName4') : $editconference['ConfShortName4']); ?>" class="form-control" id="ConfShortName4" />
			<span class="text-danger"><?php echo form_error('ConfShortName4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfShortName5" class="col-md-4 control-label"><span class="text-danger">*</span>ConfShortName5</label>
		<div class="col-md-8">
			<input type="text" name="ConfShortName5" value="<?php echo ($this->input->post('ConfShortName5') ? $this->input->post('ConfShortName5') : $editconference['ConfShortName5']); ?>" class="form-control" id="ConfShortName5" />
			<span class="text-danger"><?php echo form_error('ConfShortName5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfURL1" class="col-md-4 control-label"><span class="text-danger">*</span>ConfURL1</label>
		<div class="col-md-8">
			<input type="text" name="ConfURL1" value="<?php echo ($this->input->post('ConfURL1') ? $this->input->post('ConfURL1') : $editconference['ConfURL1']); ?>" class="form-control" id="ConfURL1" />
			<span class="text-danger"><?php echo form_error('ConfURL1');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfURL2" class="col-md-4 control-label"><span class="text-danger">*</span>ConfURL2</label>
		<div class="col-md-8">
			<input type="text" name="ConfURL2" value="<?php echo ($this->input->post('ConfURL2') ? $this->input->post('ConfURL2') : $editconference['ConfURL2']); ?>" class="form-control" id="ConfURL2" />
			<span class="text-danger"><?php echo form_error('ConfURL2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfURL3" class="col-md-4 control-label"><span class="text-danger">*</span>ConfURL3</label>
		<div class="col-md-8">
			<input type="text" name="ConfURL3" value="<?php echo ($this->input->post('ConfURL3') ? $this->input->post('ConfURL3') : $editconference['ConfURL3']); ?>" class="form-control" id="ConfURL3" />
			<span class="text-danger"><?php echo form_error('ConfURL3');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfURL4" class="col-md-4 control-label"><span class="text-danger">*</span>ConfURL4</label>
		<div class="col-md-8">
			<input type="text" name="ConfURL4" value="<?php echo ($this->input->post('ConfURL4') ? $this->input->post('ConfURL4') : $editconference['ConfURL4']); ?>" class="form-control" id="ConfURL4" />
			<span class="text-danger"><?php echo form_error('ConfURL4');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ConfURL5" class="col-md-4 control-label"><span class="text-danger">*</span>ConfURL5</label>
		<div class="col-md-8">
			<input type="text" name="ConfURL5" value="<?php echo ($this->input->post('ConfURL5') ? $this->input->post('ConfURL5') : $editconference['ConfURL5']); ?>" class="form-control" id="ConfURL5" />
			<span class="text-danger"><?php echo form_error('ConfURL5');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="WebUrl" class="col-md-4 control-label"><span class="text-danger">*</span>WebUrl</label>
		<div class="col-md-8">
			<input type="text" name="WebUrl" value="<?php echo ($this->input->post('WebUrl') ? $this->input->post('WebUrl') : $editconference['WebUrl']); ?>" class="form-control" id="WebUrl" />
			<span class="text-danger"><?php echo form_error('WebUrl');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="EarlyBird" class="col-md-4 control-label"><span class="text-danger">*</span>EarlyBird</label>
		<div class="col-md-8">
			<input type="text" name="EarlyBird" value="<?php echo ($this->input->post('EarlyBird') ? $this->input->post('EarlyBird') : $editconference['EarlyBird']); ?>" class="form-control" id="EarlyBird" />
			<span class="text-danger"><?php echo form_error('EarlyBird');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="RegCloses" class="col-md-4 control-label"><span class="text-danger">*</span>RegCloses</label>
		<div class="col-md-8">
			<input type="text" name="RegCloses" value="<?php echo ($this->input->post('RegCloses') ? $this->input->post('RegCloses') : $editconference['RegCloses']); ?>" class="form-control" id="RegCloses" />
			<span class="text-danger"><?php echo form_error('RegCloses');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="FinalDate" class="col-md-4 control-label"><span class="text-danger">*</span>FinalDate</label>
		<div class="col-md-8">
			<input type="text" name="FinalDate" value="<?php echo ($this->input->post('FinalDate') ? $this->input->post('FinalDate') : $editconference['FinalDate']); ?>" class="form-control" id="FinalDate" />
			<span class="text-danger"><?php echo form_error('FinalDate');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="TracksCount" class="col-md-4 control-label"><span class="text-danger">*</span>TracksCount</label>
		<div class="col-md-8">
			<input type="text" name="TracksCount" value="<?php echo ($this->input->post('TracksCount') ? $this->input->post('TracksCount') : $editconference['TracksCount']); ?>" class="form-control" id="TracksCount" />
			<span class="text-danger"><?php echo form_error('TracksCount');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="SubTracksCount" class="col-md-4 control-label"><span class="text-danger">*</span>SubTracksCount</label>
		<div class="col-md-8">
			<input type="text" name="SubTracksCount" value="<?php echo ($this->input->post('SubTracksCount') ? $this->input->post('SubTracksCount') : $editconference['SubTracksCount']); ?>" class="form-control" id="SubTracksCount" />
			<span class="text-danger"><?php echo form_error('SubTracksCount');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="CancellationDate" class="col-md-4 control-label"><span class="text-danger">*</span>CancellationDate</label>
		<div class="col-md-8">
			<input type="text" name="CancellationDate" value="<?php echo ($this->input->post('CancellationDate') ? $this->input->post('CancellationDate') : $editconference['CancellationDate']); ?>" class="form-control" id="CancellationDate" />
			<span class="text-danger"><?php echo form_error('CancellationDate');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="ResearchField" class="col-md-4 control-label"><span class="text-danger">*</span>ResearchField</label>
		<div class="col-md-8">
			<input type="text" name="ResearchField" value="<?php echo ($this->input->post('ResearchField') ? $this->input->post('ResearchField') : $editconference['ResearchField']); ?>" class="form-control" id="ResearchField" />
			<span class="text-danger"><?php echo form_error('ResearchField');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="AbstractSub" class="col-md-4 control-label"><span class="text-danger">*</span>AbstractSub</label>
		<div class="col-md-8">
			<input type="text" name="AbstractSub" value="<?php echo ($this->input->post('AbstractSub') ? $this->input->post('AbstractSub') : $editconference['AbstractSub']); ?>" class="form-control" id="AbstractSub" />
			<span class="text-danger"><?php echo form_error('AbstractSub');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="description" class="col-md-4 control-label"><span class="text-danger">*</span>Description</label>
		<div class="col-md-8">
			<input type="text" name="description" value="<?php echo ($this->input->post('description') ? $this->input->post('description') : $editconference['description']); ?>" class="form-control" id="description" />
			<span class="text-danger"><?php echo form_error('description');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="field" class="col-md-4 control-label">Field</label>
		<div class="col-md-8">
			<input type="text" name="field" value="<?php echo ($this->input->post('field') ? $this->input->post('field') : $editconference['field']); ?>" class="form-control" id="field" />
		</div>
	</div>
	<div class="form-group">
		<label for="field2" class="col-md-4 control-label"><span class="text-danger">*</span>Field2</label>
		<div class="col-md-8">
			<input type="text" name="field2" value="<?php echo ($this->input->post('field2') ? $this->input->post('field2') : $editconference['field2']); ?>" class="form-control" id="field2" />
			<span class="text-danger"><?php echo form_error('field2');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="date" class="col-md-4 control-label"><span class="text-danger">*</span>Date</label>
		<div class="col-md-8">
			<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $editconference['date']); ?>" class="form-control" id="date" />
			<span class="text-danger"><?php echo form_error('date');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="highlights" class="col-md-4 control-label"><span class="text-danger">*</span>Highlights</label>
		<div class="col-md-8">
			<input type="text" name="highlights" value="<?php echo ($this->input->post('highlights') ? $this->input->post('highlights') : $editconference['highlights']); ?>" class="form-control" id="highlights" />
			<span class="text-danger"><?php echo form_error('highlights');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="past_conference" class="col-md-4 control-label"><span class="text-danger">*</span>Past Conference</label>
		<div class="col-md-8">
			<input type="text" name="past_conference" value="<?php echo ($this->input->post('past_conference') ? $this->input->post('past_conference') : $editconference['past_conference']); ?>" class="form-control" id="past_conference" />
			<span class="text-danger"><?php echo form_error('past_conference');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="conference_gallery" class="col-md-4 control-label"><span class="text-danger">*</span>Conference Gallery</label>
		<div class="col-md-8">
			<input type="text" name="conference_gallery" value="<?php echo ($this->input->post('conference_gallery') ? $this->input->post('conference_gallery') : $editconference['conference_gallery']); ?>" class="form-control" id="conference_gallery" />
			<span class="text-danger"><?php echo form_error('conference_gallery');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="proceedings" class="col-md-4 control-label"><span class="text-danger">*</span>Proceedings</label>
		<div class="col-md-8">
			<input type="text" name="proceedings" value="<?php echo ($this->input->post('proceedings') ? $this->input->post('proceedings') : $editconference['proceedings']); ?>" class="form-control" id="proceedings" />
			<span class="text-danger"><?php echo form_error('proceedings');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="proceedings_current" class="col-md-4 control-label"><span class="text-danger">*</span>Proceedings Current</label>
		<div class="col-md-8">
			<input type="text" name="proceedings_current" value="<?php echo ($this->input->post('proceedings_current') ? $this->input->post('proceedings_current') : $editconference['proceedings_current']); ?>" class="form-control" id="proceedings_current" />
			<span class="text-danger"><?php echo form_error('proceedings_current');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="continent" class="col-md-4 control-label"><span class="text-danger">*</span>Continent</label>
		<div class="col-md-8">
			<textarea name="continent" class="form-control" id="continent"><?php echo ($this->input->post('continent') ? $this->input->post('continent') : $editconference['continent']); ?></textarea>
			<span class="text-danger"><?php echo form_error('continent');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="search_keywords" class="col-md-4 control-label"><span class="text-danger">*</span>Search Keywords</label>
		<div class="col-md-8">
			<textarea name="search_keywords" class="form-control" id="search_keywords"><?php echo ($this->input->post('search_keywords') ? $this->input->post('search_keywords') : $editconference['search_keywords']); ?></textarea>
			<span class="text-danger"><?php echo form_error('search_keywords');?></span>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
<?php echo form_close(); ?>