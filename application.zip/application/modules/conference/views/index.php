		  <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Users <small>Some examples to get you started</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Default Example <small>Users</small></h2>
                    <div class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="<?php echo site_url('conference/add');?>"><i class="fa fa-plus"></i> ADD</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30 align-right">
                      DataTables has most features enabled by default, so all you need to do to use it with your own tables is to call the construction function: <code>$().DataTable();</code>
                    </p>
                    
					<table id="datatable" class="table table-striped table-bordered">
						<thead>
						<tr>
							<th>ID</th>
							<th>Status</th>
							<th>Created Date</th>
							<th>ConfSlug</th>
							<th>ShortName</th>
							<th>Title</th>
							<th>Maintitle</th>
							<th>Conf Start Date</th>
							<th>Conf End Date</th>
							<th>Country</th>
							<th>State</th>
							<th>City</th>
							<th>ConfUrl</th>
							<th>Category</th>
							<th>Subject</th>
							<th>Actions</th>
						</tr>
						</thead>
						<tbody>
						<?php foreach($conference as $e){ ?>
						<tr>
							<td><?php echo $e['id']; ?></td>
							<td><?php echo $e['up']; ?></td>
							<td><?php echo $e['created_date']; ?></td>
							<td><?php echo $e['slug']; ?></td>
							<td><?php echo $e['ShortName']; ?></td>
							<td><?php echo $e['Title']; ?></td>
							<td><?php echo $e['maintitle']; ?></td>
							<td><?php echo $e['conf_start_date']; ?></td>
							<td><?php echo $e['conf_end_date']; ?></td>
							<td><?php echo $e['country']; ?></td>
							<td><?php echo $e['state']; ?></td>
							<td><?php echo $e['city']; ?></td>
							<td><?php echo $e['ConfUrl']; ?></td>
							<td><?php echo $e['category']; ?></td>
							<td><?php echo $e['subject']; ?></td>
							<td>
								<a href="<?php echo site_url('conference/edit/'.$e['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
								<a href="<?php echo site_url('conference/remove/'.$e['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
							</td>
						</tr>
						<?php } ?>
						</tbody>
					</table>
					
                  </div>
                </div>
              </div>
            </div>
          </div>



<div class="pull-right">
    <?php //echo $this->pagination->create_links(); ?>    
</div>
