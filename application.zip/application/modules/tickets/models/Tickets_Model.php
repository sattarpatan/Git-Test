<?php

class Tickets_Model extends CI_Model {

	public function getTickets($cnf_id,$status=null) {
		
		if ($status==null) {
			$sql = "SELECT ticket_id, ticket_type, ticket_name, ticket_status FROM tickets WHERE cnf_id=? ORDER BY order_no";
			$query = $this->db->query($sql,$cnf_id);
		} else {
			$sql = "SELECT ticket_id, ticket_type, ticket_name, ticket_status FROM tickets WHERE cnf_id=? AND ticket_status=? ORDER BY order_no";
			$query = $this->db->query($sql,array($cnf_id,$status));
		}
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getTicketsByType($ticket_type,$cnf_id) {
			
		$sql = "SELECT ticket_id, ticket_type, ticket_name, ticket_status FROM tickets WHERE ticket_type=? AND cnf_id=? ORDER BY order_no";
		$query = $this->db->query($sql,array($ticket_type,$cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getTicketPrices($ticket_id) {
		$sql = "SELECT * FROM ticket_prices WHERE ticket_id=?";
		$query = $this->db->query($sql,$ticket_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getTicket($ticket_id) {
		
		$sql = "SELECT * FROM tickets WHERE ticket_id=?";
		$query = $this->db->query($sql,array($ticket_id));
		$row = $query->row_array();		
		$sql1 = "SELECT c.currency_id, c.currency_code, tp.early, tp.final from currencies c LEFT JOIN ticket_prices tp ON tp.currency_id=c.currency_id AND tp.ticket_id=".$ticket_id." WHERE c.status=1";
		$query1 = $this->db->query($sql1);
		$row1 = $query1->result_array();		
		$cnt = $query->num_rows();
		if ($cnt>0) {
			$data = $row;
			$data['prices'] = $row1;
			return $data;
		} else {
			return array();
		}
	}
	
	public function insertTicket() {
		
		$this->db->trans_start();
		
		$data = array(
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'ticket_type'		=> 	$this->input->post('ticket_type'),
			'ticket_name'		=> 	$this->input->post('ticket_name'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('tickets',$data);
		
		$insert_id = $this->db->insert_id();
		
		foreach ($this->input->post('currency') as $key => $currency) {
			$data1[] = array(
				'ticket_id'			=>	$insert_id,
				'currency_id'		=>	$key,
				'early'				=>	$currency[0],
				//'normal'			=>	$currency[1],
				'final'				=>	$currency[1],
				'created_by'		=> 	$this->session->userdata('user_id'),
				'created_datetime'	=>	date('Y-m-d H:i:s'),
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
		}
		
		$this->db->insert_batch('ticket_prices',$data1);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateTicket() {
		
		$this->db->trans_start();		
		
		$ticket_id = $this->input->post('ticket_id');		
		
		$data = array(
			'ticket_type'		=> 	$this->input->post('ticket_type'),
			'ticket_name'		=> 	$this->input->post('ticket_name'),
			'ticket_status'		=>	$this->input->post('ticket_status'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where('ticket_id',$ticket_id);		
		
		$this->db->update('tickets',$data);
		
		foreach ($this->input->post('currency') as $key => $currency) {
			
			$query = "SELECT * FROM ticket_prices WHERE ticket_id=? AND currency_id=?";			
			$sql = $this->db->query($query,array($ticket_id,$key));
			$cnt = $sql->num_rows();
			
			if ($cnt>0) {
				$data1 = array(
					'early'				=>	$currency[0],
					//'normal'			=>	$currency[1],
					'final'				=>	$currency[1],
					'updated_by' 		=> 	$this->session->userdata('user_id'),
					'updated_datetime'	=>	date('Y-m-d H:i:s')
				);				
				$this->db->where(
					array(
					'ticket_id'=>$ticket_id,
					'currency_id'=>$key
					)
				);
				$this->db->update('ticket_prices',$data1);
			} else {
				$data1 = array(
					'ticket_id'			=>	$ticket_id,
					'currency_id'		=>	$key,
					'early'				=>	$currency[0],
					//'normal'			=>	$currency[1],
					'final'				=>	$currency[1],
					'created_by'		=> 	$this->session->userdata('user_id'),
					'created_datetime'	=>	date('Y-m-d H:i:s'),
					'updated_by' 		=> 	$this->session->userdata('user_id'),
					'updated_datetime'	=>	date('Y-m-d H:i:s')
				);
				$this->db->insert('ticket_prices',$data1);
			}
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
		
	}
	
	public function updateOrder($Order) {
		
		$this->db->trans_start();
		
		$i=1;
		
		foreach ($Order as $order_no => $ticket) {
			
			$data = array(
				'order_no' 			=> 	$i++,
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
			$this->db->where('ticket_id',$ticket['value']);
			$this->db->update('tickets',$data);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}		
	}
}