<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tickets extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('conference/conference_model');
			$this->load->model('tickets/Tickets_Model');
			$this->load->model('currencies/Currencies_Model');
		}
    }
	
	public function index()
	{
		$data['tickets'] = array();
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$tickets = $this->Tickets_Model->getTickets($cnf_id);
		
		foreach ($tickets as $ticket) {
			
			$query = $this->db->query("SELECT c.currency_code, tp.early, tp.final from currencies c LEFT JOIN ticket_prices tp ON tp.currency_id=c.currency_id AND tp.ticket_id=".$ticket['ticket_id']." WHERE c.status=1");
			
			$result = $query->result_array();
			
			$data['tickets'][] = array(
				'ticket_id' 	=> $ticket['ticket_id'],
				'ticket_type' 	=> $ticket['ticket_type'],
				'ticket_name' 	=> $ticket['ticket_name'],
				'ticket_status'	=> $ticket['ticket_status'],
				'prices'		=> $result
			);
		}
		
		//$this->load->layout2('tickets/list',$data);
		
		$data['_view'] = 'tickets/list';
		$this->load->view('layouts/main',$data);
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$Order = $this->input->post('order_no');
		$result = $this->Tickets_Model->updateOrder($Order);
		
		if ($result == true) {
			
			$data['tickets'] = array();			
			
			$tickets = $this->Tickets_Model->getTickets($cnf_id);			
			
			foreach ($tickets as $ticket) {
			
				$query = $this->db->query("SELECT c.currency_code, tp.early, tp.normal, tp.final from currencies c LEFT JOIN ticket_prices tp ON tp.currency_id=c.currency_id AND tp.ticket_id=".$ticket['ticket_id']." WHERE c.status=1");
				
				$result = $query->result_array();
				
				$data['tickets'][] = array(
					'ticket_id' 	=> $ticket['ticket_id'],
					'ticket_type' 	=> $ticket['ticket_type'],
					'ticket_name' 	=> $ticket['ticket_name'],
					'ticket_status'	=> $ticket['ticket_status'],
					'prices'		=> $result
				);
			}
			
			return $this->load->view('tickets/table',$data);
			
		} else {
			
			return false;
		}
	}
	
	public function get_list()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$ticket_type = $this->input->post('ticket_type');
		if ($ticket_type!="") {
			$tickets = $this->Tickets_Model->getTicketsByType($ticket_type,$cnf_id);
		} else {
			$tickets = $this->Tickets_Model->getTickets($cnf_id);
		}
		
		if (empty($tickets))
		{
			echo "empty";
		}
		else
		{
			$data = array();
			foreach ($tickets as $ticket) {
				$query = $this->db->query("SELECT c.currency_code, tp.early, tp.normal, tp.final from currencies c LEFT JOIN ticket_prices tp ON tp.currency_id=c.currency_id AND tp.ticket_id=".$ticket['ticket_id']."  WHERE c.status=1");
				
				$result = $query->result_array();			
				$data['tickets'][] = array(
					'ticket_id' 	=> $ticket['ticket_id'],
					'ticket_type' 	=> $ticket['ticket_type'],
					'ticket_name' 	=> $ticket['ticket_name'],
					'ticket_status'	=> $ticket['ticket_status'],
					'prices'		=> $result
				);
			}			
			return $this->load->view('tickets/table',$data);
		}
	}
	
	public function add()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['currencies'] = $this->Currencies_Model->getCurrencies(1);
		
		if ($this->form_validation->run('tickets_add') == FALSE)
		{			
			//$this->load->layout2('tickets/add',$data);
			$data['_view'] = 'tickets/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$insert_status = $this->Tickets_Model->insertTicket();
			
			if ($insert_status==true) {
				$this->session->set_flashdata('tickets_success', 'Tickets added successfully.');
				redirect('tickets');
			}
			else
			{
				$this->session->set_flashdata('tickets_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('tickets/add',$data);
				
				$data['_view'] = 'tickets/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($ticket_id)
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($ticket_id,$cnf_id);
		
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['currencies'] = $this->Currencies_Model->getCurrencies(1);
		$data['ticket'] = $this->Tickets_Model->getTicket($ticket_id);		
		
		if ($this->form_validation->run('tickets_edit') == FALSE)
		{			
			//$this->load->layout2('tickets/edit',$data);
			
			$data['_view'] = 'tickets/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$update_status = $this->Tickets_Model->updateTicket();
			
			if ($update_status==true) {
				$this->session->set_flashdata('tickets_success', 'Ticket updated successfully.');
				redirect('tickets');
			}
			else
			{
				$this->session->set_flashdata('tickets_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('tickets/edit',$data);
				
				$data['_view'] = 'tickets/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function check_access($ticket_id,$cnf_id) {
		
		$query = $this->db->query("SELECT * FROM tickets WHERE ticket_id='".$ticket_id."' AND cnf_id=".$cnf_id);
		
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! Record not available!');
			$tickets = $this->Tickets_Model->getTickets($cnf_id);
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			foreach ($tickets as $ticket) {
				$query = $this->db->query("SELECT c.currency_code, tp.early, tp.normal, tp.final from currencies c LEFT JOIN ticket_prices tp ON tp.currency_id=c.currency_id AND tp.ticket_id=".$ticket['ticket_id']."  WHERE c.status=1");
				
				$result = $query->result_array();			
				$data['tickets'][] = array(
					'ticket_id' 	=> $ticket['ticket_id'],
					'ticket_type' 	=> $ticket['ticket_type'],
					'ticket_name' 	=> $ticket['ticket_name'],
					'ticket_status'	=> $ticket['ticket_status'],
					'prices'		=> $result
				);
			}
			//$this->load->layout2('tickets/list',$data);
			
			$data['_view'] = 'tickets/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	function check_currencies() {
		if (empty($this->input->post('currency'))) {
			$this->form_validation->set_message('check_currencies', 'Currencies are required.');
			return false;
		} else {
			return true;
		}
	}
	
	function check_ticket_name() {
		$ticket_type = $this->input->post('ticket_type');
		$ticket_name = $this->input->post('ticket_name');
		$cnf_id = $this->session->userdata('cnf_id');
		$query = "SELECT * FROM tickets WHERE ticket_type=? AND ticket_name=? AND cnf_id=?";
		$sql = $this->db->query($query,array($ticket_type,$ticket_name,$cnf_id));
		if ($sql->num_rows()>0) {
			$this->form_validation->set_message('check_ticket_name', $ticket_name.' already existed in '.ticket_type_name($ticket_type));
			return false;
		} else {
			return true;
		}
	}
	
	function check_ticket_name_for_edit() {
		$ticket_id = $this->input->post('ticket_id');
		$ticket_type = $this->input->post('ticket_type');
		$ticket_name = $this->input->post('ticket_name');
		$cnf_id = $this->session->userdata('cnf_id');
		$query = "SELECT * FROM tickets WHERE ticket_type=? AND ticket_name=? AND ticket_id!=? AND cnf_id=?";
		$sql = $this->db->query($query,array($ticket_type,$ticket_name,$ticket_id,$cnf_id));
		if ($sql->num_rows()>0) {
			$this->form_validation->set_message('check_ticket_name_for_edit', $ticket_name.' already existed in '.ticket_type_name($ticket_type));
			return false;
		} else {
			return true;
		}
	}
}