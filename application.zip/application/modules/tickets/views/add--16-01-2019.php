<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Tickets'); ?>
		<?=view_list(base_url('cms/tickets')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('tickets_add_error')) { ?>
			<?=alert_error($this->session->flashdata('tickets_add_error')); ?>
		<?php } ?>
		<form class="form-horizontal" method="post" onsubmit="return validate()">
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ticket Type <span class="required">*</span> </label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<select name="ticket_type" class="form-control ">
						<option value="1">Academic</option>
						<option value="2">Business</option>
						<option value="3">Student</option>
						<option value="4">Addon</option>
						<option value="5">e-Poster</option>
						<option value="6">Exhibitor</option>
						<option value="7">Sponsor</option>
						<option value="8">Webinar</option>
					</select>
					<?php echo form_error('ticket_type'); ?>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Ticket Name <span class="required">*</span></label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<input type="text" name="ticket_name" class="form-control col-md-7 col-xs-12" value="">
					<?php echo form_error('ticket_name'); ?>
			  	</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="row">
						<div class="col-sm-4">
							<label>Early Price</label>
						</div>
						<div class="col-sm-4">
							<label>Normal Price</label>
						</div>									
						<div class="col-sm-4">
							<label>On Site Price</label>
						</div>
					</div>
				</div>
			</div>
			<?php foreach ($currencies as $currency) { ?>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">
					<?php echo $currency['currency_code']; ?>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="row">
						<div class="col-sm-4">
							<input type="text" class="form-control currency" id="label1" name="currency[<?php echo $currency['currency_id']; ?>][0]" value="">
							 <div class="error"></div>
						</div>
						<div class="col-sm-4">
							<input type="text" class="form-control currency" id="label2" name="currency[<?php echo $currency['currency_id']; ?>][1]" value="">
							<div class="error"></div>
						</div>									
						<div class="col-sm-4">
							<input type="text" class="form-control currency" id="label3" name="currency[<?php echo $currency['currency_id']; ?>][2]" value="">
							<div class="error"></div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12"></label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				<?php echo form_error('currency'); ?>
				</div>
			</div>
			<div class="ln_solid"></div>
			  <div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
				  <?=cancel(base_url('cms/tickets'));?>
				  <button type="submit" class="btn btn-success">Submit</button>
				</div>
			  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('cms/tickets'); ?>";
function validate() {
	$(".error").html("");
	var status = true;
	$(".currency").each(function(){
		if (isNaN($(this).val())) {
			$(this).next(".error").html("Numbers only.");
			status = false;
		}
	});
	return status;
}
</script>