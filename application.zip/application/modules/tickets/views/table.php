<?php if (!empty($tickets)) { ?>
<?php foreach ($tickets as $ticket) { ?>
<li class="ui-sortable-handle">
	<div class="row">
		<div class="col-sm-1" style="text-align:center;">
			<span class="glyphicon glyphicon-sort text-success" id="sort_icon"></span>
		</div>
		<div class="col-sm-11">
			<div class="row">
				<div class="col-sm-8">
					<div class="track_no">
						<h2><?=ticket_type_name($ticket['ticket_type']); ?> : <?=$ticket['ticket_name']; ?></h2>
					</div>
				</div>
				<div class="col-sm-4">
					<input type="hidden" name="order_no[]" class="order_no" value="<?=$ticket['ticket_id'];?>">
					<a class="pull-right btn btn-info btn-xs" href="<?php echo base_url('tickets/edit')."/".$ticket['ticket_id'] ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Ticket</a>
					<a href="#" class="pull-right btn btn-info btn-xs track_details_btn"><i class="fa fa-chevron-down"></i> Details</a>
				</div>
			</div>
			<div class="track_details" style="display:none;background:none;">
			<br/>
			<div class="container-fluid">
				<div class="row">
					<div class="col-sm-11">
						<table class="table table-bordered price-table">
							<thead>
								<tr>
								<th>Currency</th>
								<th>Early</th>
								<th>Final</th>
								<!--<th>Onsite</th>-->
								</tr>
							</thead>
							<tbody>
							  <?php foreach ($ticket['prices'] as $price) { ?>
							  <tr>
							  <td><?=$price['currency_code'];?></td>
							  <td><?=$price['early'];?></td>
							  <td><?=$price['final'];?></td>
							  <!--<td><?=$price['final'];?></td>-->
							  </tr>
							  <?php } ?>
							 </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		</div>
	</div>
</li>
<?php } ?>
<?php } ?>