<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Tickets'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<a href="#" name="order" id="order" class="btn btn-success"/>
						<i class="fa fa-first-order"></i> Update Order</a>
					<a class="btn btn-success" href="<?=base_url('tickets/add'); ?>">
						<i class="fa fa-plus"></i> ADD</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
			<?php if ($this->session->flashdata('tickets_success')) { ?>
			<?=alert_success($this->session->flashdata('tickets_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('member_access_error')) { ?>
			<?=alert_error($this->session->flashdata('member_access_error')); ?>
			<?php } ?>
			<div class="row">
				<div class="jumbotron-new">
					<div class="form-group">
						<label class="control-label col-md-2">Ticket Type</label>
						<div class="col-md-3">
						<select name="ticket_type" id="ticket_type" class="form-control">
							<option value="">All</option>						
							<option value="1">Academic</option>
							<option value="2">Business</option>
							<option value="3">Student</option>
							<option value="4">Addon</option>
							<option value="5">ePoster</option>
							<option value="6">Exhibitor</option>
							<option value="7">Sponsor</option>
							<option value="8">Webinar</option>
						</select>
						</div>
					</div>
				</div>
			</div>
			
			<div id="alerts"></div>
			<ul id="sortable" class="ui-sortable">
				<?php $this->load->view('tickets/table',$tickets); ?>
			</ul>
		</div>
	</div>
  </div>
</div>
<style>
#sort_icon{
	background: white;
    padding-left: 10px;
    padding-right: 10px;
    border-radius: 20px;
}	
#sortable a{border:1px solid #e6efed;}
.track_details{
	background:hsl(59, 26%, 92%);
	border:1px solid rgba(210, 195, 195, 0.2);
	margin-top:10px;
	padding-bottom:20px;
	color:#666;
}
#sortable li {
	overflow-y:auto;
	background: #e4e3e3;
    color: #044e8e;
}

#sortable li ul.sub_sortable {
	padding-left:0px;
}
#sortable li ul.sub_sortable li{
	background:#f5ebdf;
	color:#5a5555;
}

#sortable img{
	border:1px solid grey;
}

.track_no
{
	font-weight:600;
	line-height:32px;
}
.track_no h2{
	font-size:13px;
	font-weight:600;
}
</style>
<script>
var parent_url = "<?php echo base_url('tickets'); ?>";
var post_url = "<?=base_url('tickets/updateOrder');?>";
var url = "<?php echo base_url('tickets/get_list'); ?>";

window.onload = function() {
	
	defaultFunctions();
	
	$("#order").click(function(){
		var alertMsg = $("#alerts");
		alertMsg.css("display","none");
		var order_no = $('input[name="order_no\[\]"').serializeArray();
		var alertMsg = $("#alerts");
		alertMsg.css("display","none");
		$.ajax({
			  type: "POST",
			  url: post_url,
			  data: {
					order_no:order_no,
					},
			  success: function(resultData){
					alertMsg.html(successMsg("Tickets Order updated!")).slideDown(100);
					$("#sortable").html(resultData);
					defaultFunctions();
			  },
			  error: function(){
					alertMsg.html(errorMsg("Not updated, something went wrong!")).slideDown(100);
			  }
		});
	});
	
	$("#ticket_type").on('change',function(){
		var selected = $(this).val();
		if (selected==""){
			$("#order").css('visibility','visible');
		} else {
			$("#order").css('visibility','hidden');
		}
		$.ajax({
		  type: "POST",
		  url:url,
		  data:{ticket_type:selected},
		  success:function(response){
			  if (response==false) {
				  alert("Something went wrong.");
			  } else if (response=="empty") {
				  $("#sortable").html("<p>No Tickets Available!</p>");
			  } else {
				$("#sortable").html(response);
				defaultFunctions();
			  }
			}
		});
	});
	
	function defaultFunctions(){
		$("#sortable").sortable();
		$(".track_details_btn").click(function(e){
			e.preventDefault();
			var that = this;
			var track_details = $(this).closest("li.ui-sortable-handle").find('.track_details');
			track_details.slideToggle(100,'swing',function(){
				$("i", that).toggleClass("fa-chevron-down fa-chevron-up");
			});
		});
	}
}
</script>