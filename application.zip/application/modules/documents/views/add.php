<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Document'); ?>
		<?=view_list(base_url('documents')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('documents_add_error')) { ?>
			<?=alert_error($this->session->flashdata('documents_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Document Type <span class="required">*</span></label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<select name="type" class="form-control chosen-select">
						<option value="">Select Document Type</option>
						<?php if (!in_array(13,$uploaded_docs)) { ?>
						<option value="13">Abstract Template</option>
						<?php } ?>
						<?php if (!in_array(1,$uploaded_docs)) { ?>
						<option value="1">Initial Announcement</option>
						<?php } ?>
						<?php if (!in_array(2,$uploaded_docs)) { ?>
						<option value="2">Agenda</option>
						<?php } ?>
						<?php if (!in_array(3,$uploaded_docs)) { ?>
						<option value="3">Other</option>
						<?php } ?>
						<?php if (!in_array(4,$uploaded_docs)) { ?>
						<option value="4">Conference Guide</option>
						<?php } ?>
						<?php if (!in_array(5,$uploaded_docs)) { ?>
						<option value="5">Sponsorship Brochure</option>
						<?php } ?>
						<?php if (!in_array(6,$uploaded_docs)) { ?>
						<option value="6">Conference Brochure</option>
						<?php } ?>
						<?php if (!in_array(7,$uploaded_docs)) { ?>
						<option value="7">Exhibitor PDF</option>
						<?php } ?>
						<?php if (!in_array(8,$uploaded_docs)) { ?>
						<option value="8">e-Form</option>
						<?php } ?>
						<?php if (!in_array(9,$uploaded_docs)) { ?>
						<option value="9">e-FormUSA</option>
						<?php } ?>
						<?php if (!in_array(10,$uploaded_docs)) { ?>
						<option value="10">e-FormIndia</option>
						<?php } ?>
						<?php if (!in_array(11,$uploaded_docs)) { ?>
						<option value="11">Workshop Program</option>
						<?php } ?>
					</select>
				  <?php echo form_error('type'); ?>
				</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Document <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<input type="file" name="file" id="file"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('file'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <?=cancel(base_url('documents')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('documents'); ?>";</script>