<?php if (empty($documents)) { ?>
<p>No Conference Documents available!</p>
<?php } else { ?>
<?php foreach ($documents as $file) { ?>
<div class="col-md-3">
	<div class="thumbnail document">
	  <div class="caption1">
		<p><?=$file['doctype'];?></p>
	  </div>
	  <div class="image view view-first">
		<embed src="<?php echo $file['file_path']; ?>" width="100%" height="100%" />
	  </div>
	  <div class="caption">
		<p class="actions">
			<a href="<?php echo $file['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			&nbsp;
			<a href="<?php echo base_url('documents/forceDownload/').$file['id']; ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			&nbsp;
			<a href="javascript:modalDocument(<?php echo $file['id']; ?>);" title="Delete"><i class="fa fa-times"></i></a>
		</p>
	  </div>
	</div>
</div>
<?php } ?>
<?php } ?>