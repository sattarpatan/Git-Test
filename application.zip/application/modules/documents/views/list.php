<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Documents'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <a class="btn btn-success" href="<?=base_url('documents/add'); ?>"> <i class="fa fa-plus"></i> ADD</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
		<?php if ($this->session->flashdata('documents_success')) { ?>
		<?=alert_success($this->session->flashdata('documents_success')); ?>
		<?php } ?>
		<?php if ($this->session->flashdata('member_access_error')) { ?>
		<?=alert_error($this->session->flashdata('member_access_error')); ?>
		<?php } ?>
		<div id="alerts"></div>
		<div class="row" id="sortable">
			<?php $this->load->view('documents/table'); ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete Document</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="deleteDocument()">Delete</button>
		<input type="hidden" name="id" id="id"/>
      </div>
    </div>
  </div>
</div>
<style>
.thumbnail {
    height: 260px;
}
.thumbnail .image {
    height: 178px;
}
div.thumbnail.document p{
	text-align:center;	
}
div.thumbnail.document p.actions{
	font-size:16px;
	background:rgb(193, 193, 193);
}
div.thumbnail.document div.caption1 p{
	color:red;
	font-weight:600;
	margin-top:10px;
}
</style>
<script>
var get_file_url = "<?php echo base_url('documents/getDocument'); ?>";
var delete_url = "<?php echo base_url('documents/deleteDocument'); ?>";
function modalDocument(id){
	$.ajax({
		  type: "POST",
		  url:get_file_url,
		  data:{id:id},
		  dataType:"json",
		  success:function(response){
			 var file = response.file_path;
			 $("#id").val(id);
			 $(".modal-body").html("<embed src='"+file+"' width='100%' height='100%' /><h4 class='text-danger'>Are you sure you want to delete this document?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function deleteDocument(){
	var alertMsg = $("#alerts");
	alertMsg.css("display","none");
    $.ajax({
		  type: "POST",
		  url:delete_url,
		  data:{id:$("#id").val()},
		  success:function(response){
			  if (response==false) {
				  alertMsg.html(errorMsg("Something went wrong.")).slideDown(100);
			  } else {
				  $("#sortable").html(response);
				  alertMsg.html(successMsg("Deleted!")).slideDown(100);
			  }
			  $('#myModal').modal('hide');
		  }
	});
}
</script>