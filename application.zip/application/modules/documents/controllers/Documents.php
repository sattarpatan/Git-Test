<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Documents extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('documents/documents_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['documents'] = $this->documents_model->getDocuments($cnf_id);
		//$this->load->layout2('documents/list',$data);
		
		$data['_view'] = 'documents/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['uploaded_docs'] = $this->documents_model->getUploadedDocTypeIds($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Document');
		
		if ($this->form_validation->run('documents_add') == FALSE)
		{			
			//$this->load->layout2('documents/add',$data);
			$data['_view'] = 'documents/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(id)+1 as id FROM documents";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['id'],$cnf_id);
			$newFile = DOCUMENTS_PATH.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('documents_add_error', 'File uploading error!'); 
				//$this->load->layout2('documents/add',$data);
				$data['_view'] = 'documents/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->documents_model->insertDocument($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('documents_success', 'Conference Document added successfully!');
					redirect('cms/documents');
				}
				else
				{
					$this->session->set_flashdata('documents_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('documents/add',$data);
					$data['_view'] = 'documents/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	function deleteDocument(){
		$cnf_id = $this->session->userdata('cnf_id');
		$id = $this->input->post('id');
		$file = $this->documents_model->getDocument($id);
		$file = $file['file_path'];
		$this->load->library('../controllers/upload');
		$delete_status = $this->upload->doDelete($file);
		if ($delete_status==true)
		{
			$this->documents_model->deleteDocument($id);
			$data['documents'] = $this->documents_model->getDocuments($cnf_id);
			return $this->load->view('documents/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$document = $this->documents_model->getDocument($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($document['file_path']);
		force_download($document['file_path'],$fileContents);
		exit;
	}
	
	function check_access($id,$cnf_id){
		$query = $this->db->query("SELECT * FROM documents WHERE id='".$id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['documents'] = $this->documents_model->getDocument($cnf_id);
			//$this->load->layout2('documents/list',$data);
			$data['_view'] = 'documents/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function createFileName($id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('name')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$id.".".$fileinfo['extension'];
	}
	
	function getDocument(){
		$id = $this->input->post('id');
		$file = $this->documents_model->getDocument($id);
		echo json_encode($file);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select file');
			return false;
		} else {
			return true;
		}
	}
}