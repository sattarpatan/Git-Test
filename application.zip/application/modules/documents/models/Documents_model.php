<?php

class Documents_model extends CI_Model {

	public function getDocuments($cnf_id) {
		$sql = "SELECT b.*, DocumentType(b.type) doctype, f.* FROM documents b join filemaster f on b.file_id=f.file_id WHERE b.cnf_id=?";
		
		$query = $this->db->query($sql,$cnf_id);
		//echo $this->db->last_query();
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getDocument($id) {
		$sql = "SELECT b.*, DocumentType(b.type) doctype, f.* FROM documents b join filemaster f on b.file_id=f.file_id WHERE b.id=?";
		$query = $this->db->query($sql,array($id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function getUploadedDocTypeIds($cnf_id) {
		$sql = "SELECT * FROM documents WHERE cnf_id=?";
		$query = $this->db->query($sql,array($cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return array_column($query->result_array(),'type');  
		} else {
			return array();
		}
	}
	
	public function deleteDocument($id){
		
		$this->db->trans_start();
		
		$sql = "delete from filemaster where file_id=(select file_id from documents where id=?)";
		$this->db->query($sql,array($id));
		
		$sql = "delete from documents where id=?";
		$this->db->query($sql,array($id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function insertDocument($filepath) {
		
		$this->db->trans_start();
		
		$data = array(
			'file_path' 		=> 	$filepath,
			'title_desc'		=>	clean_title($this->input->post('name')),
			'link_url'			=>	$this->input->post('link_url'),
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('filemaster',$data);
		
		$insert_id = $this->db->insert_id();
		
		$data = array(
			'file_id' 			=> 	$insert_id,
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'type'				=>	$this->input->post('type'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('documents',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}