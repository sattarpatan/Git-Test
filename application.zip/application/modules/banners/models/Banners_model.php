<?php

class Banners_model extends CI_Model {

	public function getBanners($cnf_id) {
		$sql = "SELECT b.*, f.* FROM banners b join filemaster f on b.file_id=f.file_id WHERE b.cnf_id=?";
		$query = $this->db->query($sql,$cnf_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getBanner($banner_id) {
		$sql = "SELECT b.*, f.* FROM banners b join filemaster f on b.file_id=f.file_id WHERE b.banner_id=?";
		$query = $this->db->query($sql,array($banner_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function deleteBanner($banner_id){
		
		$this->db->trans_start();
		
		$sql = "delete from filemaster where file_id=(select file_id from banners where banner_id=?)";
		$this->db->query($sql,array($banner_id));
		
		$sql = "delete from banners where banner_id=?";
		$this->db->query($sql,array($banner_id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function insertBanner($filepath) {
		
		$this->db->trans_start();
		
		$data = array(
			'file_path' 		=> 	$filepath,
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('filemaster',$data);
		
		$insert_id = $this->db->insert_id();
		
		$data = array(
			'file_id' 			=> 	$insert_id,
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('banners',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}