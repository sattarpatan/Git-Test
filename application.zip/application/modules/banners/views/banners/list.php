<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Banner'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<?php if (empty($banners)) { ?>
					<a class="btn btn-success" href="<?=base_url('cms/banners/add'); ?>">
						<i class="fa fa-plus"></i> ADD</a>
					<?php } ?>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
		<?php if ($this->session->flashdata('banners_success')) { ?>
		<?=alert_success($this->session->flashdata('banners_success')); ?>
		<?php } ?>
		<div id="alerts"></div>
		<div class="row" id="sortable">
			<?php $this->load->view('banners/table'); ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete Banner</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="deleteBanner()">Delete</button>
		<input type="hidden" name="banner_id" id="banner_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var banner_url = "<?php echo base_url('cms/banners'); ?>";
var get_banner_url = "<?php echo base_url('cms/banners/getBanner'); ?>";
var delete_url = "<?php echo base_url('cms/banners/deleteBanner'); ?>";

function modalBanner(banner_id){
	$.ajax({
		  type: "POST",
		  url:get_banner_url,
		  data:{banner_id:banner_id},
		  dataType:"json",
		  success:function(response){
			 var file = response.file_path;
			 $("#banner_id").val(banner_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><h4 class='text-danger'>Are you sure you want to delete this banner?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function deleteBanner(){
	var alertMsg = $("#alerts");
	alertMsg.css("display","none");
    $.ajax({
		  type: "POST",
		  url:delete_url,
		  data:{banner_id:$("#banner_id").val()},
		  success:function(response){
			  if (response==false) {
				  alertMsg.html(errorMsg("Something went wrong.")).slideDown(100);
			  } else {
				  window.location.href = banner_url;
			  }
			  $('#myModal').modal('hide');
		  }
	});
}
</script>