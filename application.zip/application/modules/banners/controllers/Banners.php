<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banners extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			$this->load->model('banners/banners_model', 'banners');
			$this->load->model('conference/conference_model');
			$this->load->model('renowned_speakers/renowned_speakers_model', 'speakers');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['banners'] = $this->banners->getBanners($cnf_id);
		//$this->load->layout2('banners/list',$data);
		
		$data['_view'] = 'banners/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Banner');
		
		if ($this->form_validation->run('banners_add') == FALSE)
		{			
			
			$data['_view'] = 'banners/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$newFileName = $this->createFileName($cnf_id);
			$newFile = BANNER_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('banner_add_error', $this->session->flashdata('file_error'));
				
				$data['_view'] = 'banners/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->banners->insertBanner($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('banners_success', 'Banner added successfully!');
					redirect('banners');
				}
				else
				{
					$this->session->set_flashdata('banners_add_error', 'Sorry! Something went wrong. Try Again.');
					
					$data['_view'] = 'banners/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->banners->getBanner($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteBanner(){
		$cnf_id = $this->session->userdata('cnf_id');
		$banner_id = $this->input->post('banner_id');
		$this->check_access($banner_id,$cnf_id);
		$banner = $this->banners->getBanner($banner_id);
		$file = $banner['file_path'];
		$this->load->library('../controllers/upload');
		$delete_status = $this->upload->doDelete($file);
		if ($delete_status==true)
		{
			$this->banners->deleteBanner($banner_id);
			$data['banners'] = $this->banners->getBanners($cnf_id);
			return $this->load->view('banners/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($banner_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM banners WHERE banner_id='".$banner_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['banners'] = $this->banners->getBanners($cnf_id);
			
			$data['_view'] = 'banners/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->banners->updateOrder($order);
		if ($result == true) {
			$data['banners'] = $this->banners->getBanners($cnf_id);
			return $this->load->view('banners/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		$slug = sluggify_string($fileinfo['filename']);
		return $slug."-".$cnf_id.$fileinfo['extension'];
	}
	
	function getBanner(){
		$banner_id = $this->input->post('banner_id');
		$banner = $this->banners->getBanner($banner_id);
		echo json_encode($banner);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
	
	function valid_url_format($str){
		if (!$str){
			return true;
		}
        $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
        if (!preg_match($pattern, $str)){
            $this->form_validation->set_message('valid_url_format', 'The URL you entered is not correct. Ex : http://www.example.com');
            return FALSE;
        }
 
        return TRUE;
    }
}
