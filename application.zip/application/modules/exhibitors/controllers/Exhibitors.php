<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exhibitors extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('exhibitors/exhibitors_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['exhibitors'] = $this->exhibitors_model->getExhibitors($cnf_id);
		//$this->load->layout2('exhibitors/list',$data);
		$data['_view'] = 'exhibitors/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Exhibitor',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('exhibitors_add') == FALSE)
		{			
			//$this->load->layout2('exhibitors/add',$data);
			$data['_view'] = 'exhibitors/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(exhibitor_id)+1 as exhibitor_id FROM exhibitors";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['exhibitor_id'],$cnf_id);
			$newFile = EXHIBITOR_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('exhibitors_add_error', 'File uploading error!'); 
				//$this->load->layout2('exhibitors/add',$data);
				$data['_view'] = 'exhibitors/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->exhibitors_model->insertExhibitors($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('exhibitors_success', 'Exhibitor added successfully!');
					redirect('exhibitors');
				}
				else
				{
					$this->session->set_flashdata('exhibitors_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('exhibitors/add',$data);
					$data['_view'] = 'exhibitors/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$document = $this->exhibitors_model->getExhibitor($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($document['file_path']);
		force_download($document['file_path'],$fileContents);
		exit;
	}
	
	function deleteExhibitor(){
		$cnf_id = $this->session->userdata('cnf_id');
		$exhibitor_id = $this->input->post('exhibitor_id');
		$this->check_access($exhibitor_id,$cnf_id);
		$exhibitor = $this->exhibitors_model->getExhibitor($exhibitor_id);
		$file = $exhibitor['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->exhibitors_model->deleteExhibitor($exhibitor_id);
			$data['exhibitors'] = $this->exhibitors_model->getExhibitors($cnf_id);
			return $this->load->view('exhibitors/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($exhibitor_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM exhibitors WHERE exhibitor_id='".$exhibitor_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['exhibitors'] = $this->exhibitors_model->getExhibitors($cnf_id);
			//$this->load->layout2('exhibitors/list',$data);
			$data['_view'] = 'exhibitors/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->exhibitors_model->updateOrder($order);
		if ($result == true) {
			$data['exhibitors'] = $this->exhibitors_model->getExhibitors($cnf_id);
			return $this->load->view('exhibitors/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($exhibitor_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$exhibitor_id.".".$fileinfo['extension'];
	}
	
	function getExhibitor(){
		$exhibitor_id = $this->input->post('exhibitor_id');
		$exhibitor = $this->exhibitors_model->getExhibitor($exhibitor_id);
		echo json_encode($exhibitor);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
	
	function valid_url_format($str){
		if (!$str){
			return true;
		}
        $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
        if (!preg_match($pattern, $str)){
            $this->form_validation->set_message('valid_url_format', 'The URL you entered is not correct. Ex : http://www.example.com');
            return FALSE;
        }
 
        return TRUE;
    }
}
/***/