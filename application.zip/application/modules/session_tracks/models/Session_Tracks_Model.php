<?php

class Session_Tracks_Model extends CI_Model {

	public function getSessionTracks($session_id) {
		$sql = "SELECT st.*, t.track_name,
		IF (s.session_title='',CONCAT('Session  ',s.order_no),session_title) as session_name
		FROM session_tracks st 
		LEFT JOIN sessions s ON s.session_id=st.session_id
		LEFT JOIN tracks t ON t.track_id=st.track_id
		WHERE st.session_id=?";
		$query = $this->db->query($sql,$session_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getSessionTrack($id) {
		$sql = "SELECT st.*, t.track_name,
		IF (s.session_title='',CONCAT('Session  ',s.order_no),session_title) as session_name
		FROM session_tracks st 
		LEFT JOIN sessions s ON s.session_id=st.session_id
		LEFT JOIN tracks t ON t.track_id=st.track_id
		WHERE st.id=?";
		$query = $this->db->query($sql,$id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function getSessionTrackSpeakers($id) {
		$sql = "SELECT stp.*, m.name FROM session_track_speakers stp 
		JOIN members m ON m.member_id=stp.speaker
		WHERE stp.session_track_id=?";
		$query = $this->db->query($sql,$id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function insertSessionTrack() {
		
		$this->db->trans_start();
		
		$data = array(
			'session_id'		=>	$this->input->post('session_id'),
			'track_id'			=>	$this->input->post('track_id'),
			'from_time'			=>	$this->input->post('from_time'),
			'to_time'			=>	$this->input->post('to_time'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by'		=>	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('session_tracks',$data);
		
		$insert_id = $this->db->insert_id();
		
		if (!empty($this->input->post('speaker'))) {
		
			$speakers = $this->input->post('speaker');
			
			$speaker_type = $this->input->post('speaker_type');
			
			for ($i=0;$i<count($speakers);$i++) {
				$data1[] = array(
					'session_track_id'		=>	$insert_id,
					'speaker'				=>	$speakers[$i],
					'speaker_type'			=>	$speaker_type[$i],
					'created_by'			=> 	$this->session->userdata('user_id'),
					'created_datetime'		=>	date('Y-m-d H:i:s'),
					'updated_by'			=>	$this->session->userdata('user_id'),
					'updated_datetime'		=>	date('Y-m-d H:i:s')
				);
			}
			$this->db->insert_batch('session_track_speakers',$data1);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateSessionTrack() {
		
		$this->db->trans_start();
		
		$data = array(
			'track_id'			=>	$this->input->post('track_id'),
			'from_time'			=>	$this->input->post('from_time'),
			'to_time'			=>	$this->input->post('to_time'),
			'updated_by'		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where(array('id'=>$this->input->post('id')));
		
		$this->db->update('session_tracks',$data);
		
		$this->db->query("DELETE FROM session_track_speakers WHERE session_track_id=".$this->input->post('id'));
		
		if (!empty($this->input->post('speaker'))) {
		
			$speakers = $this->input->post('speaker');
			
			$speaker_type = $this->input->post('speaker_type');
			
			for ($i=0;$i<count($speakers);$i++) {
				$data1[] = array(
					'session_track_id'		=>	$this->input->post('id'),
					'speaker'				=>	$speakers[$i],
					'speaker_type'			=>	$speaker_type[$i],
					'created_by'			=> 	$this->session->userdata('user_id'),
					'created_datetime'		=>	date('Y-m-d H:i:s'),
					'updated_by'			=>	$this->session->userdata('user_id'),
					'updated_datetime'		=>	date('Y-m-d H:i:s')
				);
			}
			$this->db->insert_batch('session_track_speakers',$data1);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}