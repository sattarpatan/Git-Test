<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Session_Tracks extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('sessions/Sessions_Model');
			$this->load->model('session_tracks/Session_Tracks_Model');
			$this->load->model('conference/conference_model');
			$this->load->model('days/Days_Model');
			$this->load->model('members/Members_Model');
			$this->load->model('tracks/Tracks_Model');
		}
    }
	
	public function index($session_id=NULL)
	{  
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($session_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['session_tracks'] = $this->Session_Tracks_Model->getSessionTracks($session_id);
		$data['session_id'] = $session_id;
		$this->load->layout2('session_tracks/list',$data);
	}
	
	public function add($session_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($session_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['days'] = $this->Days_Model->getDays($cnf_id);
		$data['members'] = $this->Members_Model->getMembers($cnf_id);
		$data['tracks'] = $this->Tracks_Model->getTracks($cnf_id);
		$data['session_id'] = $session_id;
		
		if ($this->form_validation->run('session_tracks_add') == FALSE)
		{			
			$this->load->layout2('session_tracks/add',$data);
		}
		else
		{
			
			$insert_status = $this->Session_Tracks_Model->insertSessionTrack();
			
			if ($insert_status==true) {
				$this->session->set_flashdata('sessions_success', 'Added successfully!');
				redirect('cms/session_tracks/index/'.$session_id);
			}
			else
			{
				$this->session->set_flashdata('sessions_add_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout2('session_tracks/add',$data);
			}
		}
	}
	
	public function edit($id)
	{
		$cnf_id = $this->session->userdata('cnf_id');
		//$this->check_access($session_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['session_track'] = $this->Session_Tracks_Model->getSessionTrack($id);
		$data['session_track_speakers'] = $this->Session_Tracks_Model->getSessionTrackSpeakers($id);
		$data['members'] = $this->Members_Model->getMembers($cnf_id);
		$data['tracks'] = $this->Tracks_Model->getTracks($cnf_id);
			
		if ($this->form_validation->run('session_tracks_edit') == FALSE)
		{			
			$this->load->layout2('session_tracks/edit',$data);
		}
		else
		{			
			$update_status = $this->Session_Tracks_Model->updateSessionTrack();
			
			if ($update_status==true) {
				$this->session->set_flashdata('session_tracks_success', 'Updated successfully!');
				redirect('cms/session_tracks/index/'.$data['session_track']['session_id']);
			}
			else
			{
				$this->session->set_flashdata('session_tracks_edit_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout2('session_tracks/edit',$data);
			}
		}
	}
	
	public function check_access($session_id,$cnf_id) {
		
		$query = $this->db->query("SELECT * FROM sessions WHERE session_id='".$session_id."' AND cnf_id=".$cnf_id);
		
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('session_access_error','Sorry! Record not available!');
			redirect(base_url('sessions'));
		}
	}
	
	public function check_session_track()
	{
		$track_id = $this->input->post('track_id');
		$query = $this->db->query("SELECT * FROM session_tracks WHERE track_id= ".$track_id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_session_track', 'Selected Track already existed under this session.');
			return false;
		} else {
			return true;
		}
	}
	
	public function check_session_track_for_edit()
	{
		$id = $this->input->post('id');
		$track_id = $this->input->post('track_id');
		$query = $this->db->query("SELECT * FROM session_tracks WHERE track_id= ".$track_id." AND id!=".$id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_session_track_for_edit', 'Selected Track already existed under this session.');
			return false;
		} else {
			return true;
		}
	}
}