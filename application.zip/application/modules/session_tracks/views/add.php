<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Session Tracks'); ?>
		<?=view_list(base_url('cms/session_tracks/index/'.$session_id)); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('session_track_add_error')) { ?>
			<?=alert_error($this->session->flashdata('session_track_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" onsubmit="return validate()">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Track
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <select name="track_id" class="form-control chosen-select">
				<?php foreach ($tracks as $track) { ?>
					<option value="<?=$track['track_id'];?>"><?php if ($track['parent_id']!=0) echo "&#x21b3;&nbsp;"; echo $track['track_name'];?></option>
				<?php } ?>
			  </select>
			  <?php echo form_error('track_id'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Time
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				 <div class="form-inline">
					  <div class="form-group">
						<input type="text" class="form-control time" id="from_time" name="from_time" placeholder="From" readonly="true">
					  </div>
					  <div class="form-group">
						<input type="text" class="form-control time" id="to_time" name="to_time" placeholder="To" readonly="true">
					  </div>
				</div> 
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Speakers
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="form-group">
					<a href="#" class="btn btn-success plus_btn">+</a>
				</div>
				<div id="speaker_form_outer">
				</div>
				<div class="error" id="error"></div>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
				<input type="hidden" name="session_id" value="<?php echo $session_id; ?>"/>
			  <?=cancel(base_url('cms/session_tracks/index/'.$session_id));?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<style>
#speaker_form{
	background:rgba(128, 128, 128, 0.19);
	padding:5px;
}
a.plus_btn, a.minus_btn{
    margin-top: -5px;
    margin-left: 5px;
}
</style>
<script>
var parent_url = "<?php echo base_url('cms/sessions'); ?>";
var members = <?php echo json_encode($members); ?>;
var length = members.length;
var stp = <?php echo json_encode($this->input->post('speaker')); ?>;
var stpt = <?php echo json_encode($this->input->post('speaker_type')); ?>;
window.onload = function() {
	$("a.plus_btn").click(function(event){
		event.preventDefault();
		$form = $("<div class='form-inline speaker_form' id='speaker_form'></div>");
		$form_group = $("<div class='form-group'></div>");	
		$speaker = $("<select name='speaker[]' class='form-control speaker'></select>");
		$speaker.append("<option value=''>Select Speaker</option>");
		for(var i in members)
		{
			 $speaker.append("<option value='"+members[i].member_id+"'>"+members[i].name+"</option>");
		}	
		$form_group.append($speaker);	
		$form.append($form_group);
		$speaker_type = $('<div class="form-group"><select name="speaker_type[]" class="form-control speaker_type"><option value="">Select Type</option><option value="1">Keynote Speaker</option><option value="2">Speaker</option></select></div>');
		$form.append($speaker_type);
		$form.append('<div class="form-group"><a href="#" class="btn btn-success minus_btn">-</a></div><div class="error"></div>');
		
		var form_length = $("#speaker_form_outer > #speaker_form").length;
		
		if (form_length < length) {
			$("#speaker_form_outer").append($form);
			$(".minus_btn").click(function(event){
				event.preventDefault();
				$(this).closest("#speaker_form").remove();
			});
		}
	});
	
	if (stp) {
		for (var i=0; i < stp.length; i++) { 
			var x = $("a.plus_btn").click();
			$("#speaker_form_outer .speaker").eq(i).val(stp[i].speaker);
			$("#speaker_form_outer .speaker_type").eq(i).val(stpt[i].speaker_type);
		}
	}
}

function hasDuplicates(array) {
    return (new Set(array)).size !== array.length;
}

function validate() {
	var status = true;
	$('.error').each(function(){
		$(this).html("");
	});
	$(".speaker_form").each(function(){
		var speaker = $(this).find(".speaker");
		var speaker_type = $(this).find(".speaker_type");
		if (speaker.val()=="" || speaker_type.val()=="") {
			$(this).find(".error").html("Speaker selection error!");
			status = false;
		}
	});	
	
	var speakers = new Array();
	
	$(".speaker_form").each(function(){
		speakers.push($(this).find(".speaker").val());
	});	
	
	if (hasDuplicates(speakers)==true) {
		$("#error").html("Speakers repetation error!");
		status = false;
	}
	return status;
}
</script>