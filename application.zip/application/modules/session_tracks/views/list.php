<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Session Tracks'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-1">
				  <a class="btn btn-primary" href="<?php echo base_url('cms/sessions'); ?>"><i class="fa fa-arrow-left"></i> GOTO SESSIONS</a>
				</div>
			</div>
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-1">
				  <a class="btn btn-success" href="<?php echo base_url('cms/session_tracks/add/'.$session_id); ?>"><i class="fa fa-plus"></i> ADD SESSION TRACK</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php if ($this->session->flashdata('sessions_success')) { ?>
			<?=alert_success($this->session->flashdata('sessions_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('member_access_error')) { ?>
			<?=alert_error($this->session->flashdata('member_access_error')); ?>
			<?php } ?>
			<?php if (!empty($session_tracks)) { ?>
				<a class="btn btn-success" href="<?php echo base_url('cms/sessions'); ?>"><?php echo $session_tracks[0]['session_name']; ?></a>
			<?php } ?>
			<br/><br/>
			<table id="datatable" class="table table-striped table-bordered">
				<thead>
				<tr>
				  <th>Track</th>
				  <th>From</th>
				  <th>To</th>
				  <td>Action</td>
				</tr>
			  </thead>
			  <tbody>
			<?php foreach ($session_tracks as $st) { ?>
				<tr>
				  <td><?=$st['track_name']; ?></td>
				  <td><?=$st['from_time']; ?></td>
				  <td><?=$st['to_time']; ?></td>
				  <td>
					<?php echo edit(base_url('cms/session_tracks/edit'),$st['id']); ?>
				</td>
				</tr>
			<?php } ?>
			</table>
		  </div>
	  </div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/sessions'); ?>";</script>