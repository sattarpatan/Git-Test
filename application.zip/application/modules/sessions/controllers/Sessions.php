<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sessions extends my_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			
			
			
			$this->load->model('sessions/Sessions_Model');
			$this->load->model('conference/conference_model');
			$this->load->model('days/Days_Model');
			$this->load->model('members/Members_Model');
			$this->load->model('tracks/Tracks_Model');
		}
    }
	
	public function index()
	{  
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['sessions'] = $this->Sessions_Model->getSessions($cnf_id);
		$data['days'] = $this->Days_Model->getDays($cnf_id);
		$this->load->layout2('sessions/list',$data);
	}
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['days'] = $this->Days_Model->getDays($cnf_id);
		$data['members'] = $this->Members_Model->getMembers($cnf_id);
		$data['tracks'] = $this->Tracks_Model->getTracks($cnf_id);
		
		if ($this->form_validation->run('sessions_add') == FALSE)
		{			
			$this->load->layout2('sessions/add',$data);
		}
		else
		{
			
			$insert_status = $this->Sessions_Model->insertSession();
			
			if ($insert_status==true) {
				$this->session->set_flashdata('sessions_success', 'Added successfully!');
				redirect('cms/sessions');
			}
			else
			{
				$this->session->set_flashdata('sessions_add_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout2('sessions/add',$data);
			}
		}
	}
	
	public function edit($session_id)
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($session_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['session'] = $this->Sessions_Model->getSession($session_id,$cnf_id);
		$data['days'] = $this->Days_Model->getDays($cnf_id);
		$data['members'] = $this->Members_Model->getMembers($cnf_id);
		$data['tracks'] = $this->Tracks_Model->getTracks($cnf_id);
			
		if ($this->form_validation->run('sessions_edit') == FALSE)
		{			
			$this->load->layout2('sessions/edit',$data);
		}
		else
		{			
			$update_status = $this->Sessions_Model->updateSession();
			
			if ($update_status==true) {
				$this->session->set_flashdata('sessions_success', 'Updated successfully!');
				redirect('cms/sessions');
			}
			else
			{
				$this->session->set_flashdata('sessions_edit_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout2('sessions/edit',$data);
			}
		}
	}
	
	public function check_access($session_id,$cnf_id) {
		
		$query = $this->db->query("SELECT * FROM sessions WHERE session_id='".$session_id."' AND cnf_id=".$cnf_id);
		
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('session_access_error','Sorry! Record not available!');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['sessions'] = $this->Sessions_Model->getSessions($cnf_id);
			$this->load->layout2('sessions/list',$data);
			exit;
		}
	}
	
	function getSession(){
		$session_id = $this->input->post('session_id');
		$session = $this->Sessions_Model->getSession($session_id);
		echo json_encode($session);
	}
	
	function removeSession(){
		$session_id = $this->input->post('session_id');
		echo $this->Sessions_Model->removeSession($session_id);
	}
}