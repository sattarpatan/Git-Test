<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Edit Day'); ?>
		<?=view_list(base_url('cms/sessions')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('day_edit_error')) { ?>
			<?=alert_error($this->session->flashdata('day_edit_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Day
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <select name="day_id" class="form-control chosen-select">
				<?php foreach ($days as $day) { ?>
					<option value="<?=$day['day_id'];?>" <?php if ($day['day_id']==$session['day_id']) echo "selected"; ?>>Day <?php echo $day['day_no']; if ($day['day_title']) echo " : ". $day['day_title'] ?></option>
				<?php } ?>
			  </select>
			  <?php echo form_error('day_id'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Title / Label
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="session_title" class="form-control col-md-7 col-xs-12" value="<?=$session['session_title']; ?>">
			  <?php echo form_error('session_title'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Session Chair
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select class="form-control chosen-select" name="chair" id="chair">
				<?php foreach ($members as $member) { ?>
					<option>No Chair</option>
					<option value="<?=$member['member_id'];?>" <?php if ($member['member_id']==$session['chair']) echo "selected"; ?>><?=$member['name'];?></option>
				<?php } ?>
				</select>
			  <?php echo form_error('chair'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Session Co-Chair
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select class="form-control chosen-select" name="co_chair" id="co_chair">
				<?php foreach ($members as $member) { ?>
					<option>No Co-Chair</option>
					<option value="<?=$member['member_id'];?>" <?php if ($member['member_id']==$session['co_chair']) echo "selected"; ?>><?=$member['name'];?></option>
				<?php } ?>
				</select>
			  <?php echo form_error('co_chair'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Time
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				 <div class="form-inline">
					  <div class="form-group">
						<input type="text" class="form-control time" id="from_time" name="from_time" placeholder="From" value="<?=$session['from_time'];?>" readonly="true">
					  </div>
					  <div class="form-group">
						<input type="text" class="form-control time" id="to_time" name="to_time" placeholder="To" value="<?=$session['to_time'];?>" readonly="true">
					  </div>
				</div> 
			</div>
		  </div>
		   <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Status
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select class="form-control" name="session_status" id="session_status">
					<option value="1">Active</option>
					<option value="0" <?php if ($session['session_status']==0) echo "selected"; ?>>Inactive</option>
				</select>
			  <?php echo form_error('session_status'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
			   <input type="hidden" name="session_id" value="<?=$session['session_id'];?>"/>
			  <?=cancel(base_url('cms/sessions'));?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/sessions'); ?>";</script>