<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Sessions'); ?>
		<?=add(base_url('cms/sessions/add')); ?>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php if ($this->session->flashdata('sessions_success')) { ?>
			<?=alert_success($this->session->flashdata('sessions_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('session_access_error')) { ?>
			<?=alert_error($this->session->flashdata('session_access_error')); ?>
			<?php } ?>
			<?php $previous_day_id = 0; ?>
			<?php $i=0; ?>
			<?php foreach ($sessions as $session) {
			$i++;
			?>
				<?php if ($previous_day_id != $session['day_id']){ ?>
				<div class="box">
				<div class="btn btn-success" style="width:100%; font-weight:600;">Day <?=$session['day_no']; ?> : <?=$session['day_title']; ?></div>
				<table class="table table-bordered">
				<thead>
				<tr>
				  <th>Session</th>
				  <th>Chair</th>
				  <th>Co-Chair</th>
				  <th>From</th>
				  <th>To</th>
				  <th>Status</th>
				  <td>Action</td>
				</tr>
			  </thead>
				<?php } ?>
			  <tbody>
				<tr>
				  <td><?=$session['session_name']; ?></td>
				  <td><?=$session['name1']; ?></td>
				  <td><?=$session['name2']; ?></td>
				  <td><?=$session['from_time']; ?></td>
				  <td><?=$session['to_time']; ?></td>
				  <td><?=status($session['session_status']); ?></td>
				  <td>
					<a href="<?php echo base_url('cms/session_tracks/index/').$session['session_id']; ?>" class="btn btn-primary btn-xs"><i class="fa fa-navicon"></i> Tracks</a>
					<?php echo edit(base_url('cms/sessions/edit'),$session['session_id']); ?>
				</td>
				</tr>
				<?php if (isset($sessions[$i]['day_id'])) { ?>
				<?php if ($session['day_id'] != $sessions[$i]['day_id']){ ?>
				</table>
				</div>
				<?php } ?>
				<?php } ?>
				<?php $previous_day_id = $session['day_id']; ?>
			<?php } ?>
			</table>
		  </div>
	  </div>
  </div>
</div>
<style>
div.box{
	2px 2px 10px #9898ca;
	height:auto;
	border:0px;
	background-color:#fff;
}
table{
	background:rgba(245, 222, 193, 0.28);
}
table thead {
	background: tan;
    color: white;
}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
    border: 1px solid #d2b48c;
}
.table>tbody+tbody {
	border:0px;
}
</style>
<script>var parent_url = "<?php echo base_url('cms/sessions'); ?>";</script>