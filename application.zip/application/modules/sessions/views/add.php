<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Session for Scientific Program'); ?>
		<?=view_list(base_url('cms/sessions')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('session_add_error')) { ?>
			<?=alert_error($this->session->flashdata('session_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Day
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <select name="day_id" class="form-control chosen-select">
				<?php foreach ($days as $day) { ?>
					<option value="<?=$day['day_id'];?>">Day <?php echo $day['day_no']; if ($day['day_title']) echo " : ". $day['day_title'] ?></option>
				<?php } ?>
			  </select>
			  <?php echo form_error('day_id'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Title / Label
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="session_title" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('session_title'); ?>">
			  <?php echo form_error('session_title'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Session Chair
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select name="chair" id="chair" class="form-control chosen-select">
				<?php foreach ($members as $member) { ?>
					<option value="<?=$member['member_id'];?>"><?=$member['name'];?></option>
				<?php } ?>
				</select>
			  <?php echo form_error('chair'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Session Co-Chair
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select name="co_chair" id="co_chair" class="form-control chosen-select">
				<?php foreach ($members as $member) { ?>
					<option value="<?=$member['member_id'];?>"><?=$member['name'];?></option>
				<?php } ?>
				</select>
			  <?php echo form_error('co_chair'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Time
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				 <div class="form-inline">
					  <div class="form-group">
						<input type="text" class="form-control time" id="from_time" name="from_time" placeholder="From" readonly="true">
					  </div>
					  <div class="form-group">
						<input type="text" class="form-control time" id="to_time" name="to_time" placeholder="To" readonly="true">
					  </div>
				</div> 
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
			  <?=cancel(base_url('cms/sessions'));?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('cms/sessions'); ?>";
</script>