<?php

class Sessions_Model extends CI_Model {

	public function getSessions($cnf_id) {
		$sql = "SELECT s.*, d.day_no, d.day_title, IF (s.session_title='',CONCAT('Session  ',s.order_no),session_title) as session_name, m1.name name1, m2.name name2,
		f1.file_path file_path1, f2.file_path file_path2
		FROM sessions s
		LEFT JOIN members m1 ON s.chair = m1.member_id 
			LEFT JOIN filemaster f1 ON m1.file_id=f1.file_id
		LEFT JOIN members m2 ON s.co_chair = m2.member_id
			LEFT JOIN filemaster f2 ON m2.file_id=f2.file_id
		JOIN days d ON s.day_id=d.day_id
		WHERE s.cnf_id=? AND d.day_status=1 ORDER BY s.day_id ASC";
		$query = $this->db->query($sql,$cnf_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getSession($session_id,$cnf_id) {
		$sql = "SELECT * FROM sessions WHERE session_id=? AND cnf_id=?";
		$query = $this->db->query($sql,array($session_id,$cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}	
	
	public function insertSession() {
		
		$this->db->trans_start();
		
		$cnf_id = $this->session->userdata('cnf_id');
		
		$day_id = $this->input->post('day_id');
		
		$sql = "SELECT IFNULL(MAX(order_no)+1,1) as max_id FROM sessions WHERE cnf_id=? AND day_id=?";
		
		$query = $this->db->query($sql,array($cnf_id,$day_id));
		
		$data = array(
			'cnf_id'			=>	$cnf_id,
			'day_id'			=>	$day_id,
			'session_title'		=>	$this->input->post('session_title'),
			'chair'				=>	$this->input->post('chair'),
			'co_chair'			=>	$this->input->post('co_chair'),
			'from_time'			=>	$this->input->post('from_time'),
			'to_time'			=>	$this->input->post('to_time'),
			'order_no'			=>	$query->row_array()['max_id'],
			'session_status'	=>	1,
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by'		=>	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('sessions',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateSession() {
		
		$this->db->trans_start();
		
		$data = array(
			'day_id'			=>	$this->input->post('day_id'),
			'session_title'		=>	$this->input->post('session_title'),
			'chair'				=>	$this->input->post('chair'),
			'co_chair'			=>	$this->input->post('co_chair'),
			'from_time'			=>	$this->input->post('from_time'),
			'to_time'			=>	$this->input->post('to_time'),
			'session_status'	=>	$this->input->post('session_status'),
			'updated_by'		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where(array('session_id'=>$this->input->post('session_id')));
		
		$this->db->update('sessions',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}