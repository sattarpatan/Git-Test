<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
		<div class="x_title">
			<?=title('Tracks'); ?>
			<div class="nav navbar-right panel_toolbox">
				<div class="form-group">
					<div class="col-md-12 col-sm-12 col-xs-12">
					  <a class="btn btn-success" href="<?=base_url('tracks/add'); ?>">
						<i class="fa fa-plus"></i> ADD</a>
					  <a href="#" name="order" class="btn btn-success" id="update_track_order"/>
						<i class="fa fa-first-order"></i> Update Track Order</a>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="x_content">
			<?php if ($this->session->flashdata('tracks_success')) { ?>
			<?=alert_success($this->session->flashdata('tracks_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('member_access_error')) { ?>
			<?=alert_error($this->session->flashdata('member_access_error')); ?>
			<?php } ?>
			<div id="alerts"></div>
			<ul id="sortable" class="ui-sortable">
			<?php $this->load->view('tracks/table'); ?>
			</ul>
		</div>
	</div>
  </div>
</div>
<style>
#sort_icon{
	background: white;
    padding-left: 10px;
    padding-right: 10px;
    border-radius: 20px;
}	
#sortable a{border:1px solid #e6efed;}
.track_details{
	background:hsl(59, 26%, 92%);
	border:1px solid rgba(210, 195, 195, 0.2);
	margin-top:10px;
	padding-bottom:20px;
	color:#666;
}
#sortable li {
	overflow-y:auto;
	background: #e4e3e3;
    color: #044e8e;
}

#sortable li ul.sub_sortable {
	padding-left:0px;
}
#sortable li ul.sub_sortable li{
	background:#f5ebdf;
	color:#5a5555;
}

#sortable img{
	border:1px solid grey;
}

.track_no{font-weight:600;line-height:32px;}
</style>
<script>
var parent_url = "<?php echo base_url('tracks'); ?>";
var post_url = "<?=base_url('tracks/updateTrackOrder');?>";
var url = "<?=base_url('tracks');?>";
window.onload = function() {
	$("#sortable").sortable();
	$(".sub_sortable").sortable();
	
	$(".track_details_btn").click(function(){
		var that = this;
		var track_details = $(this).closest("li.ui-sortable-handle").find('.track_details');
		track_details.slideToggle(100,'swing',function(){
			$("i", that).toggleClass("fa-chevron-down fa-chevron-up");
		});
	});
	
	$("#update_track_order").click(function(){
		var order_no = $('input[name="order_no\[\]"').serializeArray();
		var sub_order_no = $('input[name="sub_order_no\[\]"').serializeArray();
		var alertMsg = $("#alerts");
		alertMsg.css("display","none");
		$.ajax({
			  type: "POST",
			  url: post_url,
			  data: {
					order_no:order_no,
					sub_order_no:sub_order_no
					},
			  success: function(resultData){
					alertMsg.html(successMsg("Tracks Order updated!")).slideDown(100);
					$("#sortable").html(resultData);
					$("#sortable").sortable();
					$(".sub_sortable").sortable();
					$(".track_details_btn").click(function(){
						var that = this;
						var track_details = $(this).closest("li.ui-sortable-handle").find('.track_details');
						track_details.slideToggle(100,'swing',function(){
							$("i", that).toggleClass("fa-chevron-down fa-chevron-up");
						});
					});
			  },
			  error: function(){
					alertMsg.html(errorMsg("Not updated, something went wrong!")).slideDown(100);
			  }
		});
	});
}
</script>