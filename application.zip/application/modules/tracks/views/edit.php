<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Edit Track'); ?>
		<?=view_list(base_url('tracks')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('tracks_edit_error')) { ?>
			<?=alert_error($this->session->flashdata('tracks_edit_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Track Name <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="track_name" class="form-control col-md-7 col-xs-12" value="<?=$track['track_name']; ?>">
			  <?php echo form_error('track_name'); ?>
			</div>
		  </div>
		  <!--
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Description
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<textarea name="track_description" rows="4" class="form-control col-md-7 col-xs-12"><?=$track['track_description']; ?></textarea>
			  <?php echo form_error('track_description'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Image 
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<?php if (!empty($track['file_path'])) { ?>
				<img src="<?php echo $track['file_path']; ?>" class="img-responsive"/><br/><br/>
				<?php } ?>
				<input type="file" name="track_image" id="track_image"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('track_image'); ?>
			</div>
		  </div>-->
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <input type="hidden" name="track_id" value="<?=$track['track_id']; ?>"/>
			  <?=cancel(base_url('tracks')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('tracks'); ?>";</script>