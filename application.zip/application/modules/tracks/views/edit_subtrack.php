<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Edit Sub Track'); ?>
		<?=view_list(base_url('tracks')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('subtracks_edit_error')) { ?>
			<?=alert_error($this->session->flashdata('subtracks_edit_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Main Track</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select name="parent_id" class="form-control">
					<?php foreach ($main_tracks as $track) { ?>
						<option value="<?php echo $track['track_id'] ?>"
						<?php if ($track['track_id']==$sub_track['parent_id']) { ?>
						<?php echo "selected"; } ?>>
						<?php echo $track['track_name']; ?>
						</option>
					<?php } ?>
				</select>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sub Track Name <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="track_name" class="form-control col-md-7 col-xs-12" value="<?=$sub_track['track_name'];?>">
			  <?php echo form_error('track_name'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <input type="hidden" name="track_id" value="<?=$sub_track['track_id'];?>"/>
			  <?=cancel(base_url('tracks')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('tracks'); ?>";</script>