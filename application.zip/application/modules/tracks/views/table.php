<?php $i=1; ?>
<?php foreach ($tracks as $track) { ?>
	<li class="ui-sortable-handle">
		<div class="row">
			<div class="col-sm-1" style="text-align:center;">
				<span class="glyphicon glyphicon-sort text-success" id="sort_icon"></span>
			</div>
			<div class="col-sm-11">
				<div class="row">
					<div class="col-sm-8">
						<div class="track_no">TRACK <?=$i++;?> : <?=$track['track_name']; ?></div>
					</div>
					<div class="col-sm-4">
						<input type="hidden" name="order_no[]" class="order_no" value="<?=$track['track_id'];?>">
						<!--
						<a href="<?php echo base_url('tracks/add_subtrack')."/".$track['track_id']; ?>" class="pull-right btn btn-info btn-xs track_details_btn"><i class="fa fa-plus"></i> Add Sub Track</a>
						-->
						<a href="<?php echo base_url('tracks/delete')."/".$track['track_id'] ?>" class="pull-right btn btn-info btn-xs track_details_btn"><i class="fa fa-trash"></i> Delete</a>
						<a class="pull-right btn btn-info btn-xs track_details_btn" href="<?php echo base_url('tracks/edit')."/".$track['track_id'] ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Track</a>
						
					</div>
				</div>							
			</div>
		</div>
		<div class="track_details" style="display:none;">
			<br/>
			<div class="container-fluid">
			<div class="row">
			<div class="col-sm-11">
				<span><b>Description :</b> <?=$track['track_description']; ?></span>
			</div>
			<div class="col-sm-1">
				<?php if ($track['file_path']) { ?>
					<img src="<?=$track['file_path'];?>" class="img-responsive"/>
				<?php } ?>
			</div>
			</div>
			<br/>
			<div class="row">
			<?php
			$subTracks = $this->Tracks_Model->getSubtracks($track['track_id']);
			$j=1;
			?>
			<ul class="sub_sortable">
			<?php foreach ($subTracks as $strack) { ?>
				<li class="ui-sortable-handle">
				<div class="container-fluid">
				<div class="row">
					<div class="col-sm-8">
						<div class="track_no">SUB TRACK <?=$j++;?> : <?=$strack['track_name']; ?></div>
					</div>
					<div class="col-sm-4">
						<input type="hidden" name="sub_order_no[]" class="order_no" value="<?=$strack['track_id'];?>">
						<a class="pull-right btn btn-info btn-xs track_details_btn" href="<?php echo base_url('tracks/edit_subtrack')."/".$strack['track_id'] ?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Sub Track</a>
					</div>
				</div>
				</div>
				</li>
			<?php } ?>
			</ul>
			</div>
		</div>
		</div>
	</li>
<?php } ?>