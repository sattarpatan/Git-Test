<?php

class Tracks_Model extends CI_Model {

	public function getTracks($cnf_id) {		
		$sql = "SELECT m.track_id, m.track_name, m.track_description, f.file_path,
    m.parent_id, m.order_no, p.order_no as p_order_no, (case  WHEN p.order_no IS NULL THEN m.order_no * 10
        ELSE m.order_no + p.order_no * 100 END) AS parentId FROM tracks m
    LEFT JOIN tracks p ON m.parent_id = p.track_id LEFT JOIN filemaster f
    ON f.file_id = m.file_id WHERE m.cnf_id=? ORDER BY parentId";
	
		$query = $this->db->query($sql,$cnf_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getMainTracks($cnf_id) {
		$sql = "SELECT t.*, f.file_path FROM tracks t LEFT JOIN filemaster f ON t.file_id=f.file_id WHERE t.cnf_id=? AND t.parent_id=0 ORDER BY t.order_no ASC";
	
		$query = $this->db->query($sql,$cnf_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getSubTracks($track_id) {
		$sql = "SELECT t.*, f.file_path FROM tracks t LEFT JOIN filemaster f ON t.file_id=f.file_id WHERE t.parent_id=? ORDER BY t.order_no ASC";
		$query = $this->db->query($sql,$track_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getTrack($track_id) {
		$sql = "SELECT t.*, f.file_path FROM tracks t LEFT JOIN filemaster f ON t.file_id=f.file_id WHERE t.track_id=?";
		$query = $this->db->query($sql,array($track_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function updateTrackOrder($trackOrder,$subTrackOrder) {
		
		$this->db->trans_start();
		
		$i=1;
		
		foreach ($trackOrder as $order_no => $track) {
			
			$data = array(
				'order_no' 			=> 	$i++,
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
			$this->db->where('track_id',$track['value']);
			$this->db->update('tracks',$data);
			
			$j=1;
			
			if (!empty($subTrackOrder)) {
				
				foreach ($subTrackOrder as $order_no => $subTrack) {
					
					$sql = "SELECT * FROM tracks WHERE parent_id=".$track['value']." AND track_id=".$subTrack['value'];
					
					$query = $this->db->query($sql);
					
					if ($query->num_rows()>0) {					
						$data = array(
						'order_no' 			=> 	$j++,
						'updated_by' 		=> 	$this->session->userdata('user_id'),
						'updated_datetime'	=>	date('Y-m-d H:i:s')
						);
						$this->db->where(array(
							'track_id'=>$subTrack['value'],
							'parent_id'=>$track['value']
						));
						$this->db->update('tracks',$data);
					}
				}
			}
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}		
	}
	
	public function insertTrack($cnf_id,$filepath) {
		
		$insert_id = false;
		
		$this->db->trans_start();
		
		if ($filepath!=false) {
			
			$data = array(
				'file_path' 		=> 	$filepath,
				'title_desc'		=>	$this->input->post('track_name'),
				'cnf_id'			=>	$this->session->userdata('cnf_id'),
				'created_by'		=> 	$this->session->userdata('user_id'),
				'created_datetime'	=>	date('Y-m-d H:i:s')
			);
			
			$this->db->insert('filemaster',$data);
			
			$insert_id = $this->db->insert_id();
		
		}
		
		$sql = "SELECT max(order_no)+1 as max_id FROM tracks WHERE parent_id=0";
		$query = $this->db->query($sql,$this->input->post('track_id'));
		
		$data = array(
			'track_name' 		=> 	$this->input->post('track_name'),
			'track_slug'		=>	sluggify_string($this->input->post('track_name')),
			'track_description'	=> 	$this->input->post('track_description'),
			'file_id'			=>	$insert_id,
			'cnf_id'			=>	$cnf_id,
			'order_no'			=>	$query->row_array()['max_id'],
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('tracks',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	
	public function insertSubTrack() {
	
		$cnf_id = $this->session->userdata('cnf_id');
		
		$this->db->trans_start();
		
		$sql = "SELECT max(order_no)+1 as max_id FROM tracks WHERE parent_id=?";
		$query = $this->db->query($sql,$this->input->post('track_id'));
		
		$data = array(
			'track_name' 		=> 	$this->input->post('track_name'),
			'track_slug'		=>	sluggify_string($this->input->post('track_name')),
			'parent_id'			=>	$this->input->post('parent_id'),
			'cnf_id'			=>	$cnf_id,
			'order_no'			=>	$query->row_array()['max_id'],
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('tracks',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateTrack($filepath) {
		
		$cnf_id = $this->session->userdata('cnf_id');
		$track_id = $this->input->post('track_id');
		
		$this->db->trans_start();
		
		//IF FILE UPLOADED
		if ($filepath==true) {			
			$sql = "SELECT * FROM tracks WHERE track_id=?";
			$query = $this->db->query($sql,$track_id);
			$file_id = $query->row_array()['file_id'];
			
			if ($file_id > 0) {				
				$data = array(
					'file_path' 		=> 	$filepath,
					'title_desc'		=>	$this->input->post('track_name'),
					'cnf_id'			=>	$cnf_id,
					'created_by'		=> 	$this->session->userdata('user_id'),
					'created_datetime'	=>	date('Y-m-d H:i:s')
				);				
				$this->db->where('file_id',$file_id);
				$this->db->update('filemaster',$data);			
			}
			else
			{
				$data = array(
					'file_path' 		=> 	$filepath,
					'title_desc'		=>	$this->input->post('track_name'),
					'cnf_id'			=>	$cnf_id,
					'created_by'		=> 	$this->session->userdata('user_id'),
					'created_datetime'	=>	date('Y-m-d H:i:s')
				);
				$this->db->insert('filemaster',$data);
				$file_id = $this->db->insert_id();
			}
		}

		if ($filepath==true) {			
			$data = array(
				'file_id'			=>	$file_id,
				'track_name' 		=> 	$this->input->post('track_name'),
				'track_slug'		=>	sluggify_string($this->input->post('track_name')),
				'track_description'	=> 	$this->input->post('track_description'),
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
		}
		else
		{
			$data = array(
				'track_name' 		=> 	$this->input->post('track_name'),
				'track_slug'		=>	sluggify_string($this->input->post('track_name')),
				'track_description'	=> 	$this->input->post('track_description'),
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
		}
		
		$this->db->where('track_id',$this->input->post('track_id'));
		
		$this->db->update('tracks',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateSubTrack() {
		
		$cnf_id = $this->session->userdata('cnf_id');
		
		$this->db->trans_start();
		
		$data = array(
			'track_name' 		=> 	$this->input->post('track_name'),
			'track_slug'		=>	sluggify_string($this->input->post('track_name')),
			'parent_id'			=>  $this->input->post('parent_id'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where('track_id',$this->input->post('track_id'));
		
		$this->db->update('tracks',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}
/*****end of the file****/