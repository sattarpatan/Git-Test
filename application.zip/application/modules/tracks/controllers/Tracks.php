<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracks extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('conference/conference_model');
			$this->load->model('tracks/Tracks_Model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
			
		}
    }
	
	public function updateTrackOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$trackOrder = $this->input->post('order_no');
		$subTrackOrder = $this->input->post('sub_order_no');
		$result = $this->Tracks_Model->updateTrackOrder($trackOrder,$subTrackOrder);
		if ($result == true) {
			$data['tracks'] = $this->Tracks_Model->getMainTracks($cnf_id);
			return $this->load->view('tracks/table',$data);
		} else {
			return false;
		}
	}
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['tracks'] = $this->Tracks_Model->getMainTracks($cnf_id);
		//$this->load->layout2('tracks/list',$data);
		
		$data['_view'] = 'tracks/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function add()
	{	
		$filePath = false;
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Track Image',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('tracks_add') == FALSE)
		{			
			$data['_view'] = 'tracks/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			if (!empty($_FILES['track_image']['name']))
			{				
				$sql = "SELECT max(track_id)+1 as track_id FROM tracks WHERE cnf_id=?";
				$query = $this->db->query($sql,$cnf_id);
				$result = $query->row_array();				
				$newFileName = $this->createFileName($result['track_id'],$cnf_id);
				$newFile = TRACK_IMAGES.$newFileName;
				
				$this->load->library('../controllers/upload');
				
				$upload_status = $this->upload->doUpload($_FILES['track_image'], $newFile, $data['upload_settings']);
				
				if ($upload_status==false)
				{
					$this->session->set_flashdata('track_add_error', 'File uploading error!'); 
					$data['_view'] = 'tracks/add';
					$this->load->view('layouts/main',$data);
				}
				else
				{
					$filePath = S3_PATH.$newFile;
				}
			}
			
			$status = $this->Tracks_Model->insertTrack($cnf_id,$filePath);
			
			if ($status==true) {
				$this->session->set_flashdata('tracks_success', 'Track added successfully!');
				redirect('tracks');
			}
			else
			{
				$this->session->set_flashdata('tracks_add_error', 'Sorry! Something went wrong. Try Again.');
				$data['_view'] = 'tracks/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function delete($track_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		
		$query = $this->db->get_where('tracks',
			array(
			'cnf_id' => $cnf_id,
			'track_id'	=> $track_id)
		);
		
		if ($query->num_rows()==1) {
			
			$this->db->where('track_id',$track_id);
			
			$this->db->delete('tracks');
			
			$this->session->set_flashdata('tracks_success', 'Track deleted successfully.');
			
		} 
			
		redirect('tracks');
	}
	
	public function add_subtrack($track_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['main_tracks'] = $this->Tracks_Model->getMainTracks($cnf_id);
		$this->check_access($track_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		
		if ($this->form_validation->run('subtracks_add') == FALSE)
		{			
			//$this->load->layout2('tracks/add_subtrack',$data);
			
			$data['_view'] = 'tracks/add_subtrack';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			$status = $this->Tracks_Model->insertSubTrack();
			
			if ($status==true) {
				$this->session->set_flashdata('subtracks_success', 'Sub Track added successfully!');
				redirect('tracks');
			}
			else
			{
				$this->session->set_flashdata('subtracks_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('tracks/add_subtrack',$data);
				
				$data['_view'] = 'tracks/add_subtrack';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	
	public function edit_subtrack($sub_track_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['main_tracks'] = $this->Tracks_Model->getMainTracks($cnf_id);
		$data['sub_track'] = $this->Tracks_Model->getTrack($sub_track_id);
		$this->check_access($sub_track_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		
		if ($this->form_validation->run('subtracks_edit') == FALSE)
		{			
			//$this->load->layout2('tracks/edit_subtrack',$data);
			
			$data['_view'] = 'tracks/edit_subtrack';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			$status = $this->Tracks_Model->updateSubTrack();
			
			if ($status==true) {
				$this->session->set_flashdata('subtracks_success', 'Sub Track updated successfully!');
				redirect('tracks');
			}
			else
			{
				$this->session->set_flashdata('subtracks_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('tracks/edit_subtrack',$data);
				
				$data['_view'] = 'tracks/edit_subtrack';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($track_id)
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($track_id,$cnf_id);
		$filePath = false;
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['track'] = $this->Tracks_Model->getTrack($track_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Track Image');
			
		if ($this->form_validation->run('tracks_edit') == FALSE)
		{			
			//$this->load->layout2('tracks/edit',$data);
			
			$data['_view'] = 'tracks/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			if (!empty($_FILES['track_image']['name']))
			{
				$newFileName = $this->createFileName($this->input->post('track_id'),$cnf_id);
				$newFile = TRACK_IMAGES.$newFileName;
			
				$this->load->library('../controllers/upload');
				
				$upload_status = $this->upload->doUpload($_FILES['track_image'], $newFile, $data['upload_settings']);
				
				if ($upload_status==false)
				{
					$this->session->set_flashdata('track_add_error', 'File uploading error!'); 
					//$this->load->layout2('tracks/add',$data);
					
					$data['_view'] = 'tracks/add';
					$this->load->view('layouts/main',$data);
					exit;
				}
				else
				{
					$filePath = S3_PATH.$newFile;
				}
			}
			
			$edit_status = $this->Tracks_Model->updateTrack($filePath);
			
			if ($edit_status==true) {
				$this->session->set_flashdata('tracks_success', 'Track updated successfully.');
				redirect('tracks');
			}
			else
			{
				$this->session->set_flashdata('tracks_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('tracks/edit',$data);
				$data['_view'] = 'tracks/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function createFileName($track_id,$cnf_id) {		
		$ext = pathinfo($_FILES['track_image']['name'], PATHINFO_EXTENSION);
		return sluggify_string($this->input->post('track_name'))."_".$track_id."_".$cnf_id.".".$ext;
	}
	
	function check_access($track_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM tracks WHERE track_id='".$track_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! Track not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['tracks'] = $this->Tracks_Model->getTracks($cnf_id);
			//$this->load->layout2('tracks/list',$data);
			
			$data['_view'] = 'tracks/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function check_track_name() {
		$track_name = $this->input->post('track_name');
		$cnf_id = $this->session->userdata('cnf_id');
		$query = $this->db->query("SELECT * FROM tracks WHERE track_name like '".$track_name."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_track_name', $track_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
	
	public function check_track_name_for_edit() {
		$track_name = $this->input->post('track_name');
		$track_id = $this->input->post('track_id');
		$cnf_id = $this->session->userdata('cnf_id');
		$query = $this->db->query("SELECT * FROM tracks WHERE track_name like '".$track_name."' AND track_id!=".$track_id." AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_track_name_for_edit', $track_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
}

/***/