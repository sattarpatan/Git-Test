<?php

class Currencies_Model extends CI_Model {

	public function getCurrencies($status=null) {
		
		if ($status==null) {
			$sql = "SELECT * FROM currencies";
		} else {
			$sql = "SELECT * FROM currencies WHERE status=$status";
		}
		
		$query = $this->db->query($sql);
			
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getCurrency($currency_id) {
		$sql = "SELECT * FROM currencies WHERE currency_id=?";
		$query = $this->db->query($sql,array($currency_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function insertCurrency() {
		
		$this->db->trans_start();
		
		$data = array(
			'currency_code' 	=> 	clean_title($this->input->post('currency_code')),
			'currency_symbol' 	=> 	$this->input->post('currency_symbol'),
			'status'			=>	1,
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('currencies',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateCurrency() {
		
		$this->db->trans_start();
				
		$data = array(
			'currency_code' 	=> 	clean_title($this->input->post('currency_code')),
			'currency_symbol' 	=> 	$this->input->post('currency_symbol'),
			'status'			=>	$this->input->post('status'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where('currency_id',$this->input->post('currency_id'));
		
		$this->db->update('currencies',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}