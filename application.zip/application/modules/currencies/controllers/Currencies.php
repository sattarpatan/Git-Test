<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Currencies extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin") {
			//$this->load->layout1('general/no_access');
			$data['_view'] = 'general/list';
			$this->load->view('layouts/no_access',$data);
			exit;
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('currencies/Currencies_Model');
		}
    }
	
	public function index()
	{
		$data['currencies'] = $this->Currencies_Model->getCurrencies();
		//$this->load->layout1('currencies/list',$data);
		
		$data['_view'] = 'currencies/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function get_list()
	{
		$data['currencies'] = $this->Currencies_Model->getCurrencies();
		return $this->load->view('currencies/table',$data);
	}
	
	public function add()
	{
		
		if ($this->form_validation->run('currencies_add') == FALSE)
		{			
			//$this->load->layout1('currencies/add');
			
			$data['_view'] = 'currencies/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$insert_status = $this->Currencies_Model->insertCurrency();
			
			if ($insert_status==true) {
				$this->session->set_flashdata('currencies_success', 'Setting added successfully!');
				redirect('currencies');
			}
			else
			{
				$this->session->set_flashdata('currencies_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout1('currencies/add');
				
				$data['_view'] = 'currencies/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($currency_id)
	{
		
		$data['currency'] = $this->Currencies_Model->getCurrency($currency_id);
			
		if ($this->form_validation->run('currencies_edit') == FALSE)
		{			
			//$this->load->layout1('currencies/edit',$data);
			
			$data['_view'] = 'currencies/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			$edit_status = $this->Currencies_Model->updateCurrency();
			
			if ($edit_status==true) {
				
				$this->session->set_flashdata('currencies_success', 'Updated successfully.');
				redirect('currencies');
			}
			else
			{
				$this->session->set_flashdata('currency_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout1('currencies/edit',$data);
				
				$data['_view'] = 'currencies/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function check_currency_code()
	{
		$currency_code = $this->input->post('currency_code');
		
		$query = $this->db->query("SELECT * FROM currencies WHERE currency_code like '".$currency_code."'");
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_currency_code', $currency_code.' already existed.');
			return false;
		} else {
			return true;
		}
	}
}