<table id="datatable" class="table table-striped table-bordered">
	<thead>
	<tr>
	  <th>Currency Code</th>
	  <th>Currency Symbol</th>
	  <th>Status</th>
	  <th>Action</th>
	</tr>
  </thead>
  <tbody>
<?php foreach ($currencies as $currency) { ?>
	<tr>
	  <td><?=$currency['currency_code']; ?></td>
	  <td><?=$currency['currency_symbol']; ?></td>
	  <td><?=status($currency['status']); ?></td>
	  <td>
	  <?php echo edit(base_url('currencies/edit'),$currency['currency_id']); ?>
	  </td>
	</tr>
<?php } ?>
</table>