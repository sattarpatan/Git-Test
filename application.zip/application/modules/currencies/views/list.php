<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Currency Details'); ?>
		<?=add(base_url('currencies/add')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
			<?php if ($this->session->flashdata('currencies_success')) { ?>
			<?=alert_success($this->session->flashdata('currencies_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('currencies_access_error')) { ?>
			<?=alert_error($this->session->flashdata('currencies_access_error')); ?>
			<?php } ?>
			<div id="table">
			<?php $this->load->view('currencies/table',$currencies); ?>
			</div>
		</div>
	</div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('currencies'); ?>";
var url = "<?php echo base_url('currencies/get_list'); ?>";
</script>