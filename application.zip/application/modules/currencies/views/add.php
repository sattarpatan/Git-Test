<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Currencies'); ?>
		<?=view_list(base_url('currencies')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('currency_add_error')) { ?>
			<?=alert_error($this->session->flashdata('currency_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Currency Code <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="currency_code" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('currency_code'); ?>">
			  <?php echo form_error('currency_code'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Currency Symbol <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="currency_symbol" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('currency_symbol'); ?>">
			  <?php echo form_error('currency_symbol'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <?=cancel(base_url('currencies')); ?>
			  <input type="hidden" name="companies" id="companies" value=''/>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('currencies'); ?>";</script>