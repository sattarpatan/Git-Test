<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Hilaris Conferences | ACS</title>

    <!-- Bootstrap -->
    <link href="<?=ASSETS_CMS; ?>vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=ASSETS_CMS; ?>vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?=ASSETS_CMS; ?>vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?=ASSETS_CMS; ?>vendors/animate.css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?=ASSETS_CMS; ?>build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form" style="border: 1px solid #081d1f;
    padding: 20px; background: white;">
          <section class="login_content">
             <div class="separator">

                <div class="clearfix"></div>
                <br />

            <div>
                  <img src="<?php echo base_url();?>assets/cms/images/hilaris-logo.png">
                </div>
            </div>
			
			<form name="login" id="login" action="" method="post">
              <h1>Control Panel</h1>
              <div>
                <input type="text" class="form-control parsley-error" name="user_name" placeholder="Username" />
				<?php echo form_error('user_name'); ?>
              </div>
              <div>
                <input type="password" class="form-control parsley-error" name="user_password" placeholder="Password" />
				<?php echo form_error('user_password'); ?>
              </div>
              <div>
                <input type="submit" name="submit" value="Log in" class="btn btn-primary submit"/>
				
              </div>
			  
			  <?php echo form_error('check_login'); ?>

              <div class="clearfix"></div>

             
            </form>
          </section>
        </div>

        </div>
    </div>
  </body>
</html>