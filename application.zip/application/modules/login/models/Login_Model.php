<?php

class Login_Model extends CI_Model {
	
	public function checkLogin($user_name,$user_password) {
		$sql = "SELECT * FROM users WHERE binary user_name=? AND user_status=?";
		$query = $this->db->query($sql, array($user_name,1));
		$cnt = $query->num_rows();
		if ($cnt==1) {			
			$result = $query->row_array();
			$db_username = $result['user_name'];
			$db_password = $result['user_password'];
			$enc_password = md5($user_password);
			if($user_name==$db_username&&$enc_password==$db_password)
			{
				return true;
			}
			else
			{
				return false;
			}
		} else {
			return false;
		}
	}
	
	public function getUser($user_name) {
		$sql = "SELECT * FROM users WHERE user_name=? AND user_status=?";
		$query = $this->db->query($sql, array($user_name,1));
		return $query->row_array();
	}
}