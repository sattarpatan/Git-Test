<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function __construct()
	{
        parent::__construct();
        $this->load->model('Login_Model');
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		//$this->output->enable_profiler(true);
    } 
	
	public function index()
	{	
		
		if ($this->form_validation->run('login') == FALSE)
		{			
			$this->load->view('login/index');
		}
		else
		{	
			$user_name = $this->input->post('user_name');
			$user = $this->Login_Model->getUser($user_name);
			$this->session->set_userdata(array(
				'user_name' => $user['user_name'],
				'user_email' => $user['user_email'],
				'user_id' => $user['user_id'],
				'user_type' => $user['user_type'],
				'user_displayname' => $user['user_displayname'],
				'user_login' => "Y"
			));
			//redirect('cms/conferences');
			if($user['user_type'] == "OPERATIONS")
			{
				redirect('cms/subscription');
			}else{
				redirect('cms/conferences');
			}
		}
	}
	
	public function check_login ()
	{
		$user_name = $this->input->post('user_name');
		$user_password = $this->input->post('user_password');
		$status = $this->Login_Model->checkLogin($user_name,$user_password);
		
		if ($status==true) {
			return true;
		} else {
			$this->form_validation->set_message('check_login', 'Username or Password wrong!');
			return false;
		}
	}	
}