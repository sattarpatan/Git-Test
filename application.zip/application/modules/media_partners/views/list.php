<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Media Partners'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <a class="btn btn-success" href="<?=base_url('media_partners/add'); ?>">
					<i class="fa fa-plus"></i> ADD</a>
				  <a href="#" name="order" class="btn btn-success" id="update_order"/>
					<i class="fa fa-first-order"></i> Update Order</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
		<?php if ($this->session->flashdata('media_partners_success')) { ?>
		<?=alert_success($this->session->flashdata('media_partners_success')); ?>
		<?php } ?>
		<div id="alerts"></div>
		<div class="row" id="sortable">
			<?php $this->load->view('media_partners/table'); ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete Media Partner</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="deleteMediaPartner()">Delete</button>
		<input type="hidden" name="media_partner_id" id="media_partner_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var order_url = "<?php echo base_url('media_partners/updateOrder'); ?>";
var get_media_partner_url = "<?php echo base_url('media_partners/getMediaPartner'); ?>";
var delete_url = "<?php echo base_url('media_partners/deleteMediaPartner'); ?>";
window.onload = function() {
	$("#sortable").sortable();	
	$("#update_order").click(function(){
		var order = $('input[name="order\[\]"').serializeArray();
		var alertMsg = $("#alerts");
		alertMsg.css("display","none");
		$.ajax({
			  type: "POST",
			  url: order_url,
			  data: {order:order},
			  success: function(resultData){
					alertMsg.html(successMsg("Media_Partners Order updated!")).slideDown(100);
					$("#sortable").html(resultData);
					$("#sortable").sortable();
			  },
			  error: function(){
					alertMsg.html(errorMsg("Not updated, something went wrong!")).slideDown(100);
			  }
		});
	});
}
function modalBanner(media_partner_id){
	$.ajax({
		  type: "POST",
		  url:get_media_partner_url,
		  data:{media_partner_id:media_partner_id},
		  dataType:"json",
		  success:function(response){
			 var file = response.file_path;
			 $("#media_partner_id").val(media_partner_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><h4 class='text-danger'>Are you sure you want to delete this media partner?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function deleteMediaPartner(){
	var alertMsg = $("#alerts");
	alertMsg.css("display","none");
    $.ajax({
		  type: "POST",
		  url:delete_url,
		  data:{media_partner_id:$("#media_partner_id").val()},
		  success:function(response){
			  if (response==false) {
				  alertMsg.html(errorMsg("Something went wrong.")).slideDown(100);
			  } else {
				  $("#sortable").html(response);
				  alertMsg.html(successMsg("Deleted!")).slideDown(100);
			  }
			  $('#myModal').modal('hide');
		  }
	});
}
</script>