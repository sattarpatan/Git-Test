<?php if (empty($media_partners)) { ?>
<p>No Media Partners Available!</p>
<?php } else { ?>
<?php foreach ($media_partners as $media_partner) { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $media_partner['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
			<a href="<?php echo $media_partner['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="<?php echo base_url('media_partners/edit/').$media_partner['media_partner_id']; ?>" title="Edit"><i class="fa fa-pencil"></i></a>
			<a href="<?php echo base_url('media_partners/forceDownload/').$media_partner['media_partner_id']; ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			<a href="javascript:modalBanner(<?=$media_partner['media_partner_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	  <div class="caption">
		<strong><?=$media_partner['title_desc']; ?></strong>
		<p><?=$media_partner['link_url']; ?></p>
	  </div>
	</div>
	<input type="hidden" name="order[]" class="order" value="<?=$media_partner['media_partner_id'];?>">
</div>
<?php } ?>
<?php } ?>