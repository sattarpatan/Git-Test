<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Media_partners extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('media_partners/media_partners_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
			
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['media_partners'] = $this->media_partners_model->getMediaPartners($cnf_id);
		//$this->load->layout2('media_partners/list',$data);
		
		$data['_view'] = 'media_partners/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Media Partner',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('media_partners_add') == FALSE)
		{			
			//$this->load->layout2('media_partners/add',$data);
			$data['_view'] = 'media_partners/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(media_partner_id)+1 as media_partner_id FROM media_partners";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['media_partner_id'],$cnf_id);
			$newFile = MEDIA_PARTNER_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('media_partner_add_error', 'File uploading error!'); 
				//$this->load->layout2('media_partners/add',$data);
				$data['_view'] = 'media_partners/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->media_partners_model->insertMediaPartner($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('media_partners_success', 'Media Partner added successfully!');
					redirect('media_partners');
				}
				else
				{
					$this->session->set_flashdata('media_partner_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('media_partners/add',$data);
					$data['_view'] = 'media_partners/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function edit($id){
		
		if(empty($id))
		{
			redirect('media_partners');
			exit;
		}
		
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Collaboration',$this->session->userdata('company_id'));
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['media_partners'] = $this->media_partners_model->getMediaPartner($id);
		if(empty($data['media_partners']))
		{
			redirect('media_partners');
			exit;
		}
		
		if ($this->input->post('update')=="Update")
		{
			if(!empty($_FILES['file']['name']) && $_FILES['file']['name']!="")
			{
			
				$newFile = COLLABORATION_IMAGES.$_FILES['file']['name'];
				
				$this->load->library('../controllers/upload');
				
				$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
				
				if ($upload_status==false)
				{
					$this->session->set_flashdata('media_partner_add_error', 'File uploading error!'); 
					//$this->load->layout2('media_partners/edit',$data);
					$data['_view'] = 'media_partners/edit';
					$this->load->view('layouts/main',$data);
				}
				else
				{
					$filePath = S3_PATH.$newFile;
					
					$update_status = $this->media_partners_model->updateMediaPartner($filePath, $id);
					
					if ($update_status==true) {
						$this->session->set_flashdata('media_partners_success', 'Media Partner added successfully!');
						redirect('media_partners');
					}
					else
					{
						$this->session->set_flashdata('media_partner_add_error', 'Sorry! Something went wrong. Try Again.');
						//$this->load->layout2('media_partners/add',$data);
						$data['_view'] = 'media_partners/add';
						$this->load->view('layouts/main',$data);
					}
				 }
			}else{				
				
				$update_status = $this->media_partners_model->updateMediaPartner($filePath=NULL, $id);
					
				if ($update_status==true) {
					$this->session->set_flashdata('media_partners_success', 'Media Partner added successfully!');
					redirect('media_partners');
				}
			}	 
		}
		
		//$this->load->layout2('media_partners/edit',$data);
		$data['_view'] = 'media_partners/edit';
		$this->load->view('layouts/main',$data);		

	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->media_partners_model->getMediaPartner($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteMediaPartner(){
		$cnf_id = $this->session->userdata('cnf_id');
		$media_partner_id = $this->input->post('media_partner_id');
		$media_partner = $this->media_partners_model->getMediaPartner($media_partner_id);
		$file = $media_partner['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->media_partners_model->deleteMediaPartner($media_partner_id);
			$data['media_partners'] = $this->media_partners_model->getMediaPartners($cnf_id);
			return $this->load->view('media_partners/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($media_partner_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM media_partners WHERE media_partner_id='".$media_partner_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['media_partners'] = $this->media_partners_model->getMediaPartners($cnf_id);
			//$this->load->layout2('media_partners/list',$data);
			$data['_view'] = 'media_partners/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->media_partners_model->updateOrder($order);
		if ($result == true) {
			$data['media_partners'] = $this->media_partners_model->getMediaPartners($cnf_id);
			return $this->load->view('media_partners/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($media_partner_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$media_partner_id.".".$fileinfo['extension'];
	}
	
	function getMediaPartner(){
		$media_partner_id = $this->input->post('media_partner_id');
		$media_partner = $this->media_partners_model->getMediaPartner($media_partner_id);
		echo json_encode($media_partner);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
	
	function valid_url_format($str){
		if (!$str){
			return true;
		}
        $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
        if (!preg_match($pattern, $str)){
            $this->form_validation->set_message('valid_url_format', 'The {field} you entered is not correct. Ex : http://www.example.com');
            return FALSE;
        }
 
        return TRUE;
    }
}
