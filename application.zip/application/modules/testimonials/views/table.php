<?php if (empty($testimonials)) { ?>
<p>No Testimonials Available!</p>
<?php } else { ?>
<?php foreach ($testimonials as $testimonial) { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $testimonial['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
			<a href="<?php echo $testimonial['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="<?=base_url('testimonials/edit/'.$testimonial['testimonial_id']);?>" title="Edit"><i class="fa fa-pencil"></i></a>
			<a href="<?php echo base_url('testimonials/forceDownload/').$testimonial['testimonial_id']; ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			<a href="javascript:modalTestimonial(<?=$testimonial['testimonial_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	  <div class="caption">
		<strong>Name : <?=$testimonial['name']; ?></strong>
		<p><?=$testimonial['link_url']; ?></p>
	  </div>
	</div>
	<input type="hidden" name="order[]" class="order" value="<?=$testimonial['testimonial_id'];?>">
</div>
<?php } ?>
<?php } ?>