<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Testimonial'); ?>
		<?=view_list(base_url('testimonials')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('testimonials_edit_error')) { ?>
			<?=alert_error($this->session->flashdata('testimonials_edit_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Testimonial <span class="required">*</span></label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<textarea name="testimonial" rows="5" class="form-control col-md-7 col-xs-12"><?=$testimonial['testimonial']; ?></textarea>
				  <?php echo form_error('testimonial'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Name
				<span class="required">*</span></label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="name" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['name']; ?>">
				  <?php echo form_error('name'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Designation
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="designation" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['designation']; ?>">
				  <?php echo form_error('designation'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">University
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="university" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['university']; ?>">
				  <?php echo form_error('university'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Email
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="email" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['email']; ?>">
				  <?php echo form_error('email'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Address
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="address" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['address']; ?>">
				  <?php echo form_error('address'); ?>
				</div>
		  </div>
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Country
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
				  <input type="text" name="country" class="form-control col-md-7 col-xs-12" value="<?=$testimonial['country']; ?>">
				  <?php echo form_error('country'); ?>
				</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Testimonial Image <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<?php if (!empty($testimonial['file_path'])) { ?>
				<img src="<?php echo $testimonial['file_path']; ?>" class="img-responsive"/><br/><br/>
				<?php } ?>
				<input type="file" name="file" id="file"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('file'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <input type="hidden" name="testimonial_id" value="<?=$testimonial['testimonial_id']; ?>"/>
			  <?=cancel(base_url('testimonials')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('testimonials'); ?>";</script>