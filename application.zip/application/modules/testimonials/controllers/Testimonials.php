<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testimonials extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('testimonials/testimonials_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
			
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['testimonials'] = $this->testimonials_model->getTestimonials($cnf_id);
		
		//$this->load->layout2('testimonials/list',$data);
		
		$data['_view'] = 'testimonials/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Testimonial',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('testimonials_add') == FALSE)
		{			
			//$this->load->layout2('testimonials/add',$data);
			
			$data['_view'] = 'testimonials/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(testimonial_id)+1 as testimonial_id FROM testimonials";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['testimonial_id'],$cnf_id);
			$newFile = TESTIMONIAL_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('testimonials_add_error', 'File uploading error!'); 
				//$this->load->layout2('testimonials/add',$data);
				
				$data['_view'] = 'testimonials/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->testimonials_model->insertTestimonial($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('testimonials_success', 'Testimonial added successfully!');
					redirect('testimonials');
				}
				else
				{
					$this->session->set_flashdata('testimonials_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('testimonials/add',$data);
					
					$data['_view'] = 'testimonials/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function edit($testimonial_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($testimonial_id,$cnf_id);
		$filePath = false;
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['testimonial'] = $this->testimonials_model->getTestimonial($testimonial_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Testimonial',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('testimonials_edit') == FALSE)
		{			
			//$this->load->layout2('testimonials/edit',$data);
			
			$data['_view'] = 'testimonials/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			if (!empty($_FILES['file']['name']))
			{
				$newFileName = $this->createFileName($this->input->post('testimonial_id'),$cnf_id);
				$newFile = TESTIMONIAL_IMAGES.$newFileName;
			
				$this->load->library('../controllers/upload');
				
				$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
				
				if ($upload_status==false)
				{
					$this->session->set_flashdata('testimonials_edit_error', 'File uploading error!'); 
					//$this->load->layout2('testimonials/edit',$data);
					
					$data['_view'] = 'testimonials/edit';
					$this->load->view('layouts/main',$data);
				}
				else
				{
					$filePath = S3_PATH.$newFile;
				}
			}
			
			$edit_status = $this->testimonials_model->updateTestimonial($filePath);
			
			if ($edit_status==true) {
				$this->session->set_flashdata('testimonials_success', 'Testimonial updated successfully.');
				redirect('testimonials');
			}
			else
			{
				$this->session->set_flashdata('testimonials_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('testimonials/edit',$data);
				
				$data['_view'] = 'testimonials/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function forceDownload($record_id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($record_id,$cnf_id);
		$record = $this->testimonials_model->getTestimonial($record_id);
		$this->load->helper('download');
		$fileContents = file_get_contents($record['file_path']);
		force_download($record['file_path'],$fileContents);
		exit;
	}
	
	function check_access($testimonial_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM testimonials WHERE testimonial_id='".$testimonial_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! Testimonial not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['testimonials'] = $this->testimonials_model->getTestimonials($cnf_id);
			//$this->load->layout2('testimonials/list',$data);
			
			$data['_view'] = 'testimonials/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	function deleteTestimonial(){
		$cnf_id = $this->session->userdata('cnf_id');
		$testimonial_id = $this->input->post('testimonial_id');
		$testimonial = $this->testimonials_model->getTestimonial($testimonial_id);
		$file = $testimonial['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->testimonials_model->deleteTestimonial($testimonial_id);
			$data['testimonials'] = $this->testimonials_model->getTestimonials($cnf_id);
			return $this->load->view('testimonials/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->testimonials_model->updateOrder($order);
		if ($result == true) {
			$data['testimonials'] = $this->testimonials_model->getTestimonials($cnf_id);
			return $this->load->view('testimonials/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($testimonial_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('name')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$testimonial_id.".".$fileinfo['extension'];
	}
	
	function getTestimonial(){
		$testimonial_id = $this->input->post('testimonial_id');
		$testimonial = $this->testimonials_model->getTestimonial($testimonial_id);
		echo json_encode($testimonial);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
}
/**********/