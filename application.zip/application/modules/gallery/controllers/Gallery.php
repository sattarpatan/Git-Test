<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('gallery/gallery_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['gallery'] = $this->gallery_model->getGallery($cnf_id);
		
		//$this->load->layout2('gallery/list',$data);
		$data['_view'] = 'gallery/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Gallery',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('gallery_add') == FALSE)
		{			
			$data['_view'] = 'gallery/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(gallery_id)+1 as gallery_id FROM gallery";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['gallery_id'],$cnf_id);
			$newFile = GALLERY_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('gallery_add_error', 'File uploading error!'); 
				
				$data['_view'] = 'gallery/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->gallery_model->insertGallery($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('gallery_success', 'Gallery File added successfully!');
					redirect('gallery');
				}
				else
				{
					$this->session->set_flashdata('gallery_add_error', 'Sorry! Something went wrong. Try Again.');
					
					$data['_view'] = 'gallery/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->gallery_model->getGalleryFile($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteGallery(){
		$cnf_id = $this->session->userdata('cnf_id');
		$gallery_id = $this->input->post('gallery_id');
		$gallery_file = $this->gallery_model->getGalleryFile($gallery_id);
		$file = $gallery_file['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->gallery_model->deleteGallery($gallery_id);
			$data['gallery'] = $this->gallery_model->getGallery($cnf_id);
			return $this->load->view('gallery/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($gallery_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM gallery WHERE gallery_id='".$gallery_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['gallery'] = $this->gallery_model->getGalleryFile($cnf_id);
			
			$data['_view'] = 'gallery/list';
			$this->load->view('layouts/main',$data);			
			exit;
		}
	}
	
	public function createFileName($gallery_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$gallery_id.".".$fileinfo['extension'];
	}
	
	function getGalleryFile(){
		$gallery_id = $this->input->post('gallery_id');
		$gallery_file = $this->gallery_model->getGalleryFile($gallery_id);
		$ext = pathinfo($gallery_file['file_path'],PATHINFO_EXTENSION);
		$pdf = ASSET_PATH."build/images/pdf.png";
		$doc = ASSET_PATH."build/images/word.png";
		$xls = ASSET_PATH."build/images/xls.png";
		if ($ext=="pdf") {
			$gallery_file['file_path'] = $pdf;
		} else if ($ext=="doc" or $ext=="docx") {
			$gallery_file['file_path'] = $doc;
		} else if ($ext=="xls" or $ext=="xlsx") {
			$gallery_file['file_path'] = $xls;
		}
		echo json_encode($gallery_file);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select file');
			return false;
		} else {
			return true;
		}
	}
}