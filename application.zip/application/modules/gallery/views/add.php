<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Gallery File'); ?>
		<?=view_list(base_url('gallery')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('gallery_file_add_error')) { ?>
			<?=alert_error($this->session->flashdata('gallery_file_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Gallery File <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<input type="file" name="file" id="file"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions (If Image) : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('file'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <?=cancel(base_url('gallery')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('gallery'); ?>";</script>