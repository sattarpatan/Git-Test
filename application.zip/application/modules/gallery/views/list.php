<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Gallery'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <a class="btn btn-success" href="<?=base_url('gallery/add'); ?>">
					<i class="fa fa-plus"></i> ADD</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
		<?php if ($this->session->flashdata('gallery_success')) { ?>
		<?=alert_success($this->session->flashdata('gallery_success')); ?>
		<?php } ?>
		<div id="alerts"></div>
		<div class="row">
			<?php $this->load->view('gallery/table'); ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete File</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="deleteGallery()">Delete</button>
		<input type="hidden" name="gallery_id" id="gallery_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var get_gallery_file_url = "<?php echo base_url('gallery/getGalleryFile'); ?>";
var delete_url = "<?php echo base_url('gallery/deleteGallery'); ?>";
function modalGallery(gallery_id){
	$.ajax({
		  type: "POST",
		  url:get_gallery_file_url,
		  data:{gallery_id:gallery_id},
		  dataType:"json",
		  success:function(response){
			 var file = response.file_path;
			 $("#gallery_id").val(gallery_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><h4 class='text-danger'>Are you sure you want to delete this file?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function deleteGallery(){
	var alertMsg = $("#alerts");
	alertMsg.css("display","none");
    $.ajax({
		  type: "POST",
		  url:delete_url,
		  data:{gallery_id:$("#gallery_id").val()},
		  success:function(response){
			  if (response==false) {
				  alertMsg.html(errorMsg("Something went wrong."))
				  .slideDown(100);
			  } else {
				  $("#sortable").html(response);
				  alertMsg.html(successMsg("Deleted!"))
				  .slideDown(100);
			  }
			  $('#myModal').modal('hide');
		  }
	});
}
</script>