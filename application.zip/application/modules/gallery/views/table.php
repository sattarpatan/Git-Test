<?php if (empty($gallery)) { ?>
<p>No Files available!</p>
<?php } else { ?>
<table id="datatable" class="table table-striped table-bordered">
	<thead>
		<tr>
		  <th>File</th>
		  <th>URL</th>
		  <th>Action</th>
		</tr>
	</thead>
	<tbody>
<?php
	foreach ($gallery as $gallery_file) {
		$file_type = pathinfo($gallery_file['file_path'],PATHINFO_EXTENSION);
?>
	<tr>
		<td>
			<?php if ($file_type=="gif" || $file_type=="jpg" || $file_type=="jpeg" || $file_type=="png") { ?>			
				<img src="<?php echo $gallery_file['file_path']; ?>" alt="image" class="icon img-thumbnail profile_pic">
			<?php } else if ($file_type=="pdf") { ?>			
				<img src="<?php echo ASSETS_CMS."build/images/pdf.png"; ?>" alt="pdf" class="icon img-thumbnail profile_pic">
			<?php } else if ($file_type=="doc" || $file_type=="docx") { ?>			
				<img src="<?php echo ASSETS_CMS."build/images/word.png"; ?>" alt="doc" class="icon img-thumbnail profile_pic">
			<?php } else if($file_type=="xls" || $file_type=="xlsx"){ ?>				
				<img src="<?php echo ASSETS_CMS."build/images/xls.png"; ?>" alt="xls" class="icon img-thumbnail profile_pic">
			<?php } ?>
		</td>
		<td><?=$gallery_file['file_path']; ?></td>
		<td>			
			<a href="<?php echo $gallery_file['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			&nbsp;
			<a href="<?php echo base_url('gallery/forceDownload/').$gallery_file['gallery_id']; ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			&nbsp;
			<a href="javascript:modalGallery(<?=$gallery_file['gallery_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		</td>
	</tr>
<?php } ?>
</tbody>
</table>
<?php } ?>