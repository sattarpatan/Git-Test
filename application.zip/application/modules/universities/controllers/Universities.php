<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Universities extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')!="Admin") {
			$this->load->layout1('general/no_access');
			exit;
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('universities/Universities_Model');
			$this->load->model('countries/Countries_Model');
		}
    }
	
	public function index()
	{
		$data['universities'] = $this->Universities_Model->getUniversities();
		$this->load->layout1('universities/list',$data);
	}
	
	public function add()
	{
		$data['countries'] = $this->Countries_Model->getCountries();
		
		if ($this->form_validation->run('universities_add') == FALSE)
		{			
			$this->load->layout1('universities/add',$data);
		}
		else
		{
			$insert_status = $this->Universities_Model->insertUniversity();
			if ($insert_status==true) {
				$this->session->set_flashdata('universities_success', 'University added successfully!');
				redirect('cms/universities');
			}
			else
			{
				$this->session->set_flashdata('universities_add_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout1('universities/add',$data);
			}
		}
	}
	
	public function edit($university_id)
	{
		$this->check_access($university_id);
		$data['university'] = $this->Universities_Model->getUniversity($university_id);
		$data['countries'] = $this->Countries_Model->getCountries();
			
		if ($this->form_validation->run('universities_edit') == FALSE)
		{			
			$this->load->layout1('universities/edit',$data);
		}
		else
		{
			$edit_status = $this->Universities_Model->editUniversity();
			if ($edit_status==true) {
				$this->session->set_flashdata('universities_success', 'University updated successfully.');
				redirect('cms/universities');
			}
			else
			{
				$this->session->set_flashdata('universities_edit_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout1('universities/edit',$data);
			}
		}
	}
	
	public function check_access ($university_id) {
		$university = $this->Universities_Model->getUniversity($university_id);
		if (empty($university)) {
			$this->session->set_flashdata('universities_access_error',"Sorry! Record not available!");
			$data['universities'] = $this->Universities_Model->getUniversities();
			$this->load->layout1('universities/list',$data);
			exit;
		} else {
			return true;
		}
	}
	
	public function check_university()
	{
		$university_name = $this->input->post('university_name');
		$university_id = $this->input->post('university_id');
		$query = $this->db->query("SELECT * FROM universities WHERE university_name like '".$university_name."'");
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_university', $university_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
	
	public function check_university_for_edit()
	{
		$university_name = $this->input->post('university_name');
		$university_id = $this->input->post('university_id');
		$query = $this->db->query("SELECT * FROM universities WHERE university_name like '".$university_name."' AND university_id!=".$university_id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_university_for_edit', $university_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
}