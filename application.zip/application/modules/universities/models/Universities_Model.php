<?php

class Universities_Model extends CI_Model {

	public function getUniversities($country_id=NULL) {
		if ($country_id!=NULL) {
			$sql = "SELECT u.*, c.name FROM universities u join countries c on u.country_id=c.id where u.country_id=".$country_id;
		} else {
			$sql = "SELECT u.*, c.name FROM universities u join countries c on u.country_id=c.id";
		}
		$query = $this->db->query($sql);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getUniversity($university_id) {
		$sql = "SELECT u.*, c.name FROM universities u join countries c on u.country_id=c.id WHERE u.university_id=?";
		$query = $this->db->query($sql,array($university_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function insertUniversity() {
		
		$this->db->trans_start();
		
		$data = array(
			'university_name'	=> 	$this->input->post('university_name'),
			'country_id' 		=> 	$this->input->post('country_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('universities',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function editUniversity() {
		
		$this->db->trans_start();
		
		$data = array(
			'university_name' 	=> 	$this->input->post('university_name'),
			'country_id' 		=> 	$this->input->post('country_id'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where('university_id',$this->input->post('university_id'));
		
		$this->db->update('universities',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}