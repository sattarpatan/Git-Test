<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Edit University'); ?>
		<?=view_list(base_url('cms/universities')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('universities_edit_error')) { ?>
			<?=alert_error($this->session->flashdata('universities_edit_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">University Name <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="university_name" class="form-control col-md-7 col-xs-12" value="<?=$university['university_name']; ?>">
			  <?php echo form_error('university_name'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Country <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<select class="form-control" name="country_id">
					<?php foreach ($countries as $country) { ?>
					<option value="<?=$country['country_id']; ?>" <?php if ($university['country_id']==$country['country_id']) echo "selected"; ?>><?=$country['country_name']; ?></option>
					<?php } ?>
				</select>
				<?php echo form_error('country_id'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <input type="hidden" name="university_id" value="<?=$university['university_id']; ?>"/>
			  <?=cancel(base_url('cms/universities')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/universities'); ?>";</script>