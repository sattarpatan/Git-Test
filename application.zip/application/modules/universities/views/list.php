<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Universities'); ?>
		<?=add(base_url('cms/universities/add')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
			<?php if ($this->session->flashdata('universities_success')) { ?>
			<?=alert_success($this->session->flashdata('universities_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('universities_access_error')) { ?>
			<?=alert_error($this->session->flashdata('universities_access_error')); ?>
			<?php } ?>
			<table id="datatable" class="table table-striped table-bordered">
				<thead>
				<tr>
				  <th>University</th>
				  <th>Country</th>
				  <td>Action</td>
				</tr>
			  </thead>
			  <tbody>
			<?php foreach ($universities as $university) { ?>
				<tr>
				  <td><?=$university['university_name']; ?></td>
				  <td><?=$university['country_name']; ?></td>
				  <td>
				  <?php
				  echo edit(base_url('cms/universities/edit'),$university['university_id']);
				  ?>
					</td>
				</tr>
			<?php } ?>
			</table>	
		</div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/universities'); ?>";</script>