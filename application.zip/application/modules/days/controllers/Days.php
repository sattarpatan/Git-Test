<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Days extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('days/Days_Model');
			$this->load->model('conference/conference_model');
		}
    }
	
	public function index()
	{  
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['days'] = $this->Days_Model->getDays($cnf_id);
		//$this->load->layout2('days/list',$data);
		
		$data['_view'] = 'days/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		
		if ($this->form_validation->run('days_add') == FALSE)
		{			
			//$this->load->layout2('days/add',$data);
			
			$data['_view'] = 'days/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
				
			$insert_status = $this->Days_Model->insertDay();
			
			if ($insert_status==true) {
				$this->session->set_flashdata('days_success', 'Added successfully!');
				redirect('days');
			}
			else
			{
				$this->session->set_flashdata('days_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('days/add',$data);
				
				$data['_view'] = 'days/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($day_id)
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($day_id,$cnf_id);
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['day'] = $this->Days_Model->getDay($day_id,$cnf_id);
			
		if ($this->form_validation->run('days_add') == FALSE)
		{			
			//$this->load->layout2('days/edit',$data);
			
			$data['_view'] = 'days/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			$update_status = $this->Days_Model->updateDay();
			
			if ($update_status==true) {
				$this->session->set_flashdata('days_success', 'Updated successfully!');
				redirect('days');
			}
			else
			{
				$this->session->set_flashdata('days_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('days/edit',$data);
				
				$data['_view'] = 'days/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function check_access($day_id,$cnf_id) {
		
		$query = $this->db->query("SELECT * FROM days WHERE day_id='".$day_id."' AND cnf_id=".$cnf_id);
		
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! Record not available!');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['days'] = $this->Days_Model->getDays($cnf_id);
			//$this->load->layout2('days/list',$data);
			
			$data['_view'] = 'days/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	function getDay(){
		$member_id = $this->input->post('member_id');
		$member = $this->Days_Model->getDay($member_id);
		echo json_encode($member);
	}
	
	function removeDay(){
		$member_id = $this->input->post('member_id');
		echo $this->Days_Model->removeDay($member_id);
	}
}