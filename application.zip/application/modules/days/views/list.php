<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Days'); ?>
		<?=add(base_url('days/add')); ?>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php if ($this->session->flashdata('days_success')) { ?>
			<?=alert_success($this->session->flashdata('days_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('member_access_error')) { ?>
			<?=alert_error($this->session->flashdata('member_access_error')); ?>
			<?php } ?>
			<table id="datatable" class="table table-striped table-bordered">
				<thead>
				<tr>
				  <th>Sl</th>
				  <th>Date</th>
				  <th>Title / Label</th>
				  <th>Status</th>
				  <td>Action</td>
				</tr>
			  </thead>
			  <tbody>
			<?php foreach ($days as $day) { ?>
				<tr>
				  <td>Day <?=$day['day_no']; ?></td>
				  <td><?=$day['day_date']; ?></td>
				  <td><?=$day['day_title']; ?></td>
				  <td><?=status($day['day_status']); ?></td>
				  <td><?php echo edit(base_url('days/edit'),$day['day_id']); ?></td>
				</tr>
			<?php } ?>
			</table>
		  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Remove Day from Conference</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="removeFromConf1()">Remove</button>
		<input type="hidden" name="day_id" id="day_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('days'); ?>";
var url = "<?php echo base_url('days/getDay'); ?>";
var base_url = "<?php echo base_url(); ?>";
var remove_url = "<?php echo base_url('days/removeDay'); ?>";
var days_url = "<?php echo base_url('days'); ?>";
function removeFromConf(day_id){
	$.ajax({
		  type: "POST",
		  url:url,
		  data:{day_id:day_id},
		  dataType:"json",
		  success:function(response){
			 var file = base_url + response.file_path;
			 $("#day_id").val(day_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><p><b>"+response.name+"</b></p><h4 class='text-danger'>Are you sure you want to remove this day from your conference?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function removeFromConf1(){
    $.ajax({
		  type: "POST",
		  url:remove_url,
		  data:{day_id:$("#day_id").val()},
		  success:function(response){
			  if (response==false) {
				  alert("Something went wrong.");
			  } else {
				  location.replace(days_url);
			  }
		  }
	});
}
</script>