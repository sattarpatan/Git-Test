<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Day for Scientific Program'); ?>
		<?=view_list(base_url('days')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('day_add_error')) { ?>
			<?=alert_error($this->session->flashdata('day_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Date <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<input type="text" class="form-control has-feedback-left datepicker" id="single_cal1" name="day_date" value="<?=$this->input->post('day_date');?>" aria-describedby="inputSuccess2Status">
				<span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
			  <?php echo form_error('day_date'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Title / Label
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="day_title" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('day_title'); ?>">
			  <?php echo form_error('day_title'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
			  <?=cancel(base_url('days'));?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('days'); ?>";</script>