<?php

class Days_Model extends CI_Model {

	public function getDays($cnf_id) {
		$sql = "SELECT *, IF (day_title='',CONCAT('Day ',day_no),day_title) as day_name FROM days WHERE cnf_id=?";
		$query = $this->db->query($sql,$cnf_id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getDay($day_id,$cnf_id) {
		$sql = "SELECT *, IF (day_title='',CONCAT('Day ',day_no),day_title) as day_name FROM days WHERE day_id=? AND cnf_id=?";
		$query = $this->db->query($sql,array($day_id,$cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}	
	
	public function removeDay($member_id){
		
		$this->db->trans_start();
		
		$sql = "delete from days_confs where member_id=?";
		$this->db->query($sql,array($member_id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function insertDay() {
		
		$this->db->trans_start();
		
		$sql = "SELECT IFNULL(MAX(day_no)+1,1) as max_id FROM days WHERE cnf_id=?";
		$query = $this->db->query($sql,$this->session->userdata('cnf_id'));
		
		$data = array(
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'day_no'			=>	$query->row_array()['max_id'],
			'day_date'			=>	$this->input->post('day_date'),
			'day_title'			=>	$this->input->post('day_title'),
			'day_status'		=>	1,
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('days',$data);
		//echo $this->db->last_query();
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateDay() {
		
		$this->db->trans_start();
		
		$data = array(
			'day_title' 		=> 	$this->input->post('day_title'),
			'day_date'			=>	$this->input->post('day_date'),
			'day_status'		=>	$this->input->post('day_status'),
			'updated_by'		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where(array('day_id'=>$this->input->post('day_id')));
		
		$this->db->update('days',$data);
		/* echo $this->db->last_query();
		exit; */
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}