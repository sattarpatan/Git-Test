<?php

class Renowned_Speakers_Model extends CI_Model {

	public function getRenownedSpeakers($cnf_id) {
		$sql = "SELECT m.*, oc.order_no, f.file_path FROM renowned_speakers oc 
		LEFT JOIN members m on m.member_id=oc.member_id
		LEFT JOIN filemaster f on f.file_id = m.file_id where m.cnf_id=? order by oc.order_no asc";
		$query = $this->db->query($sql,$cnf_id);		
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getMembersForRenownedSpeakersSelection($cnf_id) {
		$sql = "SELECT m.*, f.file_path, oc.order_no FROM members m 
		JOIN filemaster f ON m.file_id=f.file_id 
		LEFT JOIN renowned_speakers oc ON oc.cnf_id=? AND oc.member_id = m.member_id
		WHERE m.cnf_id=? ORDER BY oc.order_no ASC";
		$query = $this->db->query($sql,array($cnf_id,$cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function selectRenownedSpeakers() {		
		$members = $this->input->post('members');		
		$cnf_id = $this->session->userdata('cnf_id');		
		$i=1;
		
		$this->db->trans_start();
		
		$sql = "delete from renowned_speakers where cnf_id=?";		
		$this->db->query($sql,array($cnf_id));		
		foreach ($members as $member=>$value) {
			$data = array(
				'member_id' 		=> 	$member,
				'order_no'			=>	$i++,
				'cnf_id'			=>	$cnf_id,
				'created_by'		=> 	$this->session->userdata('user_id'),
				'created_datetime'	=>	date('Y-m-d H:i:s')
			);
			$this->db->insert('renowned_speakers',$data);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}