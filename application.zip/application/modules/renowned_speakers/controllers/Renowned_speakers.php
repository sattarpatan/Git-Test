<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Renowned_Speakers extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('memberslogin');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('membersconferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('members/Members_Model');
			$this->load->model('conference/conference_model');
			$this->load->model('renowned_speakers/Renowned_Speakers_Model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['renowned_speakers'] = $this->Renowned_Speakers_Model->getRenownedSpeakers($cnf_id);
		//$this->load->layout2('renowned_speakers/list',$data);
		
		$data['_view'] = 'renowned_speakers/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function select()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['members'] = $this->Renowned_Speakers_Model->getMembersForRenownedSpeakersSelection($cnf_id);
		
		if ($this->input->post('Submit') != "Submit")
		{			
			//$this->load->layout2('renowned_speakers/select',$data);
			
			$data['_view'] = 'renowned_speakers/select';
			$this->load->view('layouts/main',$data);
		}
		else
		{	
			$status = $this->Renowned_Speakers_Model->selectRenownedSpeakers();
			
			if ($status==true) {
				$this->session->set_flashdata('renowned_speakers_success', 'Selected successfully!');
				redirect('renowned_speakers');
			}
			else
			{
				$this->session->set_flashdata('renowned_speakers_select_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout2('renowned_speakers/select',$data);
				
				$data['_view'] = 'renowned_speakers/select';
				$this->load->view('layouts/main',$data);
			}
		}
	}
}