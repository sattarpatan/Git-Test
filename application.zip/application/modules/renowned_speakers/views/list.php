<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Renowned Speakers'); ?>
		<?=select(base_url('renowned_speakers/select')); ?>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php if ($this->session->flashdata('renowned_speakers_success')) { ?>
			<?=alert_success($this->session->flashdata('renowned_speakers_success')); ?>
			<?php } ?>
			<table class="table table-striped table-bordered">
				<thead>
				<tr>
				  <th>Order No</th>
				  <th>Member</th>
				  <th>Name</th>
				  <th>Email</th>
				  <th>Country</th>
				  <th>University</th>
				  <th>Company</th>
				</tr>
			  </thead>
			  <tbody>
			<?php foreach ($renowned_speakers as $member) { ?>
				<tr>
				  <td class="text-center"><?=$member['order_no'];?>
				  </td>
				  <td>
					  <img src="<?php echo $member['file_path']; ?>" alt="<?=$member['name']; ?>" class="datatable_image">
                  </td>
				  <td><?=$member['name']; ?></td>
				  <td><?=$member['email']; ?></td>
				  <td><?=$member['country']; ?></td>
				  <td><?=$member['university']; ?></td>
				  <td><?=$member['company']; ?></td>
				</tr>
			<?php } ?>
			</table>
		  </div>
	  </div>
  </div>
</div>