<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Renowned Speakers'); ?>
		<?=view_list(base_url('renowned_speakers')); ?>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php if ($this->session->flashdata('renowned_speakers_select_error')) { ?>
			<?=alert_error($this->session->flashdata('renowned_speakers_select_error')); ?>
			<?php } ?>
			<form name="form1" method="post">
				<table class="table table-striped table-bordered">
					<thead>
					<tr>
					  <th>Order</th>
					  <th>Select</th>
					  <th>Member</th>
					  <th>Name</th>
					  <th>Email</th>
					  <th>Country</th>
					  <th>University</th>
					  <th>Company</th>
					</tr>
				  </thead>
				  <tbody id="sortable">
				<?php foreach ($members as $member) { ?>
					<tr>
					  <td>
					  <div class="col-sm-1">
							<span class="glyphicon glyphicon-sort text-success" id="sort_icon"></span>
						</div>
					 </td>
					 <td>
						 <div class="checkbox">
							<label class="">
								<div class="icheckbox_flat-green">
									<input type="checkbox" class="flat" name="members[<?=$member['member_id']; ?>]"
									<?php if ($member['order_no']!="") echo "checked"; ?>>
									<ins class="iCheck-helper"></ins>
								</div>
							</label>
						  </div>
					 </td>
					  <td>
						  <img src="<?php echo $member['file_path']; ?>" alt="<?=$member['name']; ?>" class="datatable_image">
					  </td>
					  <td><?=$member['name']; ?></td>
					  <td><?=$member['email']; ?></td>
					  <td><?=$member['country']; ?></td>
					  <td><?=$member['university']; ?></td>
					  <td><?=$member['company']; ?></td>
					</tr>
				<?php } ?>
				</table>
				<div class="form-group">
					<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
					  <input type="submit" class="btn btn-success" value="Submit" name="Submit"/>
					</div>
				</div>
			</form>
		  </div>
	  </div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('renowned_speakers'); ?>";
window.onload = function() { $("#sortable").sortable(); }
</script>