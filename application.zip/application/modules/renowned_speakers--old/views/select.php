<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<h2 class="text-success">Speakers</h2>		
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
				  <a class="btn btn-success" href="<?php echo base_url('renowned_speakers/select'); ?>"><i class="fa fa-hand-pointer-o"></i> SELECT</a>
				</div>
			</div>
		</div>		
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
			<?php /* if ($this->session->flashdata('renowned_speakers_select_error')) { ?>
			<?=alert_error($this->session->flashdata('renowned_speakers_select_error')); ?>
			<?php } */ ?>
			<form name="form1" method="post">
				<table id="datatable" class="table table-striped table-bordered">
					<thead>
					<tr>
					  <th>Order</th>
					  <th>Select</th>
					  <th>Photo</th>
					  <th>Name</th>
					  <th>Country</th>
					  <th>University / Company</th>
					  <th>Designation</th>
					  <th>Department</th>
					</tr>
				  </thead>
				  <tbody id="sortable">
					<?php foreach ($members as $member) { ?>
					<tr>
					 <td>
					  <div class="col-sm-1">
							<span class="glyphicon glyphicon-sort text-success" id="sort_icon"></span>
						</div>
					 </td>
					 <td>
						 <div class="checkbox">
							<label class="">
								<div class="icheckbox_flat-green">
									<input type="checkbox" class="flat" name="members[<?=$member['id']; ?>]"
									<?php if ($member['order_no']!="") echo "checked"; ?>>
									<ins class="iCheck-helper"></ins>
								</div>
							</label>
						  </div>
					 </td>
					  <td>
						  <img src="<?php echo base_url('uploads/members/'.$member['photo']); ?>" alt="<?=$member['name']; ?>" class="img-thumbnail" width="50" height="50">
					  </td>
					  <td><?=$member['name']; ?></td>
					  <td><?=$member['country']; ?></td>
					  <td><?=$member['university_name']; ?></td>
					  <td><?=$member['designation']; ?></td>
					  <td><?=$member['department']; ?></td>
					</tr>
					<?php } ?>
				  </tbody>
				</table>
				<div class="form-group">
					<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
					  <input type="submit" class="btn btn-success" value="Submit" name="Submit"/>
					</div>
				</div>
			</form>
		  </div>
	  </div>
  </div>
</div>
<script>
var parent_url = "<?php echo base_url('renowned_speakers'); ?>";
window.onload = function() { $("#sortable").sortable(); }
</script>