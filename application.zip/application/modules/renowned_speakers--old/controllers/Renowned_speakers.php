<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Renowned_speakers extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('Members_Model');
			$this->load->model('Conferences_Model');
			$this->load->model('Renowned_Speakers_Model');
		} */
		
		$this->load->model('members/members_model');
		$this->load->model('conference/conference_model', 'conference');
		$this->load->model('renowned_speakers/renowned_speakers_model', 'speakers');
		
    }
	
	public function index()
	{
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference->get_all_conference();
		$data['renowned_speakers'] = $this->speakers->getRenownedSpeakers($cnf_id);
		
		$data['_view'] = 'renowned_speakers/list';
        $this->load->view('layouts/main',$data);
		
		//$this->load->layout2('renowned_speakers/list',$data);
	}
	
	public function select()
	{	
		$cnf_id = 1;//$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference->get_all_conference();
		$data['members'] = $this->speakers->getMembersForRenownedSpeakersSelection($cnf_id);
		
		if ($this->input->post('Submit') != "Submit")
		{			
			//$this->load->layout2('renowned_speakers/select',$data);
			$data['_view'] = 'renowned_speakers/select';
			$this->load->view('layouts/main',$data);
		}
		else
		{	
			$status = $this->speakers->selectRenownedSpeakers();
			
			if ($status==true) {
				$this->session->set_flashdata('renowned_speakers_success', 'Selected successfully!');
				redirect('renowned_speakers');
			}
			else
			{
				$this->session->set_flashdata('renowned_speakers_select_error', 'Sorry! Something went wrong. Try Again.');
				$this->load->layout2('renowned_speakers/select',$data);
				
				$data['_view'] = 'renowned_speakers/select';
				$this->load->view('layouts/main',$data);
			}
		}
	}
}