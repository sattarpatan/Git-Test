<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Countries extends MY_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('Countries_model', 'country');
		$this->load->model('cities_model', 'cities_model');
    }
    
    public function index(){

		$data['countries'] = $this->country->getCountryRows();
		
		$data['_view'] = 'index';
        $this->load->view('layouts/main',$data);
        
    }
    
    public function getStates(){
        $states = array();
        $country_id = $this->input->post('country_id');
        if($country_id){
            $con['conditions'] = array('country_id'=>$country_id);
            $states = $this->country->getStateRows($con);
        }
        echo json_encode($states);
    }
    
    public function getCities(){
        $cities = array();
        $state_id = $this->input->post('state_id');
        if($state_id){
            $con['conditions'] = array('state_id'=>$state_id);
            $cities = $this->country->getCityRows($con);
        }
        echo json_encode($cities);
    }

}

/*****/