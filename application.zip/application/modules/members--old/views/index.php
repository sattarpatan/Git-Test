		  <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Default Example <small>Users</small></h2>
                    <div class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="<?php echo site_url('members/add'); ?>"><i class="fa fa-plus"></i> Add</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
 <table id="datatable" class="table table-striped table-bordered">
    <thead>
	<tr>
		<th>ID</th>
		<th>Photo</th>
		<th>Name</th>
		<th>Country</th>
		<th>University / Company</th>
		<th>Designation</th>
		<th>Department</th>
		<th>Biography</th>
		<th>Research & Interest</th>
		<th>Status</th>
		<th>Created Date</th>
		<th>Actions</th>
    </tr>
	</thead>
	<tbody>
	<?php foreach($members as $r){ ?>
    <tr>
		<td><?php echo $r['id']; ?></td>
		<td>
			<img src="<?php echo base_url('uploads/members/'.$r['photo']); ?>" alt="<?php echo $r['name']; ?>" class="img-thumbnail" width="50" height="50">
		</td>
		<td><?php echo $r['name']; ?></td>
		<td><?php echo $r['country']; ?></td>
		<td><?php echo $r['university_name']; ?></td>
		<td><?php echo $r['designation']; ?></td>
		<td><?php echo $r['department']; ?></td>
		<td><?php echo $r['biography']; ?></td>
		<td><?php echo $r['research']; ?></td>
		<td><?php echo $r['status']; ?></td>
		<td><?php echo $r['created_date']; ?></td>
		<td>
            <a href="<?php echo site_url('members/edit/'.$r['id']); ?>" class="btn btn-info btn-xs">Edit</a> 
            <a href="<?php echo site_url('members/remove/'.$r['id']); ?>" class="btn btn-danger btn-xs">Delete</a>
        </td>
    </tr>
	<?php } ?>
	</tbody>
</table>                   
					
					
                  </div>
                </div>
              </div>
            </div>
          </div>



<div class="pull-right">
    <?php //echo $this->pagination->create_links(); ?>    
</div>
