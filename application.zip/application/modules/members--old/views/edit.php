<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		
		<?php echo form_open_multipart('members/edit/'.$member['id'],array("class"=>"form-horizontal")); ?>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name"><span class="text-danger">*</span>Image
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<img src="<?php echo base_url('uploads/members/'.$member['photo']); ?>" class="img-responsive img-circle"/><br/><br/>
				<input type="file" name="photo" id="photo"/>
				<br/>
				<!--<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>-->
				</div>
				<span class="text-danger"><?php echo form_error('photo'); ?></span>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"><span class="text-danger">*</span>Name</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="name" class="form-control col-md-7 col-xs-12" value="<?php echo $member['name']; ?>">
			  <span class="text-danger"><?php echo form_error('name'); ?></span>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> <span class="text-danger">*</span>Country
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<input type="text" name="country" class="form-control col-md-7 col-xs-12" value="<?php echo $member['country']; ?>">
				<span class="text-danger"><?php echo form_error('country'); ?></span>
			</div>
		  </div>
		  
		  <div class="form-group"><hr/></div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> <span class="text-danger">*</span>University / Company
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="university_name" class="form-control col-md-7 col-xs-12" value="<?php echo $member['university_name']; ?>">
			  <span class="text-danger"><?php echo form_error('university_name'); ?></span>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> <span class="text-danger">*</span>Designation
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="designation" class="form-control col-md-7 col-xs-12" value="<?php echo $member['designation']; ?>">
			  <span class="text-danger"><?php echo form_error('designation'); ?></span>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Department
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="department" class="form-control col-md-7 col-xs-12" value="<?php echo $member['department'];?>">
			  <span class="text-danger"><?php echo form_error('department'); ?></span>
			</div>
		  </div>
		  
		  <div class="form-group"><hr/></div>
		  
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Biography
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<textarea rows="5" cols="" class="form-control " id="biography" name="biography"><?php echo $member['biography']; ?></textarea>
				<span class="text-danger"><?php echo form_error('biography'); ?></span>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name"> Research & Interest
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<textarea rows="5" cols="" class="form-control " id="research" name="research"><?php echo $member['research']; ?></textarea>
			</div>
		  </div>
		  
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>


<?php /*echo form_open('members/edit/'.$member['id'],array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="phone_no" class="col-md-4 control-label"><span class="text-danger">*</span>Phone No</label>
		<div class="col-md-8">
			<input type="text" name="phone_no" value="<?php echo ($this->input->post('phone_no') ? $this->input->post('phone_no') : $member['phone_no']); ?>" class="form-control" id="phone_no" />
			<span class="text-danger"><?php echo form_error('phone_no');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="fax_no" class="col-md-4 control-label">Fax No</label>
		<div class="col-md-8">
			<input type="text" name="fax_no" value="<?php echo ($this->input->post('fax_no') ? $this->input->post('fax_no') : $member['fax_no']); ?>" class="form-control" id="fax_no" />
		</div>
	</div>
	<div class="form-group">
		<label for="status" class="col-md-4 control-label">Status</label>
		<div class="col-md-8">
			<input type="text" name="status" value="<?php echo ($this->input->post('status') ? $this->input->post('status') : $member['status']); ?>" class="form-control" id="status" />
		</div>
	</div>
	<div class="form-group">
		<label for="created_date" class="col-md-4 control-label">Created Date</label>
		<div class="col-md-8">
			<input type="text" name="created_date" value="<?php echo ($this->input->post('created_date') ? $this->input->post('created_date') : $member['created_date']); ?>" class="form-control" id="created_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="updated_date" class="col-md-4 control-label">Updated Date</label>
		<div class="col-md-8">
			<input type="text" name="updated_date" value="<?php echo ($this->input->post('updated_date') ? $this->input->post('updated_date') : $member['updated_date']); ?>" class="form-control" id="updated_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="conf_id" class="col-md-4 control-label">Conf Id</label>
		<div class="col-md-8">
			<input type="text" name="conf_id" value="<?php echo ($this->input->post('conf_id') ? $this->input->post('conf_id') : $member['conf_id']); ?>" class="form-control" id="conf_id" />
		</div>
	</div>
	<div class="form-group">
		<label for="name" class="col-md-4 control-label"><span class="text-danger">*</span>Name</label>
		<div class="col-md-8">
			<input type="text" name="name" value="<?php echo ($this->input->post('name') ? $this->input->post('name') : $member['name']); ?>" class="form-control" id="name" />
			<span class="text-danger"><?php echo form_error('name');?></span>
		</div>
	</div>
	<div class="form-group">
		<label for="photo" class="col-md-4 control-label">Photo</label>
		<div class="col-md-8">
			<input type="text" name="photo" value="<?php echo ($this->input->post('photo') ? $this->input->post('photo') : $member['photo']); ?>" class="form-control" id="photo" />
		</div>
	</div>
	<div class="form-group">
		<label for="img_url" class="col-md-4 control-label">Img Url</label>
		<div class="col-md-8">
			<input type="text" name="img_url" value="<?php echo ($this->input->post('img_url') ? $this->input->post('img_url') : $member['img_url']); ?>" class="form-control" id="img_url" />
		</div>
	</div>
	<div class="form-group">
		<label for="country" class="col-md-4 control-label">Country</label>
		<div class="col-md-8">
			<input type="text" name="country" value="<?php echo ($this->input->post('country') ? $this->input->post('country') : $member['country']); ?>" class="form-control" id="country" />
		</div>
	</div>
	<div class="form-group">
		<label for="biography" class="col-md-4 control-label">Biography</label>
		<div class="col-md-8">
			<textarea name="biography" class="form-control" id="biography"><?php echo ($this->input->post('biography') ? $this->input->post('biography') : $member['biography']); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="affiliation" class="col-md-4 control-label">Affiliation</label>
		<div class="col-md-8">
			<textarea name="affiliation" class="form-control" id="affiliation"><?php echo ($this->input->post('affiliation') ? $this->input->post('affiliation') : $member['affiliation']); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="designation" class="col-md-4 control-label"><span class="text-danger">*</span>Designation</label>
		<div class="col-md-8">
			<textarea name="designation" class="form-control" id="designation"><?php echo ($this->input->post('designation') ? $this->input->post('designation') : $member['designation']); ?></textarea>
			<span class="text-danger"><?php echo form_error('designation');?></span>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>
	
<?php echo form_close();*/ ?>