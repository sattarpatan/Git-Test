<?php

class File_upload_settings_model extends CI_Model {

	public function getFileUploadSettings() {
		
		$sql = "SELECT * FROM file_upload_settings";
		$query = $this->db->query($sql);
			
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getFileUploadSettingById($id) {
		$sql = "SELECT * FROM file_upload_settings WHERE id=?";
		$query = $this->db->query($sql,$id);
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function getFileUploadSetting($file_name) {
		$sql = "SELECT * FROM file_upload_settings WHERE file_name=?";
		$query = $this->db->query($sql,array($file_name));
		
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function insertFileUploadSetting() {
		
		$this->db->trans_start();
		
		foreach ($this->input->post('file_types') as $key => $value) {
			$file_types[] = $key;
		}
		
		$file_types = implode("|",$file_types);
		
		$data = array(
			'file_name' 		=> 	clean_title($this->input->post('file_name')),
			'width' 			=> 	$this->input->post('width'),
			'height' 			=> 	$this->input->post('height'),
			'allowed_size' 		=> 	$this->input->post('allowed_size'),
			'file_types'		=>	$file_types,
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('file_upload_settings',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function editFileUploadSetting() {
		
		$this->db->trans_start();
		
		foreach ($this->input->post('file_types') as $key => $value) {
			$file_types[] = $key;
		}
		
		$file_types = implode("|",$file_types);
		
		$data = array(
			'file_name' 		=> 	$this->input->post('file_name'),
			'width' 			=> 	$this->input->post('width'),
			'height' 			=> 	$this->input->post('height'),
			'file_types'		=>	$file_types,
			'allowed_size' 		=> 	$this->input->post('allowed_size'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->where('id',$this->input->post('id'));
		
		$this->db->update('file_upload_settings',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}