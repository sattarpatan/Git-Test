<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<h2 class="text-success">File Upload Settings</h2>		
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
				  <a class="btn btn-success" href="<?php echo base_url('file_upload_settings/add'); ?>"><i class="fa fa-hand-pointer-o"></i> ADD</a>
				</div>
			</div>
		</div>		
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
			<?php /* if ($this->session->flashdata('file_upload_settings_success')) { ?>
			<?=alert_success($this->session->flashdata('file_upload_settings_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('file_upload_settings_access_error')) { ?>
			<?=alert_error($this->session->flashdata('file_upload_settings_access_error')); ?>
			<?php } */ ?>
			<div id="table">
			<?php $this->load->view('file_upload_settings/table',$file_upload_settings); ?>
			</div>
		</div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/file_upload_settings'); ?>";</script>