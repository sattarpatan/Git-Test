<table id="datatable" class="table table-striped table-bordered">
	<thead>
	<tr>
	  <th>Id</th>
	  <th>File Name</th>
	  <th>Width (Px)</th>
	  <th>Height (Px)</th>
	  <th>Allowed Size (MB)</th>
	  <th>File Types</th>
	  <td>Action</td>
	</tr>
  </thead>
  <tbody>
<?php foreach ($file_upload_settings as $file) { ?>
	<tr>
	  <td><?=$file['id']; ?></td>
	  <td><?=$file['file_name']; ?></td>
	  <td><?=$file['width']; ?></td>
	  <td><?=$file['height']; ?></td>
	  <td><?=$file['allowed_size']; ?></td>
	  <td><?=str_replace("|",", ",$file['file_types']); ?></td>
	  <td><a href="<?php echo base_url('file_upload_settings/edit').'/'.$file['id'];?>">Edit</a>
		</td>
	</tr>
<?php } ?>
</table>