<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<h2 class="text-success">File Upload Settings</h2>		
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
				  <a class="btn btn-success" href="<?php echo base_url('file_upload_settings'); ?>"><i class="fa fa-bars"></i> List</a>
				</div>
			</div>
		</div>		
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php /* if ($this->session->flashdata('amenity_add_error')) { ?>
			<?=alert_error($this->session->flashdata('amenity_add_error')); ?>
		<?php } */ ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">File Name <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="file_name" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('file_name'); ?>">
			  <?php echo form_error('file_name'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Width 
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="width" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('width'); ?>">
			  <?php echo form_error('width'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Height 
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="height" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('height'); ?>">
			  <?php echo form_error('height'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Max Allowed Size <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			  <input type="text" name="allowed_size" class="form-control col-md-7 col-xs-12" value="<?=$this->input->post('allowed_size'); ?>">
			  <?php echo form_error('allowed_size'); ?>
			</div>
		  </div>
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">File Types <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
			
			<div class="row">
			  
			  <div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[jpg]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.jpg
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[jpeg]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.jpeg
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[png]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.png
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[gif]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.gif
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[pdf]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.pdf
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[doc]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.doc
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[docx]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.docx
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[xls]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.xls
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[xlsx]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.xlsx
					</label>
				  </div>
				</div>
				
				<div class="col-md-6">
				<div class="checkbox">
					<label class="">
						<div class="icheckbox_flat-green">
							<input type="checkbox" class="flat" name="file_types[pdf]">
							<ins class="iCheck-helper"></ins>
						</div>&nbsp;&nbsp;&nbsp;.pdf
					</label>
				  </div>
				</div>
				
				</div>
					
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-5 col-sm-5 col-xs-12 col-md-offset-7">
			  <a href="<?php echo base_url('file_upload_settings'); ?>" class="btn btn-primary">Cancel</a>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('cms/file_upload_settings'); ?>";</script>