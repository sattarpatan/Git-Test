<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class File_upload_settings extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')!="Admin") {
			$this->load->layout1('general/no_access');
			exit;
		} else {
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('file_upload_settings_model');
		} */
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->load->model('file_upload_settings_model');
		
		
    }
	
	public function index()
	{
		$data['file_upload_settings'] = $this->file_upload_settings_model->getFileUploadSettings();
		
		$data['_view'] = 'file_upload_settings/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function get_list()
	{
		$data['file_upload_settings'] = $this->file_upload_settings_model->getFileUploadSettings();
		return $this->load->view('file_upload_settings/table',$data);
	}
	
	public function add()
	{
		
		if ($this->form_validation->run('file_upload_settings_add') == FALSE)
		{			
			//$this->load->layout1('file_upload_settings/add');
			$data['_view'] = 'file_upload_settings/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$insert_status = $this->file_upload_settings_model->insertFileUploadSetting();
			if ($insert_status==true) {
				$this->session->set_flashdata('file_upload_settings_success', 'Setting added successfully!');
				redirect('file_upload_settings');
			}
			else
			{
				$this->session->set_flashdata('file_upload_settings_add_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout1('file_upload_settings/add');
				$data['_view'] = 'file_upload_settings/add';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function edit($id)
	{
		$this->check_access($id);
		$data['setting'] = $this->file_upload_settings_model->getFileUploadSettingById($id);		
		$data['file_types'] = explode("|",$data['setting']['file_types']);
			
		if ($this->form_validation->run('file_upload_settings_edit') == FALSE)
		{			
			//$this->load->layout1('file_upload_settings/edit',$data);
			$data['_view'] = 'file_upload_settings/edit';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			$edit_status = $this->file_upload_settings_model->editFileUploadSetting();
			
			if ($edit_status==true) {
				$this->session->set_flashdata('file_upload_settings_success', 'File Upload updated successfully.');
				redirect('cms/file_upload_settings');
			}
			else
			{
				$this->session->set_flashdata('file_upload_settings_edit_error', 'Sorry! Something went wrong. Try Again.');
				//$this->load->layout1('file_upload_settings/edit',$data);
				$data['_view'] = 'file_upload_settings/edit';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function check_access ($id) {
		$settings = $this->file_upload_settings_model->getFileUploadSettingById($id);
		if (empty($settings)) {
			$this->session->set_flashdata('file_upload_settings_access_error',"Sorry! Record not available!");
			$data['file_upload_settings'] = $this->file_upload_settings_model->getFileUploadSettings();
			$this->load->layout1('file_upload_settings/list',$data);
			exit;
		} else {
			return true;
		}
	}
	
	public function check_file_name()
	{
		$file_name = $this->input->post('file_name');
		$company_id = $this->input->post('company_id');
		$query = $this->db->query("SELECT * FROM file_upload_settings WHERE file_name like '".$file_name."'");
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_file_name', $file_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
	
	public function check_file_name_for_edit()
	{
		$file_name = $this->input->post('file_name');
		$id = $this->input->post('id');
		$query = $this->db->query("SELECT * FROM file_upload_settings WHERE file_name like '".$file_name."' AND id!=".$id);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('check_file_name_for_edit', $file_name.' already existed.');
			return false;
		} else {
			return true;
		}
	}
}