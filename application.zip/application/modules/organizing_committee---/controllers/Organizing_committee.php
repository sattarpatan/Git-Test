<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Organizing_committee extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('Members_Model');
			$this->load->model('Conferences_Model');
			$this->load->model('Organizing_Committee_Model');
		} */
		
		
		$this->load->model('members/Members_model');
		$this->load->model('conference/Conference_model');
		$this->load->model('organizing_committee/Organizing_committee_model', 'ocm');
		
    }
	
	public function index()
	{
		$cnf_id = 1;
		$data['conference'] = $this->Conference_model->get_all_conference();
		$data['members'] = $this->Members_model->get_all_members();
		$data['organizing_committee'] = $this->ocm->getCommitteeMembers($cnf_id);
		
		$data['_view'] = 'organizing_committee/list';
        $this->load->view('layouts/main',$data);
	}
	
	public function select()
	{	
		$cnf_id = 1;
		$data['conference'] = $this->Conference_model->get_all_conference();
		$data['members'] = $this->ocm->getMembersForCommitteeSelection($cnf_id);
		
		if ($this->input->post('Submit') != "Submit")
		{			
			$data['_view'] = 'organizing_committee/select';
			$this->load->view('layouts/main',$data);
		}
		else
		{	
			$status = $this->ocm->selectCommittee();
			
			if ($status==true) {
				$this->session->set_flashdata('committee_members_success', 'Selected successfully!');
				redirect('organizing_committee');
			}
			else
			{
				$this->session->set_flashdata('committee_members_select_error', 'Sorry! Something went wrong. Try Again.');
				
				$data['_view'] = 'organizing_committee/select';
				$this->load->view('layouts/main',$data);
			}
		}
	}
	
	public function check_edit_member_access ($member_id) {
		$member = $this->Members_Model->getMember($member_id);
		$cnf_id = $this->session->userdata('cnf_id');
		if ($member['cnf_id']==$cnf_id) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public function view($member_id)
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->Conferences_Model->getConference($cnf_id);
		$data['countries'] = $this->Countries_Model->getCountries();
		$data['member'] = $this->Members_Model->getMember($member_id);
		$data['researchs'] = unserialize($data['member']['research']);
		$data['member_confs'] = $this->Members_Model->getMemberConfs($member_id);
		$this->load->layout2('members/view',$data);
	}
	
	function removeMember(){
		$member_id = $this->input->post('member_id');
		echo $this->Members_Model->removeMember($member_id);
	}
	
	function getMember(){
		$member_id = $this->input->post('member_id');
		$member = $this->Members_Model->getMember($member_id);
		echo json_encode($member);
	}
	
	public function file_check() {
		if (empty($_FILES['member']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select member');
			return false;
		} else {
			return true;
		}
	}
	
	public function email_check() {
		$email =  $this->input->post('email');
		$sql = "SELECT * FROM members WHERE email=?";
		$query = $this->db->query($sql,$email);
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('email_check', 'This email is not available!');
			return false;
		} else {
			return true;
		}
	}
	
	public function email_check_for_edit() {
		$email =  $this->input->post('email');
		$member_id = $this->input->post('member_id');
		$sql = "SELECT * FROM members WHERE email=? AND member_id!=?";
		$query = $this->db->query($sql,array($email,$member_id));
		if ($query->num_rows()>0) {
			$this->form_validation->set_message('email_check_for_edit', 'Member already existed with this email id!');
			return false;
		} else {
			return true;
		}
	}
}

/****************/