<?php

class Organizing_committee_model extends CI_Model {

	public function getCommitteeMembers($cnf_id) {
		$sql = "SELECT m.*, oc.order_no FROM organizing_committee oc 
		LEFT JOIN renownedspeakers m on m.id=oc.member_id
		where m.conf_id=? order by oc.order_no asc";
		$query = $this->db->query($sql,$cnf_id);	

//echo $this->db->last_query();
		
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getMembersForCommitteeSelection($cnf_id) {
		$sql = "SELECT m.*, oc.order_no FROM renownedspeakers m 
		LEFT JOIN organizing_committee oc ON oc.cnf_id=? AND oc.member_id = m.id
		WHERE m.conf_id=? ORDER BY oc.order_no ASC";
		$query = $this->db->query($sql,array($cnf_id,$cnf_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		} 
	}
	
	public function selectCommittee() {
		
		$members = $this->input->post('members');		
		$cnf_id = 1; //$this->session->userdata('cnf_id');		
		$i=1;
		
		$this->db->trans_start();
		
		$sql = "delete from organizing_committee where cnf_id=?";		
		$this->db->query($sql,array($cnf_id));		
		foreach ($members as $member=>$value) {
			$data = array(
				'member_id' 		=> 	$member,
				'order_no'			=>	$i++,
				'cnf_id'			=>	$cnf_id,
				// 'created_by'		=> 	$this->session->userdata('user_id'),
				'created_datetime'	=>	date('Y-m-d H:i:s')
			);
			$this->db->insert('organizing_committee',$data);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
}