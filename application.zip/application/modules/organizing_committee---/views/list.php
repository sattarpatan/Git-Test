<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<h2 class="text-success">Organizing Committee</h2>		
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
				  <a class="btn btn-success" href="<?php echo base_url('organizing_committee/select'); ?>"><i class="fa fa-hand-pointer-o"></i> SELECT</a>
				</div>
			</div>
		</div>		
		<div class="clearfix"></div>
	  </div>
	  
		<div class="x_content">
			<?php /* if ($this->session->flashdata('committee_members_success')) { ?>
			<?=alert_success($this->session->flashdata('committee_members_success')); ?>
			<?php } ?>
			<?php if ($this->session->flashdata('committee_members_select_error')) { ?>
			<?=alert_error($this->session->flashdata('committee_members_select_error')); ?>
			<?php } */ ?>
			<table id="datatable" class="table table-striped table-bordered">
			  <thead>
					<tr>
					  <th>Order</th>
					  <th>Photo</th>
					  <th>Name</th>
					  <th>Country</th>
					  <th>University / Company</th>
					  <th>Designation</th>
					  <th>Department</th>
					</tr>
			  </thead>
			  <tbody>
			<?php foreach ($organizing_committee as $member) { ?>
				<tr>
				  <td class="text-center"><?=$member['order_no'];?></td>
				  <td>
					  <img src="<?php echo base_url('uploads/members/'.$member['photo']); ?>" alt="<?=$member['name']; ?>" class="img-thumbnail" width="50" height="50">
                  </td>
				  <td><?=$member['name']; ?></td>
				  <td><?=$member['country']; ?></td>
				  <td><?=$member['university_name']; ?></td>
				  <td><?=$member['designation']; ?></td>
				  <td><?=$member['department']; ?></td>
				</tr>
			<?php } ?>
			  </tbody>
			</table>
		  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Remove Member from Conference</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="removeFromConf1()">Remove</button>
		<input type="hidden" name="member_id" id="member_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var url = "<?php echo base_url('members/getMember'); ?>";
var base_url = "<?php echo base_url(); ?>";
var remove_url = "<?php echo base_url('members/removeMember'); ?>";
var members_url = "<?php echo base_url('members'); ?>";
function removeFromConf(member_id){
	$.ajax({
		  type: "POST",
		  url:url,
		  data:{member_id:member_id},
		  dataType:"json",
		  success:function(response){
			 var file = base_url + response.file_path;
			 $("#member_id").val(member_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><p><b>"+response.name+"</b></p><h4 class='text-danger'>Are you sure you want to remove this member from this conference?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function removeFromConf1(){
    $.ajax({
		  type: "POST",
		  url:remove_url,
		  data:{member_id:$("#member_id").val()},
		  success:function(response){
			  if (response==false) {
				  alert("Something went wrong.");
			  } else {
				  location.replace(members_url);
			  }
		  }
	});
}
</script>