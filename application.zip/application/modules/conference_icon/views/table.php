<?php if (empty($icon)) { ?>
<p>Icon not available!</p>
<?php } else { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $icon['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
		    <a href="<?php echo $icon['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="javascript:modalIcon(<?=$icon['icon_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	</div>
</div>
<?php } ?>