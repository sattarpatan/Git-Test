<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?php //title('Add Icon'); ?>
		<?php //view_list(base_url('cms/conference_icon')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php 
		
		if ($this->session->flashdata('banner_add_error')) { ?>
			<?php echo alert_error($this->session->flashdata('banner_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
			<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Icon Image <span class="required">*</span>
			</label>
			<div class="col-md-6 col-sm-6 col-xs-12">
				<div class="jumbotron jumbotron-small">
				<input type="file" name="file" id="file"/>
				<br/>
				<ul class="list-group file-instructions">
					<li class="list-group-item active">INSTRUCTIONS :</li>
					<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
					<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
					<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
				</ul>
				</div>
				<?php echo form_error('file'); ?>
			</div>
		  </div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <a href="<?php echo site_url('conference_icon'); ?>" class="btn btn-danger">Cancel</a>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo site_url('conference_icon'); ?>";</script>