<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Conference_icon extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			//exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else { */
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
			$this->load->model('conference_icon/conference_icon_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		/* } */
    }
	
	public function index()
	{
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['icon'] = $this->conference_icon_model->getConferenceIcon($cnf_id);
		
		$data['_view'] = 'conference_icon/list';
        $this->load->view('layouts/main',$data);
		
		//$this->load->layout2('conference_icon/list',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Conference Icon');
		
		if ($this->form_validation->run('icon_add') == FALSE)
		{	
			$data['_view'] = 'conference_icon/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{			
			
			$newFileName = $this->createFileName($cnf_id);
			$newFile = CONF_ICONS.$newFileName;

			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			//$this->upload->display_errors()
			
			if ($upload_status==false)
			{
		
				$this->session->set_flashdata('banner_add_error', $this->session->flashdata('file_error')); 
				
				$data['_view'] = 'conference_icon/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->conference_icon_model->insertIcon($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('conference_icon_success', 'Icon added successfully!');
					redirect('cms/conference_icon');
				}
				else
				{
					$this->session->set_flashdata('conference_icon_add_error', 'Sorry! Something went wrong. Try Again.');
					$this->load->layout2('conference_icon/add',$data);
				}
			 }
		}
	}
	
	/* public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->conference_icon_model->getIcon($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	} */
	
	function deleteIcon(){
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$icon_id = $this->input->post('icon_id');
		$this->check_access($icon_id,$cnf_id);
		$icon = $this->conference_icon_model->getIcon($icon_id);
		$file = $icon['file_path'];
		$this->load->library('../controllers/upload');
		$delete_status = $this->upload->doDelete($file);
		if ($delete_status==true)
		{
			$this->conference_icon_model->deleteIcon($icon_id);
			$data['icon'] = $this->conference_icon_model->getConferenceIcon($cnf_id);
			return $this->load->view('conference_icon/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($icon_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM conference_icons WHERE icon_id='".$icon_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = 1; //$this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['conference_icon'] = $this->conference_icon_model->getConference_Icon($cnf_id);
			$this->load->layout2('conference_icon/list',$data);
			exit;
		}
	}
	
	public function createFileName($cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		$slug = sluggify_string($fileinfo['filename']);
		return $slug."-".$cnf_id.".".$fileinfo['extension'];
	}
	
	function getIcon(){
		$icon_id = $this->input->post('icon_id');
		$icon = $this->conference_icon_model->getIcon($icon_id);
		echo json_encode($icon);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
}
/************/