		  <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Users <small>Some examples to get you started</small></h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Default Example <small>Users</small></h2>
                    <div class="nav navbar-right panel_toolbox">
                      <a class="btn btn-success" href="<?php echo site_url('conference/index');?>"><i class="fa fa-bars"></i> Go to List</a>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                      The fields marked with <code>*</code> are required.
                    </p>
                    
<?php echo form_open('subject/add',array("class"=>"form-horizontal")); ?>

	<div class="form-group">
		<label for="subject" class="col-md-2 control-label">Subject</label>
		<div class="col-md-8">
			<input type="text" name="subject" value="<?php echo $this->input->post('subject'); ?>" class="form-control" id="subject" />
		</div>
	</div>
	<div class="form-group">
		<label for="slug" class="col-md-2 control-label">Slug</label>
		<div class="col-md-8">
			<input type="text" name="slug" value="<?php echo $this->input->post('slug'); ?>" class="form-control" id="slug" />
		</div>
	</div>
	<div class="form-group">
		<label for="category" class="col-md-2 control-label">Category</label>
		<div class="col-md-8">
			<input type="text" name="category" value="<?php echo $this->input->post('category'); ?>" class="form-control" id="category" />
		</div>
	</div>
	<div class="form-group">
		<label for="emailid" class="col-md-2 control-label">Emailid</label>
		<div class="col-md-8">
			<input type="text" name="emailid" value="<?php echo $this->input->post('emailid'); ?>" class="form-control" id="emailid" />
		</div>
	</div>
	<div class="form-group">
		<label for="type" class="col-md-2 control-label">Type</label>
		<div class="col-md-8">
			<input type="text" name="type" value="<?php echo $this->input->post('type'); ?>" class="form-control" id="type" />
		</div>
	</div>
	<div class="form-group">
		<label for="companytype" class="col-md-2 control-label">Companytype</label>
		<div class="col-md-8">
			<input type="text" name="companytype" value="<?php echo $this->input->post('companytype'); ?>" class="form-control" id="companytype" />
		</div>
	</div>
	<div class="form-group">
		<label for="status" class="col-md-2 control-label">Status</label>
		<div class="col-md-8">
			<input type="text" name="status" value="<?php echo $this->input->post('status'); ?>" class="form-control" id="status" />
		</div>
	</div>
	<div class="form-group">
		<label for="created_date" class="col-md-2 control-label">Created Date</label>
		<div class="col-md-8">
			<input type="text" name="created_date" value="<?php echo $this->input->post('created_date'); ?>" class="form-control" id="created_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="updated_date" class="col-md-2 control-label">Updated Date</label>
		<div class="col-md-8">
			<input type="text" name="updated_date" value="<?php echo $this->input->post('updated_date'); ?>" class="form-control" id="updated_date" />
		</div>
	</div>
	<div class="form-group">
		<label for="description" class="col-md-2 control-label">Description</label>
		<div class="col-md-8">
			<textarea name="description" class="form-control" id="description"><?php echo $this->input->post('description'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="description2" class="col-md-2 control-label">Description2</label>
		<div class="col-md-8">
			<textarea name="description2" class="form-control" id="description2"><?php echo $this->input->post('description2'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="content" class="col-md-2 control-label">Content</label>
		<div class="col-md-8">
			<textarea name="content" class="form-control" id="content"><?php echo $this->input->post('content'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="meta_title" class="col-md-2 control-label">Meta Title</label>
		<div class="col-md-8">
			<textarea name="meta_title" class="form-control" id="meta_title"><?php echo $this->input->post('meta_title'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="meta_keywords" class="col-md-2 control-label">Meta Keywords</label>
		<div class="col-md-8">
			<textarea name="meta_keywords" class="form-control" id="meta_keywords"><?php echo $this->input->post('meta_keywords'); ?></textarea>
		</div>
	</div>
	<div class="form-group">
		<label for="meta_desc" class="col-md-2 control-label">Meta Desc</label>
		<div class="col-md-8">
			<textarea name="meta_desc" class="form-control" id="meta_desc"><?php echo $this->input->post('meta_desc'); ?></textarea>
		</div>
	</div>
	
	<div class="form-group">
		<div class="col-sm-offset-4 col-sm-8">
			<button type="submit" class="btn btn-success">Save</button>
        </div>
	</div>

<?php echo form_close(); ?>					
					
                  </div>
                </div>
              </div>
            </div>
          </div>

