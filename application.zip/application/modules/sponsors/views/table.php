<?php if (empty($sponsors)) { ?>
<p>No Sponsors Available!</p>
<?php } else { ?>
<?php foreach ($sponsors as $sponsor) { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $sponsor['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
			<a href="<?php echo $sponsor['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="<?php echo base_url('sponsors/forceDownload/').$sponsor['sponsor_id']; ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			<a href="javascript:modalBanner(<?=$sponsor['sponsor_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	  <div class="caption">
		<strong><?=$sponsor['title_desc']; ?></strong>
		<p><?=$sponsor['link_url']; ?></p>
	  </div>
	</div>
	<input type="hidden" name="order[]" class="order" value="<?=$sponsor['sponsor_id'];?>">
</div>
<?php } ?>
<?php } ?>