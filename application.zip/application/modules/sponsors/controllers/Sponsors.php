<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sponsors extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('sponsors/sponsors_model');
			$this->load->model('conferences/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		} */
		
		
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('sponsors/sponsors_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
    }
	
	public function index()
	{
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['sponsors'] = $this->sponsors_model->getSponsors($cnf_id);
		
		$data['_view'] = 'sponsors/list';
        $this->load->view('layouts/main',$data);
		
	
	}
	
	
	public function add()
	{	
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Sponsor');
		
		if ($this->form_validation->run('sponsors_add') == FALSE)
		{			
			$data['_view'] = 'sponsors/add';
			$this->load->view('layouts/main',$data);
			//$this->load->layout2('sponsors/add',$data);
		}
		else
		{
			$sql = "SELECT max(sponsor_id)+1 as sponsor_id FROM sponsors";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['sponsor_id'],$cnf_id);
			$newFile = SPONSOR_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('sponsor_add_error', 'File uploading error!'); 
				//$this->load->layout2('sponsors/add',$data);
				$data['_view'] = 'sponsors/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->sponsors_model->insertSponsor($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('sponsors_success', 'Sponsors added successfully!');
					redirect('cms/sponsors');
				}
				else
				{
					$this->session->set_flashdata('sponsor_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('sponsors/add',$data);
					$data['_view'] = 'sponsors/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->sponsors_model->getSponsor($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteSponsor(){
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$sponsor_id = $this->input->post('sponsor_id');
		$sponsor = $this->sponsors_model->getSponsor($sponsor_id);
		$file = $sponsor['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->sponsors_model->deleteSponsor($sponsor_id);
			$data['sponsors'] = $this->sponsors_model->getSponsors($cnf_id);
			return $this->load->view('sponsors/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($sponsor_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM sponsors WHERE sponsor_id='".$sponsor_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['sponsors'] = $this->sponsors_model->getSponsors($cnf_id);
			//$this->load->layout2('sponsors/list',$data);
			$data['_view'] = 'sponsors/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->sponsors_model->updateOrder($order);
		if ($result == true) {
			$data['sponsors'] = $this->sponsors_model->getSponsors($cnf_id);
			return $this->load->view('sponsors/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($sponsor_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$sponsor_id.".".$fileinfo['extension'];
	}
	
	function getSponsor(){
		$sponsor_id = $this->input->post('sponsor_id');
		$sponsor = $this->sponsors_model->getSponsor($sponsor_id);
		echo json_encode($sponsor);
	}
	
	function valid_url_format($str){
		if (!$str){
			return true;
		}
        $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
        if (!preg_match($pattern, $str)){
            $this->form_validation->set_message('valid_url_format', 'The URL you entered is not correct. Ex : http://www.example.com');
            return FALSE;
        }
 
        return TRUE;
    }
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
}
