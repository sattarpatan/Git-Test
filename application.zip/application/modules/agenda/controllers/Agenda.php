<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agenda extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		/* if ($this->session->userdata('user_login')!="Y") {
			redirect('cms/login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('cms/conferences');
		} else {
			//$this->output->enable_profiler(true);
			$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->load->model('agenda_model');
			$this->load->model('conference_model');
			$this->load->model('file_upload_settings_model');
		} */
		
		
		$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
		$this->load->model('agenda/agenda_model');
		$this->load->model('conference/conference_model');
		$this->load->model('file_upload_settings/file_upload_settings_model');
		
		// $this->load->library('pagination');
		
    }
	
	public function index()
	{
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['agendas'] = $this->agenda_model->getAgendas($cnf_id);
		
		$data['_view'] = 'agenda/list';
        $this->load->view('layouts/main',$data);
		
		/* $data['module'] = "agenda";
		$data['view_file'] = "table";
		echo Modules::run('template/two_col', $data); */
	}
	
	
	public function add()
	{	
		$cnf_id = 1; //$this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Agenda Image');
		
		
		//$this->load->library('my_form_validation');
		
		if($this->form_validation->run('agenda_add') == FALSE)
		{			
			$data['_view'] = 'agenda/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(agenda_id)+1 as agenda_id FROM agenda";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['agenda_id'],$cnf_id);
			$newFile = AGENDA_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $newFile, $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('agenda_add_error', 'File uploading error!'); 
				$data['_view'] = 'agenda/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->agenda_model->insertAgenda($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('agenda_success', 'Agenda added successfully!');
					redirect('agenda');
				}
				else
				{
					$this->session->set_flashdata('agenda_add_error', 'Sorry! Something went wrong. Try Again.');
					$data['_view'] = 'agenda/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->agenda_model->getAgenda($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteAgenda(){
		$cnf_id = $this->session->userdata('cnf_id');
		$agenda_id = $this->input->post('agenda_id');
		$this->check_access($agenda_id,$cnf_id);
		$agenda = $this->agenda_model->getAgenda($agenda_id);
		$file = $agenda['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->agenda_model->deleteAgenda($agenda_id);
			$data['agendas'] = $this->agenda_model->getAgendas($cnf_id);
			return $this->load->view('agenda/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($agenda_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM agenda WHERE agenda_id='".$agenda_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['agenda'] = $this->agenda_model->getAgenda($cnf_id);
			$this->load->layout2('agenda/list',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->agenda_model->updateOrder($order);
		if ($result == true) {
			$data['agendas'] = $this->agenda_model->getAgendas($cnf_id);
			return $this->load->view('agenda/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($agenda_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		return $slug."-".$cnf_id."-".$agenda_id.".".$fileinfo['extension'];
	}
	
	function getAgenda(){
		$agenda_id = $this->input->post('agenda_id');
		$agenda = $this->agenda_model->getAgenda($agenda_id);
		echo json_encode($agenda);
	}
	
	public function file_check() {
		
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message(__FUNCTION__, 'The %s field can not be null');
			return false;
		} else {
			return true;
		}
	}
}
/**************/