<?php if (empty($agendas)) { ?>
<p>No Agenda available!</p>
<?php } else { ?>
<?php foreach ($agendas as $agenda) { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $agenda['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
			<a href="<?php echo $agenda['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="javascript:modalAgenda(<?=$agenda['agenda_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	  <div class="caption text-center">
		Date<br/>
		<strong><?=$agenda['date']; ?></strong>
	  </div>
	</div>
	<input type="hidden" name="order[]" class="order" value="<?=$agenda['agenda_id'];?>">
</div>
<?php } ?>
<?php } ?>