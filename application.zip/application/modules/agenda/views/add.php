<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Add Agenda'); ?>
		<?=view_list(base_url('agenda')); ?>
		<div class="clearfix"></div>
	  </div>
	  <div class="x_content">
		<?php if ($this->session->flashdata('agenda_add_error')) { ?>
			<?=alert_error($this->session->flashdata('agenda_add_error')); ?>
		<?php } ?>
		<form id="demo-form2" class="form-horizontal form-label-left" method="post" enctype="multipart/form-data">
		  <div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Agenda Image <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="jumbotron jumbotron-small">
					<input type="file" name="file" id="file"/>
					<br/>
					<ul class="list-group file-instructions">
						<li class="list-group-item active">INSTRUCTIONS :</li>
						<li class="list-group-item">Max Dimentions : <?=$upload_settings['width'];?>px x <?=$upload_settings['height'];?>px only</li>
						<li class="list-group-item">Max Allowed Size : <?=$upload_settings['allowed_size'];?> MB only</li>
						<li class="list-group-item">File Types : <?php echo str_replace("|",", ",$upload_settings['file_types']);?> only</li>
					</ul>
					</div>
					<?php echo form_error('file'); ?>
				</div>
			</div>
			<div class="form-group">
				<label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Agenda Date <span class="required">*</span>
				</label>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="xdisplay_inputx has-feedback">
						<input type="text" class="form-control has-feedback-left datepicker" name="date" placeholder="Start" aria-describedby="inputSuccess2Status">
						<span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
						<span id="inputSuccess2Status" class="sr-only">(success)</span>
					  </div>
					<?php echo form_error('date'); ?>
				</div>
			</div>
		  <div class="ln_solid"></div>
		  <div class="form-group">
			<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
			  <?=cancel(base_url('agenda')); ?>
			  <button type="submit" class="btn btn-success">Submit</button>
			</div>
		  </div>
		</form>
	  </div>
	</div>
  </div>
</div>
<script>var parent_url = "<?php echo base_url('agenda'); ?>";</script>