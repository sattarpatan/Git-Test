<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Collaborations extends MY_Controller {
	
	public function __construct()
	{
        parent::__construct();
		if ($this->session->userdata('user_login')!="Y") {
			redirect('login');
		} else if ($this->session->userdata('user_type')=="Admin" or $this->session->userdata('user_type')=="CTL") {
			$this->load->layout1('general/no_access');
			exit;
		}  else if (empty($this->session->userdata('cnf_id'))) {
			redirect('conferences');
		} else {
			//$this->output->enable_profiler(true);
						
			$this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
			$this->load->model('collaborations/collaborations_model');
			$this->load->model('conference/conference_model');
			$this->load->model('file_upload_settings/file_upload_settings_model');
		}
    }
	
	public function index()
	{
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['collaborations'] = $this->collaborations_model->getCollaborations($cnf_id);
		//$this->load->layout2('collaborations/list',$data);
		$data['_view'] = 'collaborations/list';
        $this->load->view('layouts/main',$data);
	}
	
	
	public function add()
	{	
		$cnf_id = $this->session->userdata('cnf_id');
		$data['conference'] = $this->conference_model->get_conference($cnf_id);
		$data['upload_settings'] = $this->file_upload_settings_model->getFileUploadSetting('Collaboration',$this->session->userdata('company_id'));
		
		if ($this->form_validation->run('collaborations_add') == FALSE)
		{			
			//$this->load->layout2('collaborations/add',$data);
			$data['_view'] = 'collaborations/add';
			$this->load->view('layouts/main',$data);
		}
		else
		{
			$sql = "SELECT max(collaboration_id)+1 as collaboration_id FROM collaborations";
			$query = $this->db->query($sql);
			$result = $query->row_array();				
			$newFileName = $this->createFileName($result['collaboration_id'],$cnf_id);
			
/* 			echo $newFileName; 
			print_r($_FILES['file']);
			exit; */
			$newFile = COLLABORATION_IMAGES.$newFileName;
			
			$this->load->library('../controllers/upload');
			
			$upload_status = $this->upload->doUpload($_FILES['file'], $_FILES['file']['name'], $data['upload_settings']);
			
			if ($upload_status==false)
			{
				$this->session->set_flashdata('colloboration_add_error', 'File uploading error!'); 
				//$this->load->layout2('collaborations/add',$data);
				$data['_view'] = 'collaborations/add';
				$this->load->view('layouts/main',$data);
			}
			else
			{
				$filePath = S3_PATH.$newFile;
				
				$insert_status = $this->collaborations_model->insertCollaboration($filePath);
				
				if ($insert_status==true) {
					$this->session->set_flashdata('collaborations_success', 'Collaboration added successfully!');
					redirect('collaborations');
				}
				else
				{
					$this->session->set_flashdata('colloboration_add_error', 'Sorry! Something went wrong. Try Again.');
					//$this->load->layout2('collaborations/add',$data);
					$data['_view'] = 'collaborations/add';
					$this->load->view('layouts/main',$data);
				}
			 }
		}
	}
	
	public function forceDownload($id) {
		$cnf_id = $this->session->userdata('cnf_id');
		$this->check_access($id,$cnf_id);
		$file = $this->collaborations_model->getCollaboration($id);
		$this->load->helper('download');
		$fileContents = file_get_contents($file['file_path']);
		force_download($file['file_path'],$fileContents);
		exit;
	}
	
	function deleteCollaboration(){
		$cnf_id = $this->session->userdata('cnf_id');
		$collaboration_id = $this->input->post('collaboration_id');
		$this->check_access($collaboration_id,$cnf_id);
		$collaboration = $this->collaborations_model->getCollaboration($collaboration_id);
		$file = $collaboration['file_path'];		
		$this->load->library('../controllers/upload');			
		$delete_status = $this->upload->doDelete($file);		
		if ($delete_status==true)
		{
			$this->collaborations_model->deleteCollaboration($collaboration_id);
			$data['collaborations'] = $this->collaborations_model->getCollaborations($cnf_id);
			return $this->load->view('collaborations/table',$data);
		}
		else
		{
			return false;
		}
	}
	
	function check_access($collaboration_id,$cnf_id){
		$query = $this->db->query("SELECT * FROM collaborations WHERE collaboration_id='".$collaboration_id."' AND cnf_id=".$cnf_id);
		if ($query->num_rows()>0)
		{
			return true;
		}
		else
		{
			$this->session->set_flashdata('member_access_error','Sorry! File not available!');
			$cnf_id = $this->session->userdata('cnf_id');
			$data['conference'] = $this->conference_model->get_conference($cnf_id);
			$data['collaborations'] = $this->collaborations_model->getCollaborations($cnf_id);
			//$this->load->layout2('collaborations/list',$data);
			$data['_view'] = 'collaborations/list';
			$this->load->view('layouts/main',$data);
			exit;
		}
	}
	
	public function updateOrder() {
		$cnf_id = $this->session->userdata('cnf_id');
		$order = $this->input->post('order');
		$result = $this->collaborations_model->updateOrder($order);
		if ($result == true) {
			$data['collaborations'] = $this->collaborations_model->getCollaborations($cnf_id);
			return $this->load->view('collaborations/table',$data);
		} else {
			return false;
		}		
	}
	
	public function createFileName($collaboration_id,$cnf_id) {		
		$fileinfo = pathinfo($_FILES['file']['name']);
		if ($this->input->post('title_desc')!="") {
			$slug = sluggify_string($this->input->post('title_desc'));
		} else {
			$slug = sluggify_string($fileinfo['filename']);
		}
		echo $slug."-".$cnf_id."-".$collaboration_id.".".$fileinfo['extension'];
	}
	
	function getCollaboration(){
		$collaboration_id = $this->input->post('collaboration_id');
		$collaboration = $this->collaborations_model->getCollaboration($collaboration_id);
		echo json_encode($collaboration);
	}
	
	public function file_check() {
		if (empty($_FILES['file']['name']))
		{
			$this->form_validation->set_message('file_check', 'Please select image');
			return false;
		} else {
			return true;
		}
	}
}