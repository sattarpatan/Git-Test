<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
	  <div class="x_title">
		<?=title('Collaborations'); ?>
		<div class="nav navbar-right panel_toolbox">
			<div class="form-group">
				<div class="col-md-12 col-sm-12 col-xs-12">
				  <a class="btn btn-success" href="<?=base_url('collaborations/add'); ?>">
					<i class="fa fa-plus"></i> ADD</a>
				  <a href="#" name="order" class="btn btn-success" id="update_order"/>
					<i class="fa fa-first-order"></i> Update Order</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	  </div>
		<div class="x_content">
		<?php if ($this->session->flashdata('collaborations_success')) { ?>
		<?=alert_success($this->session->flashdata('collaborations_success')); ?>
		<?php } ?>
		<div id="alerts"></div>
		<div class="row" id="sortable">
			<?php $this->load->view('collaborations/table'); ?>
		</div>
	  </div>
	  </div>
  </div>
</div>
<button style="display:none;" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="model_btn">Open Modal</button>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Delete Collaboration</h4>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
		<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		<button type="button" class="btn btn-danger" onclick="deleteCollaboration()">Delete</button>
		<input type="hidden" name="collaboration_id" id="collaboration_id"/>
      </div>
    </div>
  </div>
</div>
<script>
var order_url = "<?php echo base_url('collaborations/updateOrder'); ?>";
var get_collaboration_url = "<?php echo base_url('collaborations/getCollaboration'); ?>";
var delete_url = "<?php echo base_url('collaborations/deleteCollaboration'); ?>";
window.onload = function() {
	$("#sortable").sortable();	
	$("#update_order").click(function(){
		var order = $('input[name="order\[\]"').serializeArray();
		var alertMsg = $("#alerts");
		alertMsg.css("display","none");
		$.ajax({
			  type: "POST",
			  url: order_url,
			  data: {order:order},
			  success: function(resultData){
					alertMsg.html(successMsg("Collaborations order updated!"))
					.slideDown(100);
					$("#sortable").html(resultData);
					$("#sortable").sortable();
			  },
			  error: function(){
					alertMsg.html(errorMsg("Not updated, something went wrong!"))
					.slideDown(100);
			  }
		});
	});
}
function modalCollaboration(collaboration_id){
	$.ajax({
		  type: "POST",
		  url:get_collaboration_url,
		  data:{collaboration_id:collaboration_id},
		  dataType:"json",
		  success:function(response){
			 var file = response.file_path;
			 $("#collaboration_id").val(collaboration_id);
			 $(".modal-body").html("<p><img src="+file+" class='img img-responsive' \/></p><h4 class='text-danger'>Are you sure you want to delete this collaboration?</h4>");
			 $("#model_btn").click();
		  }
	});
}

function deleteCollaboration(){
	var alertMsg = $("#alerts");
	alertMsg.css("display","none");
    $.ajax({
		  type: "POST",
		  url:delete_url,
		  data:{collaboration_id:$("#collaboration_id").val()},
		  success:function(response){
			  if (response==false) {
				  alertMsg.html(errorMsg("Something went wrong."))
				  .slideDown(100);
			  } else {
				  $("#sortable").html(response);
				  alertMsg.html(successMsg("Deleted!"))
				  .slideDown(100);
			  }
			  $('#myModal').modal('hide');
		  }
	});
}
</script>