<?php if (empty($collaborations)) { ?>
<p>No Collaborations available!</p>
<?php } else { ?>
<?php foreach ($collaborations as $collaboration) { ?>
<div class="col-md-55">
	<div class="thumbnail">
	  <div class="image view view-first">
		<img style="width: 100%; display: block;" src="<?php echo $collaboration['file_path']; ?>" alt="image">
		<div class="mask">
		  <p>&nbsp;</p>
		  <div class="tools tools-bottom">
			<a href="<?php echo $collaboration['file_path']; ?>" target="_blank" title="View"><i class="fa fa-eye"></i></a>
			<a href="<?php echo base_url('collaborations/forceDownload/100'); ?>" title="Download"><i class="fa fa-cloud-download"></i></a>
			<a href="javascript:modalCollaboration(<?=$collaboration['collaboration_id'];?>);" title="Delete"><i class="fa fa-times"></i></a>
		  </div>
		</div>
	  </div>
	  <div class="caption">
		<strong><?=$collaboration['title_desc']; ?></strong>
		<p><?=$collaboration['link_url']; ?></p>
	  </div>
	</div>
	<input type="hidden" name="order[]" class="order" value="<?=$collaboration['collaboration_id'];?>">
</div>
<?php } ?>
<?php } ?>