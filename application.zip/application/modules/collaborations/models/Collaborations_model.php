<?php

class Collaborations_model extends CI_Model {

	public function getCollaborations($cnf_id) {
		$sql = "SELECT b.*, f.* FROM collaborations b join filemaster f on b.file_id=f.file_id WHERE b.cnf_id=? ORDER BY b.order_no ASC";
		$query = $this->db->query($sql,$cnf_id);
		//echo $this->db->last_query();
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->result_array();
		} else {
			return array();
		}
	}
	
	public function getCollaboration($collaboration_id) {
		$sql = "SELECT b.*, f.* FROM collaborations b join filemaster f on b.file_id=f.file_id WHERE b.collaboration_id=?";
		$query = $this->db->query($sql,array($collaboration_id));
		$cnt = $query->num_rows();
		if ($cnt>0) {
			return $query->row_array();
		} else {
			return array();
		}
	}
	
	public function deleteCollaboration($collaboration_id){
		
		$this->db->trans_start();
		
		$sql = "delete from filemaster where file_id=(select file_id from collaborations where collaboration_id=?)";
		$this->db->query($sql,array($collaboration_id));
		
		$sql = "delete from collaborations where collaboration_id=?";
		$this->db->query($sql,array($collaboration_id));
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function insertCollaboration($filepath) {
		
		$this->db->trans_start();
		
		$data = array(
			'file_path' 		=> 	$filepath,
			'title_desc'		=>	clean_title($this->input->post('title_desc')),
			'link_url'			=>	$this->input->post('link_url'),
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('filemaster',$data);
		
		$insert_id = $this->db->insert_id();
		
		$sql = "SELECT max(order_no)+1 as max_id FROM collaborations WHERE cnf_id=?";
		$query = $this->db->query($sql,$this->session->userdata('cnf_id'));
		
		$data = array(
			'file_id' 			=> 	$insert_id,
			'cnf_id'			=>	$this->session->userdata('cnf_id'),
			'order_no'			=>	$query->row_array()['max_id'],
			'created_by'		=> 	$this->session->userdata('user_id'),
			'created_datetime'	=>	date('Y-m-d H:i:s'),
			'updated_by' 		=> 	$this->session->userdata('user_id'),
			'updated_datetime'	=>	date('Y-m-d H:i:s')
		);
		
		$this->db->insert('collaborations',$data);
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}
	}
	
	public function updateOrder($order) {
		
		$this->db->trans_start();
		
		$i=1;
		
		foreach ($order as $key => $value) {			
			$data = array(
				'order_no' 			=> 	$i++,
				'updated_by' 		=> 	$this->session->userdata('user_id'),
				'updated_datetime'	=>	date('Y-m-d H:i:s')
			);
			$this->db->where('collaboration_id',$value['value']);
			$this->db->update('collaborations',$data);
		}
		
		$this->db->trans_complete();
		
		if ($this->db->trans_status() === FALSE)
		{
			$this->db->trans_rollback();
			return false;
		}
		else
		{
			$this->db->trans_commit();
			return true;
		}		
	}
}