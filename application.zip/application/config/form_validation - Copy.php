<?php

$config = array(

	'login' => array(
	
		array(
			'field' => 'user_name',
			'label' => 'User Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'user_password',
			'label' => 'Password',
			'rules' => 'required|callback_check_login'
		),
	),
	
	'user_add' => array(
	
		array(
			'field' => 'user_type',
			'label' => 'User Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'user_displayname',
			'label' => 'Display Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'user_email',
			'label' => 'Email ID',
			'rules' => 'required|callback_check_email'
		),
		
		array(
			'field' => 'user_name',
			'label' => 'User Name',
			'rules' => 'required|callback_check_username'
		),
		
		array(
			'field' => 'user_password',
			'label' => 'Password',
			'rules' => 'required'
		),
	),
	
	'user_edit_profile' => array(
	
		array(
			'field' => 'user_type',
			'label' => 'User Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'user_displayname',
			'label' => 'Display Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'user_email',
			'label' => 'Email ID',
			'rules' => 'required|callback_check_email_for_edit'
		),
		
		array(
			'field' => 'user_name',
			'label' => 'User Name',
			'rules' => 'required|callback_check_username_for_edit'
		),
		
		array(
			'field' => 'user_status',
			'label' => 'Status',
			'rules' => 'required'
		),
	),
	
	'user_edit_password' => array(
	
		array(
			'field' => 'user_password',
			'label' => 'Password',
			'rules' => 'required'
		)
	),
	
	'update_name' => array(
	
		array(
			'field' => 'user_displayname',
			'label' => 'Display Name',
			'rules' => 'required'
		)
	),
	
	'update_password' => array(
	
		array(
			'field' => 'old_password',
			'label' => 'Old Password',
			'rules' => 'required|callback_check_password'
		),
	
		array(
			'field' => 'user_password',
			'label' => 'New Password',
			'rules' => 'required|matches[confirm_password]|min_length[6]|max_length[20]'
		),
		
		array(
			'field' => 'confirm_password',
			'label' => 'Confirm Password',
			'rules' => 'required'
		),
	),
	
	'conference_add' => array(
	
		array(
			'field' => 'cnf_url',
			'label' => 'Conference URL',
			'rules' => 'required|callback_check_cnf_url'
		),
		
		array(
			'field' => 'cnf_pc',
			'label' => 'PC',
			'rules' => 'required'
		),
		
		array(
			'field' => 'cnf_tl',
			'label' => 'TL',
			'rules' => 'required'
		),
		
		array(
			'field' => 'cnf_ctl',
			'label' => 'CTL',
			'rules' => 'required'
		),
	),
	
	'conference_edit' => array(
	
		array(
			'field' => 'cnf_url',
			'label' => 'Conference URL',
			'rules' => 'required|callback_check_cnf_url_for_edit'
		),
		
		array(
			'field' => 'cnf_pc',
			'label' => 'PC',
			'rules' => 'required'
		),
		
		array(
			'field' => 'cnf_tl',
			'label' => 'TL',
			'rules' => 'required'
		),
		
		array(
			'field' => 'cnf_ctl',
			'label' => 'CTL',
			'rules' => 'required'
		),
	),
	
	'primary_add' => array(
		
		/* array(
			'field' => 'main_title',
			'label' => 'Main Title',
			'rules' => 'required'
		),
		
		array(
			'field' => 'theme',
			'label' => 'Conference Theme',
			'rules' => 'required'
		), */
		
		array(
			'field' => 'subject_id',
			'label' => 'Subject',
			'rules' => 'required'
		),
		
		array(
			'field' => 'start_date',
			'label' => 'Start Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'end_date',
			'label' => 'End Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'region_id',
			'label' => 'Region',
			'rules' => 'required'
		),
		
		array(
			'field' => 'country_id',
			'label' => 'Country',
			'rules' => 'required'
		),
		
		array(
			'field' => 'city_id',
			'label' => 'City',
			'rules' => 'required'
		),
	),
	
	'primary_edit' => array(
		
		/* array(
			'field' => 'main_title',
			'label' => 'Main Title',
			'rules' => 'required'
		),
		
		array(
			'field' => 'theme',
			'label' => 'Conference Theme',
			'rules' => 'required'
		), */
		
		array(
			'field' => 'subject_id',
			'label' => 'Subject',
			'rules' => 'required'
		),
		
		array(
			'field' => 'start_date',
			'label' => 'Start Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'end_date',
			'label' => 'End Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'region_id',
			'label' => 'Region',
			'rules' => 'required'
		),
		
		array(
			'field' => 'country_id',
			'label' => 'Country',
			'rules' => 'required'
		),
		
		array(
			'field' => 'city_id',
			'label' => 'City',
			'rules' => 'required'
		),
	),
	
	'subjects_add' => array(
	
		array(
			'field' => 'subject_name',
			'label' => 'Subject Name',
			'rules' => 'required|callback_check_subject'
		),
		
		array(
			'field' => 'parent_id',
			'label' => 'Category',
			'rules' => 'required'
		),
		
	),
	
	'subject_edit' => array(
	
		array(
			'field' => 'subject_name',
			'label' => 'Subject Name',
			'rules' => 'required|callback_check_subject_for_edit'
		),
		
		array(
			'field' => 'parent_id',
			'label' => 'Category',
			'rules' => 'required'
		),
		
	),
	
	'subject_categories_add' => array(
	
		array(
			'field' => 'subject_name',
			'label' => 'Category Name',
			'rules' => 'required|callback_check_subject_category'
		),		
	),
	
	'subject_categories_edit' => array(
	
		array(
			'field' => 'subject_name',
			'label' => 'Category Name',
			'rules' => 'required|callback_check_subject_category_for_edit'
		),		
	),
	
	'days_add' => array(
	
		array(
			'field' => 'day_date',
			'label' => 'Date',
			'rules' => 'required'
		),
	),
	
	'sessions_add' => array(
	
		array(
			'field' => 'day_id',
			'label' => 'Day',
			'rules' => 'required'
		),
	),
	
	'sessions_edit' => array(
	
		array(
			'field' => 'day_id',
			'label' => 'Day',
			'rules' => 'required'
		),
	),
	
	'session_tracks_add' => array(
	
		array(
			'field' => 'track_id',
			'label' => 'Track',
			'rules' => 'required|callback_check_session_track'
		),
	),
	
	'session_tracks_edit' => array(
	
		array(
			'field' => 'track_id',
			'label' => 'Track',
			'rules' => 'required|callback_check_session_track_for_edit'
		),
	),
	
	'tracks_add' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name'
		),
	),
	
	'tracks_edit' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name_for_edit'
		),
	),
	
	'subtracks_add' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name'
		),
	),
	
	'subtracks_edit' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name_for_edit'
		),
	),
	
	'seo_pages_add' => array(
	
		array(
			'field' => 'page_title',
			'label' => 'Page Title',
			'rules' => 'required|callback_check_seo_page'
		),
	),
	
	'seo_pages_edit' => array(
	
		array(
			'field' => 'page_title',
			'label' => 'Page Title',
			'rules' => 'required|callback_check_seo_page_for_edit'
		),
	),
	
	'amenities_add' => array(
	
		array(
			'field' => 'amenity_name',
			'label' => 'Amenity Name',
			'rules' => 'required|callback_check_amenity'
		),
	),
	
	'amenities_edit' => array(
	
		array(
			'field' => 'amenity_name',
			'label' => 'Amenity Name',
			'rules' => 'required|callback_check_amenity_for_edit'
		),
	),
	
	'regions_add' => array(
	
		array(
			'field' => 'region_name',
			'label' => 'Region Name',
			'rules' => 'required|callback_check_region'
		),
	),
	
	'regions_edit' => array(
	
		array(
			'field' => 'region_name',
			'label' => 'Region Name',
			'rules' => 'required|callback_check_region_for_edit'
		),
	),
	
	'companies_add' => array(
	
		array(
			'field' => 'company_name',
			'label' => 'Company Name',
			'rules' => 'required|callback_check_company'
		),
	),
	
	'companies_edit' => array(
	
		array(
			'field' => 'company_name',
			'label' => 'Company Name',
			'rules' => 'required|callback_check_company_for_edit'
		),
	),
	
	'countries_add' => array(
	
		array(
			'field' => 'country_name',
			'label' => 'Country Name',
			'rules' => 'required|callback_check_country'
		),
	),
	
	'countries_edit' => array(
	
		array(
			'field' => 'country_name',
			'label' => 'Country Name',
			'rules' => 'required|callback_check_country_for_edit'
		),
	),
	
	'states_add' => array(
	
		array(
			'field' => 'state_name',
			'label' => 'State Name',
			'rules' => 'required|callback_check_state'
		),
	),
	
	'states_edit' => array(
	
		array(
			'field' => 'state_name',
			'label' => 'State Name',
			'rules' => 'required|callback_check_state_for_edit'
		),
	),
	
	'cities_add' => array(
	
		array(
			'field' => 'city_name',
			'label' => 'City Name',
			'rules' => 'required|callback_check_city'
		),
	),
	
	'cities_edit' => array(
	
		array(
			'field' => 'city_name',
			'label' => 'City Name',
			'rules' => 'required|callback_check_city_for_edit'
		),
	),
	
	'universities_add' => array(
	
		array(
			'field' => 'university_name',
			'label' => 'University Name',
			'rules' => 'required|callback_check_university'
		),
	),
	
	'universities_edit' => array(
	
		array(
			'field' => 'university_name',
			'label' => 'University Name',
			'rules' => 'required|callback_check_university_for_edit'
		),
	),
	
	'content_groups_add' => array(
	
		array(
			'field' => 'content_group_name',
			'label' => 'Content Group Name',
			'rules' => 'required|callback_check_content_group_name'
		),
	),
	
	'content_groups_edit' => array(
	
		array(
			'field' => 'content_group_name',
			'label' => 'Content Group Name',
			'rules' => 'required|callback_check_content_group_name_for_edit'
		),
	),
	
	'content_titles_add' => array(
	
		array(
			'field' => 'content_title',
			'label' => 'Content Title',
			'rules' => 'required|callback_check_content_title'
		),
	),
	
	
	'content_titles_edit' => array(
	
		array(
			'field' => 'content_title',
			'label' => 'Content Title',
			'rules' => 'required|callback_check_content_title_for_edit'
		),
	),
	
	'banners_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Banner Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'icon_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Icon Image',
			'rules' => 'callback_file_check'
		),
		
	),
	
	'journals_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'sponsors_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Sponsor Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'media_partners_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Partner Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'collaborations_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Collaboration Image',
			'rules' => 'callback_file_check'
		),
		
		/* array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		), */
	),
	
	'exhibitors_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Exhibitor Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'gallery_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'File',
			'rules' => 'callback_file_check'
		),
	),
	
	'documents_add' => array(
	
		array(
			'field' => 'type',
			'label' => 'Document Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'file',
			'label' => 'File',
			'rules' => 'callback_file_check'
		),
	),
	
	'testimonials_add' => array(
	
		array(
			'field' => 'testimonial',
			'label' => 'Testimonial',
			'rules' => 'required'
		),
		
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'file',
			'label' => 'Testimonial Image',
			'rules' => 'callback_file_check'
		),
		
		
	),
	
	'testimonials_edit' => array(
		
		array(
			'field' => 'testimonial',
			'label' => 'Testimonial',
			'rules' => 'required'
		),
		
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'valid_email'
		),
	),
	
	'webinars_add' => array(
	
	    array(
			'field' => 'type',
			'label' => 'Select Type',
			'rules' => 'required'
		),
		
		 array(
			'field' => 'date',
			'label' => 'Date',
			'rules' => 'required'
		),
	
		array(
			'field' => 'title',
			'label' => 'Title',
			'rules' => 'required'
		),
		
		array(
			'field' => 'speaker',
			'label' => 'Speaker',
			'rules' => 'required'
		),
		
		

		
	),
	
		'latest_report_add' => array(
	
	  
		 array(
			'field' => 'date',
			'label' => 'Date',
			'rules' => 'required'
		),
	
		array(
			'field' => 'title',
			'label' => 'Title',
			'rules' => 'required'
		),
		
		array(
			'field' => 'description',
			'label' => 'Description',
			'rules' => 'required'
		),
	
	),
	
	'latest_report_edit' => array(
	
	  
		 array(
			'field' => 'date',
			'label' => 'Date',
			'rules' => 'required'
		),
	
		array(
			'field' => 'title',
			'label' => 'Title',
			'rules' => 'required'
		),
		
		array(
			'field' => 'description',
			'label' => 'Description',
			'rules' => 'required'
		),
	
	),
	
	
	
	
	
	'webinars_edit' => array(
	
	    array(
			'field' => 'type',
			'label' => 'Select Type',
			'rules' => 'required'
		),
	
	    array(
			'field' => 'date',
			'label' => 'Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'title',
			'label' => 'Title',
			'rules' => 'required'
		 ),
		
		array(
			'field' => 'speaker',
			'label' => 'Speaker',
			'rules' => 'required'
		),
		
		
		
	),
	
	'contacts_add' => array(
	
		array(
			'field' => 'email1',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'email2',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'email3',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
	),
	
	
	'contacts_edit' => array(
	
		array(
			'field' => 'email1',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'email2',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'email3',
			'label' => 'Label',
			'rules' => 'valid_email'
		),
	),
	
	'city_images_add' => array(
	
		array(
			'field' => 'city_image',
			'label' => 'City Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'venue_images_add' => array(
	
		array(
			'field' => 'venue_image',
			'label' => 'Venue Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'members_add' => array(
	
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'company',
			'label' => 'Company',
			'rules' => 'required'
		),
		
		array(
			'field' => 'u_designation',
			'label' => 'Designation',
			'rules' => 'required'
		),
		
		/* array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'required|valid_email|callback_email_check'
		), */
	),
	
	'members_edit' => array(
	
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'company',
			'label' => 'Company',
			'rules' => 'required'
		),
		
		array(
			'field' => 'u_designation',
			'label' => 'Designation',
			'rules' => 'required'
		),
		
		/* array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'required|valid_email|callback_email_check_for_edit'
		), */
	),
	
	'file_upload_settings_add' => array(
	
		array(
			'field' => 'file_name',
			'label' => 'File Name',
			'rules' => 'required|callback_check_file_name'
		)
	),
	
	'file_upload_settings_edit' => array(
	
		array(
			'field' => 'file_name',
			'label' => 'File Name',
			'rules' => 'required|callback_check_file_name_for_edit'
		),
	),
	
	'currencies_add' => array(
	
		array(
			'field' => 'currency_code',
			'label' => 'Currency Code',
			'rules' => 'required|callback_check_currency_code'
		),
		array(
			'field' => 'currency_symbol',
			'label' => 'Currency Symbol',
			'rules' => 'required'
		)
	),
	
	'currencies_edit' => array(
	
		array(
			'field' => 'currency_code',
			'label' => 'Currency Code',
			'rules' => 'required'
		),
		array(
			'field' => 'currency_symbol',
			'label' => 'Currency Symbol',
			'rules' => 'required'
		)
	),
	
	'tickets_add' => array(
	
		array(
			'field' => 'ticket_type',
			'label' => 'Ticket Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'ticket_name',
			'label' => 'Ticket Name',
			'rules' => 'required|callback_check_ticket_name'
		),
		
		array(
			'field' => 'currency',
			'label' => 'Currency',
			'rules' => 'callback_check_currencies'
		),
	),
	
	'tickets_edit' => array(
	
		array(
			'field' => 'ticket_type',
			'label' => 'Ticket Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'ticket_name',
			'label' => 'Ticket Name',
			'rules' => 'required|callback_check_ticket_name_for_edit'
		),
		
		array(
			'field' => 'currency',
			'label' => 'Currency',
			'rules' => 'callback_check_currencies'
		),
	),
	
	'discounts_add' => array(
	
		array(
			'field' => 'discount_value',
			'label' => 'Ticket Value',
			'rules' => 'required'
		),
		
		array(
			'field' => 'discount_code',
			'label' => 'Dicount Code',
			'rules' => 'required|callback_check_discount_code'
		),
		
		array(
			'field' => 'expiry_date',
			'label' => 'Expiry Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'tickets',
			'label' => 'Tickets',
			'rules' => 'callback_check_tickets'
		),
	),
	
	'discounts_edit' => array(
	
		array(
			'field' => 'discount_value',
			'label' => 'Ticket Value',
			'rules' => 'required'
		),
		
		array(
			'field' => 'discount_code',
			'label' => 'Dicount Code',
			'rules' => 'required|callback_check_discount_code_for_edit'
		),
		
		array(
			'field' => 'expiry_date',
			'label' => 'Expiry Date',
			'rules' => 'required'
		),
		
		array(
			'field' => 'tickets',
			'label' => 'Tickets',
			'rules' => 'callback_check_tickets'
		),
	),
	
	'social_media_add' => array(
	
		array(
			'field' => 'facebook',
			'label' => 'Facebook',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'twitter',
			'label' => 'Twitter',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'linkedin',
			'label' => 'Linkedin',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'youtube',
			'label' => 'Youtube',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'flickr',
			'label' => 'Flickr',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'google-plus',
			'label' => 'Google-plus',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'pinterest',
			'label' => 'Pinterest',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'rss',
			'label' => 'RSS',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'blogspot',
			'label' => 'Blogspot',
			'rules' => 'trim|valid_url'
		),
	),
	
	'social_media_edit' => array(
		
		array(
			'field' => 'facebook',
			'label' => 'Facebook',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'twitter',
			'label' => 'Twitter',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'linkedin',
			'label' => 'Linkedin',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'youtube',
			'label' => 'Youtube',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'flickr',
			'label' => 'Flickr',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'google-plus',
			'label' => 'Google-plus',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'pinterest',
			'label' => 'Pinterest',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'rss',
			'label' => 'RSS',
			'rules' => 'trim|valid_url'
		),
		
		array(
			'field' => 'blogspot',
			'label' => 'Blogspot',
			'rules' => 'trim|valid_url'
		),
	),	
);