<?php

$config = array(

	'icon_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Icon 1Image',
			'rules' => 'callback_file_check'
		),
		
	),
	
	'agenda_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Agenda Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'date',
			'label' => 'Date',
			'rules' => 'required'
		),
		
	),
	
	'banners_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Banner Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	
	
	'journals_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'sponsors_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Sponsor Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'media_partners_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Partner Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'collaborations_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Collaboration Image',
			'rules' => 'callback_file_check'
		),
		
		/* array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		), */
	),
	
	'exhibitors_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'Exhibitor Image',
			'rules' => 'callback_file_check'
		),
		
		array(
			'field' => 'link_url',
			'label' => 'URL',
			'rules' => 'trim|callback_valid_url_format'
		),
	),
	
	'gallery_add' => array(
	
		array(
			'field' => 'file',
			'label' => 'File',
			'rules' => 'callback_file_check'
		),
	),
	
	'documents_add' => array(
	
		array(
			'field' => 'type',
			'label' => 'Document Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'file',
			'label' => 'File',
			'rules' => 'callback_file_check'
		),
	),
	
	'testimonials_add' => array(
	
		array(
			'field' => 'testimonial',
			'label' => 'Testimonial',
			'rules' => 'required'
		),
		
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'valid_email'
		),
		
		array(
			'field' => 'file',
			'label' => 'Testimonial Image',
			'rules' => 'callback_file_check'
		),
		
		
	),
	
	'testimonials_edit' => array(
		
		array(
			'field' => 'testimonial',
			'label' => 'Testimonial',
			'rules' => 'required'
		),
		
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'valid_email'
		),
	),
	
	'tracks_add' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name'
		),
	),
	
	'tracks_edit' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name_for_edit'
		),
	),
	
	'subtracks_add' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name'
		),
	),
	
	'subtracks_edit' => array(
	
		array(
			'field' => 'track_name',
			'label' => 'Track Name',
			'rules' => 'required|callback_check_track_name_for_edit'
		),
	),
	
	'days_add' => array(
	
		array(
			'field' => 'day_date',
			'label' => 'Date',
			'rules' => 'required'
		),
	),
	
	'sessions_add' => array(
	
		array(
			'field' => 'day_id',
			'label' => 'Day',
			'rules' => 'required'
		),
	),
	
	'sessions_edit' => array(
	
		array(
			'field' => 'day_id',
			'label' => 'Day',
			'rules' => 'required'
		),
	),
	
	'session_tracks_add' => array(
	
		array(
			'field' => 'track_id',
			'label' => 'Track',
			'rules' => 'required|callback_check_session_track'
		),
	),
	
	'session_tracks_edit' => array(
	
		array(
			'field' => 'track_id',
			'label' => 'Track',
			'rules' => 'required|callback_check_session_track_for_edit'
		),
	),
	
	'members_add' => array(
	
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'company',
			'label' => 'Company',
			'rules' => 'required'
		),
		
		array(
			'field' => 'u_designation',
			'label' => 'Designation',
			'rules' => 'required'
		),
		
		/* array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'required|valid_email|callback_email_check'
		), */
	),
	
	'members_edit' => array(
	
		array(
			'field' => 'name',
			'label' => 'Name',
			'rules' => 'required'
		),
		
		array(
			'field' => 'company',
			'label' => 'Company',
			'rules' => 'required'
		),
		
		array(
			'field' => 'u_designation',
			'label' => 'Designation',
			'rules' => 'required'
		),
		
		/* array(
			'field' => 'email',
			'label' => 'Email',
			'rules' => 'required|valid_email|callback_email_check_for_edit'
		), */
	),
	
	'currencies_add' => array(
	
		array(
			'field' => 'currency_code',
			'label' => 'Currency Code',
			'rules' => 'required|callback_check_currency_code'
		),
		array(
			'field' => 'currency_symbol',
			'label' => 'Currency Symbol',
			'rules' => 'required'
		)
	),
	
	'currencies_edit' => array(
	
		array(
			'field' => 'currency_code',
			'label' => 'Currency Code',
			'rules' => 'required'
		),
		array(
			'field' => 'currency_symbol',
			'label' => 'Currency Symbol',
			'rules' => 'required'
		)
	),
	
	'tickets_add' => array(
	
		array(
			'field' => 'ticket_type',
			'label' => 'Ticket Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'ticket_name',
			'label' => 'Ticket Name',
			'rules' => 'required|callback_check_ticket_name'
		),
		
		array(
			'field' => 'currency',
			'label' => 'Currency',
			'rules' => 'callback_check_currencies'
		),
	),
	
	'tickets_edit' => array(
	
		array(
			'field' => 'ticket_type',
			'label' => 'Ticket Type',
			'rules' => 'required'
		),
		
		array(
			'field' => 'ticket_name',
			'label' => 'Ticket Name',
			'rules' => 'required|callback_check_ticket_name_for_edit'
		),
		
		array(
			'field' => 'currency',
			'label' => 'Currency',
			'rules' => 'callback_check_currencies'
		),
	),
	
	
	
	
	
	
	
	
);
