<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('title'))
{
    function title($title)
    {
        return '<h2 class="text-success">'.$title.'</h2>'; 
    }   
}

if (!function_exists('status'))
{
    function status($status)
    {
        return ($status==1) ? '<button class="btn btn-success btn-xs">Active</button>' : '<button class="btn btn-danger btn-xs">Inactive</button>'; 
    }   
}

if (!function_exists('rstatus'))
{
    function rstatus($status)
    {
        return ($status=="Approved") ? '<button class="btn btn-success btn-xs">Approved</button>' : '<button class="btn btn-danger btn-xs">Pending</button>'; 
    }   
}

if (!function_exists('manage'))
{
    function manage($cnf_id)
    {
		return '<a href="#" class="btn btn-primary btn-xs" onclick="set_conference('.$cnf_id.')"><i class="fa fa-cog"></i> Manage</a>'; 
    }   
}

if (!function_exists('edit'))
{
    function edit($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit</a>'; 
		}
    }   
}

if (!function_exists('edit_profile'))
{
    function edit_profile($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Profile</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Profile</a>'; 
		}
    }   
}

if (!function_exists('edit_password'))
{
    function edit_password($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Password</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit Password</a>'; 
		}
    }   
}

if (!function_exists('delete'))
{
    function delete($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Delete</a>'; 
		}
    }   
}

if (!function_exists('remove_from_conf'))
{
    function remove_from_conf($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-warning btn-xs"><i class="fa fa-arrow-down"></i> Remove from Conference</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-warning btn-xs"><i class="fa fa-arrow-down"></i> Remove from Conference</a>'; 
		}
    }   
}

if (!function_exists('add_to_conf'))
{
    function add_to_conf($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-success btn-xs"><i class="fa fa-arrow-up"></i> Add to Conference</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-success btn-xs"><i class="fa fa-arrow-up"></i> Add to Conference</a>'; 
		}
    }   
}

if (!function_exists('view'))
{
    function view($url,$id=NULL)
    {
        if ($id!=NULL)
		{
			return '<a href="'.$url.'/'.$id.'" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>'; 
		}
		else
		{
			return '<a href="'.$url.'" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> View</a>'; 
		}
    }   
}

if (!function_exists('add'))
{
    function add($url)
    {
        return '<div class="nav navbar-right panel_toolbox">
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <a class="btn btn-success" href="'.$url.'"><i class="fa fa-plus"></i> ADD</a>
						</div>
					</div>
				</div>'; 
    }   
}

if (!function_exists('select'))
{
    function select($url)
    {
        return '<div class="nav navbar-right panel_toolbox">
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <a class="btn btn-success" href="'.$url.'"><i class="fa fa-hand-pointer-o"></i> SELECT</a>
						</div>
					</div>
				</div>'; 
    }   
}

if (!function_exists('view_list'))
{
    function view_list($url)
    {
        return '<div class="nav navbar-right panel_toolbox">
					<div class="form-group">
						<div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
						  <a class="btn btn-success" href="'.$url.'"><i class="glyphicon glyphicon-list-alt"></i> LIST</a>
						</div>
					</div>
				</div>'; 
    }   
}

if (!function_exists('cancel'))
{
    function cancel($url)
    {
        return '<a class="btn btn-primary" href="'.$url.'">Cancel</a>'; 
    }   
}

if (!function_exists('alert_error'))
{
    function alert_error($msg)
    {
        return '<div class="alert alert-danger alert-dismissable"> 
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
			<span class="sr-only">Error:</span>
			'.$msg.'
			</div>'; 
    }   
}

if (!function_exists('alert_success'))
{
    function alert_success($msg)
    {
        return '<div class="alert alert-success alert-dismissable"> 
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			<span class="glyphicon glyphicon-tree-deciduous" aria-hidden="true"></span>
			<span class="sr-only">Success:</span>
			'.$msg.'
			</div>'; 
    }   
}

if (!function_exists('sluggify_string'))
{
	function sluggify_string( $string ) {
		$string = preg_replace('/[^A-Za-z0-9\- ]/', '', $string);
		$string = preg_replace('/[\s-]+/', '-', $string);
		$string = trim($string, '.-_');
		return $string = strtolower($string);
	}
}

if (!function_exists('clean_title'))
{
	function clean_title( $string ) {
		$string = preg_replace('/[^A-Za-z0-9\-, ]/', '', $string);
		return $string = trim($string, '.-_');
	}
}

if (!function_exists('clean_meta_data'))
{
	function clean_meta_data( $string ) {
		$string = preg_replace('/[^A-Za-z0-9\-|, ]/', '', $string);
		return $string = trim($string, '.-_');
	}
}

if (!function_exists('ticket_type_name'))
{
	function ticket_type_name( $ticket_type ) {
		
		if ($ticket_type==1) {
			return "Academic";
		}
		if ($ticket_type==2) {
			return "Business";
		}
		if ($ticket_type==3) {
			return "Student";
		}
		if ($ticket_type==4) {
			return "Addon";
		}
		if ($ticket_type==5) {
			return "e-Poster";
		}
		if ($ticket_type==6) {
			return "Exhibitor";
		}
		if ($ticket_type==7) {
			return "Sponsor";
		}
		if ($ticket_type==8) {
			return "Webinar";
		}
	}
}

if (!function_exists('discount_type_name'))
{
	function discount_type_name( $discount_type ) {
		
		if ($discount_type==1) {
			return "Flat";
		}
		if ($discount_type==2) {
			return "Percentage";
		}
	}
}

if (!function_exists('s_c_status'))
{
	function s_c_status($company_id,$status) {
		
		if ($discount_type==1) {
			return "Flat";
		}
		if ($discount_type==2) {
			return "Percentage";
		}
	}
}

if (!function_exists('cnf_url'))
{
    function cnf_url($conf)
    {
       return base_url($conf['cnf_url']);
    }   
}

if (!function_exists('custom_date'))
{
    function custom_date($date,$format)
    {
		$dateObj = date_create($date);
		return date_format($dateObj,$format);
    }   
}