<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Upload {
	
    private $bucket = "hilaris";

    function __construct() {
        //$this->ci = & get_instance();
    } 

    public function doUpload($file, $fileName, $uploadSettings) {

        if (!empty($file) && $file['error'] != 4) {
			
			$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
			$valid_formats = explode("|",$uploadSettings['file_types']);
			$dimentions = getimagesize($file['tmp_name']);
			if(@is_array($dimentions)){
				$image = true;
			} else {
				$image = false;
			}
			
			/* print_r($dimentions);
			exit; */
			
			$ci2 = & get_instance();
			$ci2->load->library('s3');
			$ci2->load->library('session');
			$tmpName = $file['tmp_name'];

			if (!in_array($ext,$valid_formats))
			{
			   $ci2->session->set_flashdata('file_error', 'File type not supported');
			   return false;
			} 
			else if ($file['size'] > ($uploadSettings['allowed_size'] * 1024 * 1024))
			{
			   $ci2->session->set_flashdata('file_error', 'File size exceeded');
			   return false;
			}
			else if ($image==true && $dimentions[0]>$uploadSettings['width'])
			{
				$ci2->session->set_flashdata('file_error', 'File width exceeded');
				return false;
			}
			else if ($image==true && $dimentions[1]>$uploadSettings['height'])
			{
				$ci2->session->set_flashdata('file_error', 'File height exceeded');
				return false;
			}
			
			if($ci2->s3->putObjectFile($tmpName, $this->bucket, $fileName, S3::ACL_PUBLIC_READ))
			{	
				return true;
			}
			else
			{
				$this->session->set_flashdata('file_error', 'File uploading error');
				return false;
			}
        } else 
		{
			$this->session->set_flashdata('file_error', 'File uploading error');
			return false;
		}
    }
	
	public function doDelete($fileName) {
		$fileName = str_replace("https://s3.amazonaws.com/hilaris-assets/","",$fileName);
        $ci2 = & get_instance();
		$ci2->load->library('s3');
		if ($ci2->s3->deleteObject($this->bucket, $fileName)) {
			return true;
		} else {
			return false;
		}
    }
}
